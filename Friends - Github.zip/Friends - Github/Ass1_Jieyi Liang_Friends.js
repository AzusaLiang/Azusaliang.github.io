(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Ass1_Jieyi Liang_Friends_atlas_1", frames: [[948,0,941,2007],[0,0,946,2043]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_2", frames: [[943,0,935,1971],[0,0,941,2007]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_3", frames: [[934,0,929,1935],[0,0,932,1953]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_4", frames: [[0,0,1341,1331]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_5", frames: [[0,0,1342,1330]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_6", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_7", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_8", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_9", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_10", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_11", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_12", frames: [[0,0,1343,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_13", frames: [[0,0,1338,1333]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_14", frames: [[0,0,1339,1332]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_15", frames: [[0,0,1342,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_16", frames: [[0,0,1342,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_17", frames: [[0,0,1342,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_18", frames: [[0,0,1341,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_19", frames: [[0,0,1341,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_20", frames: [[0,0,1335,1334]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_21", frames: [[0,0,1336,1333]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_22", frames: [[0,0,1340,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_23", frames: [[0,0,1340,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_24", frames: [[0,0,1333,1335]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_25", frames: [[0,0,1339,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_26", frames: [[0,0,1339,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_27", frames: [[0,0,1331,1336]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_28", frames: [[0,0,1330,1337]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_29", frames: [[0,0,1338,1328]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_30", frames: [[0,0,1338,1328]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_31", frames: [[0,0,1337,1328]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_32", frames: [[0,0,1328,1337]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_33", frames: [[0,0,1326,1338]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_34", frames: [[0,0,1325,1339]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_35", frames: [[0,0,1336,1327]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_36", frames: [[0,0,1323,1340]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_37", frames: [[0,0,1322,1341]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_38", frames: [[0,0,1326,1336]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_39", frames: [[0,0,1325,1337]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_40", frames: [[0,0,1324,1338]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_41", frames: [[0,0,1321,1341]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_42", frames: [[0,0,1327,1334]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_43", frames: [[0,0,1335,1326]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_44", frames: [[0,0,1335,1326]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_45", frames: [[0,0,1322,1339]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_46", frames: [[0,0,1321,1340]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_47", frames: [[0,0,1327,1333]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_48", frames: [[0,0,1319,1341]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_49", frames: [[0,0,1319,1341]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_50", frames: [[0,0,1327,1332]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_51", frames: [[0,0,1334,1325]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_52", frames: [[0,0,1327,1330]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_53", frames: [[0,0,1332,1325]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_54", frames: [[0,0,1327,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_55", frames: [[0,0,1327,1328]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_56", frames: [[0,0,1331,1324]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_57", frames: [[0,0,1330,1324]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_58", frames: [[0,0,1326,1326]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_59", frames: [[0,0,1329,1323]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_60", frames: [[0,0,1327,1323]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_61", frames: [[0,0,924,1899],[926,0,924,1899]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_62", frames: [[0,0,1325,1324]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_63", frames: [[0,0,1326,1322]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_64", frames: [[0,0,1324,1323]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_65", frames: [[0,0,1324,1321]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_66", frames: [[0,0,1323,1321]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_67", frames: [[0,0,1295,1337]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_68", frames: [[0,0,918,1863]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_69", frames: [[0,0,1271,1333]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_70", frames: [[0,0,1270,1332]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_71", frames: [[0,0,915,1846],[917,0,912,1828]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_72", frames: [[0,0,1248,1329]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_73", frames: [[0,0,906,1792],[908,0,906,1792]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_74", frames: [[0,0,1224,1325]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_75", frames: [[0,0,1217,1322]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_76", frames: [[0,0,1200,1321]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_77", frames: [[902,0,898,1737],[0,0,900,1755]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_78", frames: [[0,0,1175,1317]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_79", frames: [[0,0,895,1720]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_80", frames: [[0,0,1164,1313]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_81", frames: [[1153,0,888,1684],[0,0,1151,1312]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_82", frames: [[0,0,888,1684],[890,0,1126,1308]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_83", frames: [[0,0,883,1648],[885,0,1109,1303]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_84", frames: [[1103,0,880,1630],[0,0,1101,1304]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_85", frames: [[0,0,877,1612],[879,0,1076,1299]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_86", frames: [[0,0,872,1576],[874,0,872,1576]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_87", frames: [[0,0,1055,1293]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_88", frames: [[0,0,1052,1295],[1054,0,866,1540]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_89", frames: [[0,0,1026,1291],[1028,0,863,1522]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_90", frames: [[862,0,1001,1286],[0,0,860,1504]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_91", frames: [[0,0,998,1283],[1000,0,855,1468]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_92", frames: [[857,0,975,1282],[0,0,855,1468]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_93", frames: [[0,0,975,1253],[977,0,975,1253]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_94", frames: [[0,0,848,1433],[850,0,950,1277]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_95", frames: [[0,0,846,1415],[848,0,940,1272]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_96", frames: [[0,0,843,1397],[845,0,924,1272]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_97", frames: [[0,0,837,1361],[839,0,837,1361]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_98", frames: [[0,0,898,1268],[900,0,881,1262]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_99", frames: [[834,0,872,1263],[0,0,832,1325]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_100", frames: [[830,0,826,1289],[0,0,828,1307]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_101", frames: [[848,0,825,1254],[0,0,846,1258]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_102", frames: [[0,0,825,1254],[827,0,825,1254]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_103", frames: [[0,0,825,1254],[827,0,825,1254]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_104", frames: [[0,0,800,1156],[802,0,687,1250]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_105", frames: [[673,0,669,1250],[1344,0,661,1259],[0,0,671,1250]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_106", frames: [[0,0,661,1259],[663,0,661,1259],[1326,0,661,1259]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_107", frames: [[663,0,660,1257],[1325,0,660,1257],[0,0,661,1259]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_108", frames: [[661,0,658,1253],[0,0,659,1254],[1321,0,656,1250]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_109", frames: [[0,0,655,1250],[1314,0,653,1250],[657,0,655,1250]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_110", frames: [[0,0,650,1250],[1304,0,647,1250],[652,0,650,1250],[0,1252,1000,730]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_111", frames: [[1275,856,749,805],[0,0,800,881],[802,0,800,854],[0,1411,612,601],[614,1663,781,381],[0,883,1273,526]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_112", frames: [[1428,0,326,353],[1244,770,278,374],[348,865,304,359],[928,763,314,335],[298,1266,311,345],[654,763,272,391],[896,387,291,374],[1768,1488,280,365],[1212,1146,289,355],[0,1637,300,364],[587,387,307,355],[1500,382,279,386],[928,1100,282,366],[1781,382,265,397],[1524,781,315,330],[888,1468,293,350],[1756,0,285,380],[1482,1503,284,360],[617,1610,269,389],[611,1226,274,382],[1503,1146,301,340],[302,1613,313,340],[1183,1503,297,345],[0,1266,296,369],[1189,387,309,350],[0,383,585,480],[0,865,346,399],[0,0,781,381],[783,0,643,385]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_113", frames: [[800,726,261,367],[0,337,285,358],[1429,1146,276,338],[582,332,256,386],[287,337,293,338],[1340,746,242,398],[541,720,257,374],[1387,346,243,398],[534,1458,269,353],[1562,0,290,344],[0,0,305,335],[855,1095,273,346],[1246,0,314,320],[0,1422,268,375],[1104,1465,283,324],[1130,1146,297,317],[0,697,274,370],[840,332,249,392],[1389,1486,286,317],[290,1096,296,324],[933,0,311,325],[1091,327,294,331],[588,1096,265,360],[1677,1486,297,303],[1091,660,247,390],[805,1458,297,310],[270,1422,262,380],[1584,746,242,398],[287,677,252,382],[0,1069,288,351],[623,0,308,330],[307,0,314,325],[1707,1146,280,331],[1632,346,243,398]]},
		{name:"Ass1_Jieyi Liang_Friends_atlas_114", frames: [[1477,0,556,150],[1477,152,556,150],[291,305,220,251],[0,312,220,251],[513,305,62,65],[1532,555,123,66],[513,372,44,54],[1427,583,56,32],[72,565,70,56],[347,558,86,69],[2035,0,7,7],[435,558,70,61],[256,348,29,31],[222,520,61,32],[513,428,24,14],[559,372,21,13],[222,481,54,37],[1892,304,139,146],[1532,456,142,97],[1700,304,190,304],[1892,452,142,108],[1364,456,166,125],[222,312,32,111],[222,425,44,54],[1980,601,56,32],[144,565,70,56],[1892,562,86,69],[2035,9,7,7],[0,565,70,61],[256,381,29,31],[256,312,33,34],[1364,583,61,32],[539,428,24,14],[559,387,21,13],[1980,562,54,37],[584,298,556,150],[1142,304,556,150],[513,450,220,251],[735,450,220,251],[957,456,220,251],[222,558,123,66],[1179,0,296,289],[291,0,291,303],[883,0,294,296],[0,0,289,310],[584,0,297,296],[1179,456,183,300]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.currentSoundStreamInMovieclip;
	this.soundStreamDuration = new Map();
	this.streamSoundSymbolsList = [];

	this.gotoAndPlayForStreamSoundSync = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.gotoAndPlay = function(positionOrLabel){
		this.clearAllSoundStreams();
		var pos = this.timeline.resolve(positionOrLabel);
		if (pos != null) { this.startStreamSoundsForTargetedFrame(pos); }
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		this.clearAllSoundStreams();
		this.startStreamSoundsForTargetedFrame(this.currentFrame);
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
		this.clearAllSoundStreams();
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
		this.clearAllSoundStreams();
	}
	this.startStreamSoundsForTargetedFrame = function(targetFrame){
		for(var index=0; index<this.streamSoundSymbolsList.length; index++){
			if(index <= targetFrame && this.streamSoundSymbolsList[index] != undefined){
				for(var i=0; i<this.streamSoundSymbolsList[index].length; i++){
					var sound = this.streamSoundSymbolsList[index][i];
					if(sound.endFrame > targetFrame){
						var targetPosition = Math.abs((((targetFrame - sound.startFrame)/lib.properties.fps) * 1000));
						var instance = playSound(sound.id);
						var remainingLoop = 0;
						if(sound.offset){
							targetPosition = targetPosition + sound.offset;
						}
						else if(sound.loop > 1){
							var loop = targetPosition /instance.duration;
							remainingLoop = Math.floor(sound.loop - loop);
							if(targetPosition == 0){ remainingLoop -= 1; }
							targetPosition = targetPosition % instance.duration;
						}
						instance.loop = remainingLoop;
						instance.position = Math.round(targetPosition);
						this.InsertIntoSoundStreamData(instance, sound.startFrame, sound.endFrame, sound.loop , sound.offset);
					}
				}
			}
		}
	}
	this.InsertIntoSoundStreamData = function(soundInstance, startIndex, endIndex, loopValue, offsetValue){ 
 		this.soundStreamDuration.set({instance:soundInstance}, {start: startIndex, end:endIndex, loop:loopValue, offset:offsetValue});
	}
	this.clearAllSoundStreams = function(){
		this.soundStreamDuration.forEach(function(value,key){
			key.instance.stop();
		});
 		this.soundStreamDuration.clear();
		this.currentSoundStreamInMovieclip = undefined;
	}
	this.stopSoundStreams = function(currentFrame){
		if(this.soundStreamDuration.size > 0){
			var _this = this;
			this.soundStreamDuration.forEach(function(value,key,arr){
				if((value.end) == currentFrame){
					key.instance.stop();
					if(_this.currentSoundStreamInMovieclip == key) { _this.currentSoundStreamInMovieclip = undefined; }
					arr.delete(key);
				}
			});
		}
	}

	this.computeCurrentSoundStreamInstance = function(currentFrame){
		if(this.currentSoundStreamInMovieclip == undefined){
			var _this = this;
			if(this.soundStreamDuration.size > 0){
				var maxDuration = 0;
				this.soundStreamDuration.forEach(function(value,key){
					if(value.end > maxDuration){
						maxDuration = value.end;
						_this.currentSoundStreamInMovieclip = key;
					}
				});
			}
		}
	}
	this.getDesiredFrame = function(currentFrame, calculatedDesiredFrame){
		for(var frameIndex in this.actionFrames){
			if((frameIndex > currentFrame) && (frameIndex < calculatedDesiredFrame)){
				return frameIndex;
			}
		}
		return calculatedDesiredFrame;
	}

	this.syncStreamSounds = function(){
		this.stopSoundStreams(this.currentFrame);
		this.computeCurrentSoundStreamInstance(this.currentFrame);
		if(this.currentSoundStreamInMovieclip != undefined){
			var soundInstance = this.currentSoundStreamInMovieclip.instance;
			if(soundInstance.position != 0){
				var soundValue = this.soundStreamDuration.get(this.currentSoundStreamInMovieclip);
				var soundPosition = (soundValue.offset?(soundInstance.position - soundValue.offset): soundInstance.position);
				var calculatedDesiredFrame = (soundValue.start)+((soundPosition/1000) * lib.properties.fps);
				if(soundValue.loop > 1){
					calculatedDesiredFrame +=(((((soundValue.loop - soundInstance.loop -1)*soundInstance.duration)) / 1000) * lib.properties.fps);
				}
				calculatedDesiredFrame = Math.floor(calculatedDesiredFrame);
				var deltaFrame = calculatedDesiredFrame - this.currentFrame;
				if((deltaFrame >= 0) && this.ignorePause){
					cjs.MovieClip.prototype.play.call(this);
					this.ignorePause = false;
				}
				else if(deltaFrame >= 2){
					this.gotoAndPlayForStreamSoundSync(this.getDesiredFrame(this.currentFrame,calculatedDesiredFrame));
				}
				else if(deltaFrame <= -2){
					cjs.MovieClip.prototype.stop.call(this);
					this.ignorePause = true;
				}
			}
		}
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_42 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib._5a230d977ab1282200749715122466795026 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_111"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_104"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_111"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_111"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0074bb31_d3d7_4c2b_8d4c_e2de28919d34 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_42"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_021f507c_fe80_4db7_b28f_a0fb860700d4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_72"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_02b74297_c1d9_4c85_89cb_6a56eb83b7bf = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_03108360_12bd_4165_b4f3_78c24891a65c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_105"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_04e0ff08_a8c3_4f11_aae4_7c466cbd9fdb = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_80"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_074ba4b5_665c_4976_8efc_0e0af54178e1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_85"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_07cca3dc_2d6b_4a4d_8229_67d3256e222a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_67"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0880430b_d551_46a6_b9b0_b1a05a7afd52 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_107"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0946ec2a_0ae4_423a_82ff_e143dc9c7a9c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_91"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_09628f30_96af_4e66_bc2d_35b68915eab4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0b0fc6b1_d067_4c04_9cc5_f5fc154bb3cf = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_101"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0b81795a_4f44_44ee_bd6e_26a13d16a198 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0c0215f1_8028_4531_a57a_f774d47f3664 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_20"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0c7cd311_49d8_40b6_9af7_ef49393e71ba = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0f0a23e3_38d8_44b8_8204_4a6fd58f3e06 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.BMP_0fc8712f_57d9_46bc_9704_69b379bfe214 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1077c2f4_d443_44d3_8e42_cc444f2dceef = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1158e789_a00e_4910_abf2_0d9d7082a3d1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1172f37e_78f6_4b7a_90d4_4f80632b3a17 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_63"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_11ce32bb_318c_48e6_a1c0_bec7696c8d83 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_97"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1259510f_6cfd_49f9_be7e_54f6306909c7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.BMP_136a677c_bb20_49f5_9566_112a30d8b874 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_37"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_138cda8c_1e77_4545_b053_50e1c98cccee = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_92"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1478b51e_f891_414e_8a02_ff76424ee2cc = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_86"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_17dbe07d_f4b3_4e15_85e9_3795226f7ba4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_43"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_194088ad_d06b_4be7_9365_50d40a245927 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_15"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1a073860_49d2_43c7_8af0_a35bf77fcfb2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_35"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1a0b1a22_6784_4beb_b860_dceaa5d601d2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1a4a6810_ab9e_40ca_a223_391e982305df = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_7"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1c5ab76d_0902_49aa_83ab_0dc2ec96637d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_56"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1e740e63_0544_4ccd_8062_0dd5bb2dd5e0 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_105"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1e7974e5_0531_4193_b259_fc6ba08edca1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1ea9e92f_c03e_4363_a5ae_27b83b918c4b = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_8"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_1fc913b0_2e0d_4dc5_8d63_759ce09f1488 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_18"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_21063e66_3ba4_4d0d_8f29_cd1747bab8df = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_45"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_22819c11_a526_4461_b29d_6499bd4837c6 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_54"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_22c19331_f36d_470c_9338_23df1a0d8841 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_90"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_22f0890b_1124_480c_b3cd_086796d5d315 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_65"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_23feb85f_fdf8_4b94_bb56_5053d22f4f56 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.BMP_246c67c8_10d8_48fa_91ac_ed93b59ae9be = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.BMP_247f7da0_3113_462a_a66a_dd3a85b40831 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_36"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_26aaa295_8ecd_43d3_bd88_99e0f293f37e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_109"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_26b679c2_34a8_4f49_a075_b145af616971 = function() {
	this.initialize(img.BMP_26b679c2_34a8_4f49_a075_b145af616971);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,992,2331);


(lib.BMP_2845a9cb_3717_4544_b14f_5c48af5620f3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_22"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_285c01a2_00c4_4832_984f_8a06ac4922a8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_94"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_29cb9bb4_1607_48ca_bf5a_9abeb078ba72 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_29"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_2a6c6181_4334_4f29_bc7c_705e0aaf4824 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_78"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_2d707a79_0a64_4bbd_b08c_646a543df14b = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.BMP_2e212a8e_6ab0_4ccc_8044_9b2fbe736e29 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_87"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_2e365981_7a85_432b_b1dd_a3a958ba368e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_89"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_2e3d36a1_ef76_48c3_90f2_1e6036bdcc36 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_109"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_2ea02083_f40a_4c12_bc48_b213d6fde114 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_21"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_303b7a85_a3b5_4a17_93cd_927b0c8eea93 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_107"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_31683047_955a_451c_a2ad_cdae48f163bb = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_23"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_31ffaee5_4b11_4750_aee3_360f7e86acee = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_332ea57d_16d1_4228_8327_61e38414cc39 = function() {
	this.initialize(img.BMP_332ea57d_16d1_4228_8327_61e38414cc39);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,964,2151);


(lib.BMP_33549304_d507_4587_b165_f7c0ccd34aa3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_93"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_34473b6d_68ed_4a0d_832c_b11be83a2083 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.BMP_36240579_f902_4422_89d3_d392ac1ffb8d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_9"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_370ec49d_0b79_4455_9e61_924055af0a22 = function() {
	this.initialize(img.BMP_370ec49d_0b79_4455_9e61_924055af0a22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,948,2061);


(lib.BMP_39481c03_b4d1_4d3c_9dd7_7d3dde51be4a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_60"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_39fe64a9_c7d0_4e0a_83d3_6e5ac81a9460 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_39"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_3a75fcb3_4074_493b_a42f_e25c604e59ea = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.BMP_3a975cbe_3a24_4d30_8105_1c1fd14f66b2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_73"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_3b2c8d29_65a1_4c05_a7f9_d8f47fc4b3ca = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_3c870421_59c0_4c09_b5c2_51660c11ffc6 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_28"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_3cf7d1c5_1dc3_42ce_abf1_1a579965add6 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.BMP_41d4e2c6_edb5_4552_8ba0_b96996772216 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_423e1008_986d_466e_9f99_82c25859bb5d = function() {
	this.initialize(img.BMP_423e1008_986d_466e_9f99_82c25859bb5d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,984,2277);


(lib.BMP_42aed579_c10f_4722_ba29_f3975e067405 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.BMP_4400f580_25f6_4c05_ac5d_37693f9b1f0e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_93"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_463f73b4_15c1_42bf_bffe_0694372d3863 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.BMP_465e09f9_1b6b_4f1e_bfe0_ded5286a164d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.BMP_47a60fa9_0497_4df7_baf8_45b098119bed = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_25"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_4c8d72a2_a8b1_41bf_92b7_9127ec3b940d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_33"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_4d5067ed_449a_471c_92f6_07c7982a8457 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_62"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_52a82f38_d5ba_4ecc_b874_865815c4ffbe = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_16"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_57aa3ec1_9d2b_4b7b_87e3_9d3385d16a9d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_98"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_58e49e98_6e8b_4045_8855_1961f59b04ba = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.BMP_598ad700_b6f7_4e3d_b510_fe844e9b6053 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_47"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_5b6dd3b1_2a9c_4b9d_9a4a_aeb014b0615b = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_96"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_5bdd1a53_80c8_49ff_abe6_f52214b2c7d4 = function() {
	this.initialize(img.BMP_5bdd1a53_80c8_49ff_abe6_f52214b2c7d4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,975,2223);


(lib.BMP_5bff00e2_c1b9_4ba3_b2d0_e3696d3728e4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_91"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_5c904ad5_5025_42f5_b8f1_f35588e982fe = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_83"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_60586941_0b38_4bee_a76f_417c4b942e26 = function() {
	this.initialize(img.BMP_60586941_0b38_4bee_a76f_417c4b942e26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,969,2187);


(lib.BMP_60ee80d9_78f8_4a70_819f_c5df93e529f2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_14"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_616afaf9_298d_4763_83ff_a1ab3fa2a152 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_6271ce67_8cd6_48bd_b84a_f7dda1a3bfdc = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_84"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_629fbc6f_8bf8_4449_add7_09b47a0f81a3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_105"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_62ce02b4_ad02_4f1f_91e4_a0a1c130ce8d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_38"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_63a6afc5_30a6_4087_8aa4_ac9a7d4cb43c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_71"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_656d62d4_88ae_4460_be1d_21b4f1cd4697 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.BMP_65f52934_207a_4c07_beaa_3a33dd20e860 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_59"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_665f5be6_f634_4c34_979a_554d519cded1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_88"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_67cf4822_70ca_47cb_bdb8_74bc299fb298 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_106"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_68ad80ee_26c2_4ca2_9246_1de3a0ff71db = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_81"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_68eff3db_b7a0_49a6_a67c_c6177007bbe1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_74"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_69420efe_85a1_43e0_8690_fe8a154fccaf = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_108"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_6aea30a4_9771_48f7_9511_d949c53a09d1 = function() {
	this.initialize(img.BMP_6aea30a4_9771_48f7_9511_d949c53a09d1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,987,2295);


(lib.BMP_6bf45faf_e615_4252_be7c_598bcbccac16 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_97"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_6cbea746_b0f4_4e88_85a1_d0711508f537 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_61"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_6e276610_0ea5_4dad_bb56_c85b3db63769 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_106"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_6ec5101e_21ef_4790_8dc9_85c297e53d62 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.BMP_6fd98cfa_4d61_40dd_9d0b_f810e95dad23 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_99"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_729ecdba_ed40_45fa_a92a_6866ba43a9fc = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.BMP_731b6c13_d4c0_4868_bb2b_e96bbdb699ed = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_89"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7367bd0b_104c_4ff0_ae5f_3e0d06481f17 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.BMP_73b431d4_84e9_4b7a_9913_ae2d0d3cc44a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_19"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_74866099_b0fe_4372_a9eb_1302c4205ec7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_24"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_771653ca_97be_44bc_8df8_72dd57224c29 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7743ee04_b567_47a2_82da_b45bce5c7968 = function() {
	this.initialize(img.BMP_7743ee04_b567_47a2_82da_b45bce5c7968);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,975,2223);


(lib.BMP_77f902ec_7304_4f95_a52c_0b882136750a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_108"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7826b409_c1c5_49a7_9d28_8e71a39de371 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_10"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_78981d08_888c_4144_aa33_2b66f93be196 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_11"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7a6187f4_760f_4a45_b592_edea07bae90c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_109"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7bfd816e_f4f8_4d03_a8e8_01bd2e158171 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7d48466a_f8d1_407f_8c02_111d515fccbc = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_70"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7e72b04a_8c11_4135_84ab_5dd98f41f9e4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_84"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7e8c41ac_207b_4be3_b471_0b291b5c81f0 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7f496313_ca86_46d0_92f3_53aa178f5b98 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_81"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_7f61aaf2_4620_428b_b0d0_8199b1d82b44 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_48"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_81a9e7c3_c9f1_4c8b_994a_a9c17c6fe25e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_55"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_8217304c_ab8b_4e60_bf14_165b96aeed63 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_90"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_83c5ad44_6e3e_4a0d_9219_32fba3610b62 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_102"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_8414b78f_0e73_43eb_a08c_8d8a1e39c2c2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.BMP_860bf159_8cc4_439b_bf40_a0d54a81b1ca = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.BMP_86929627_a4aa_4c0e_91ea_b1b82064f8af = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.BMP_8739c21a_d800_425b_8c07_7baaa1b76c5a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.BMP_874e8f4b_4a2f_4c55_b340_5c89f1c790fc = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_88"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_876b56da_2732_4da5_9cf7_313b46d9898d = function() {
	this.initialize(img.BMP_876b56da_2732_4da5_9cf7_313b46d9898d);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,952,2079);


(lib.BMP_89ed1879_f162_4899_aedd_699fc3d5cda9 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_61"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_8b8e7fd3_ae9b_4409_9724_3ca2d3782150 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_73"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_8b9b6307_3cff_4096_9621_ef12af4b8844 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_26"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_8cdc5a21_fd70_4da8_a36e_04f051a6c866 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_12"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9129269d_9503_41e4_9fa8_ceadf14bc18a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.BMP_92e00c94_08e2_4822_aed2_7e7fd50f79af = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.BMP_93442360_1895_4deb_b4d4_5c3787bfada3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_101"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_96bc8d6f_9833_482b_b275_e031fcbccef2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_92"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9789ff62_8425_48b9_95b1_a4f978a85e06 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_50"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_97b868ca_b987_4364_a57d_8ac4def82c40 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9822633b_de4b_47bb_aad7_8f202bbe3dc2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_13"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_998101f4_0620_4255_a9ca_31c77513a9a8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9af6ea72_4691_4619_b29e_896803e9502e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9b122fbb_af45_43f5_867b_475177f08bf7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_83"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9b167905_a9c8_4a40_82cc_27e8a24f33ea = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_49"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9b66bf67_28b5_45c4_afbb_54e45d9968f2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_100"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9d592c17_dfa4_4f15_b4f1_e18952a11a42 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_30"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9dc9bd1a_91f1_4526_9545_9d7210145c10 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_53"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9e08b91a_b38f_4af3_97c1_55699c159171 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_77"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_9eb21181_a039_4318_a8f3_43237b8dbf93 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_86"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a0474b53_1ca3_4424_9a68_61ee65b2d16e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_108"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a2aee37e_8e44_46d0_ae1b_d08909b20d7c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_46"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a30c09c5_769c_47b5_afab_3ea426fec37a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a4016fb1_7dae_4e8a_a236_2928d7afdda8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a5e771e1_1320_402c_9136_ef0cc8c5791c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_75"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a65297fe_b79e_4729_9230_536a21ab1ff0 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a69e7237_9cb9_435f_8f55_76b14e17ad4a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a69f3c54_d0ef_4c1b_b799_cc55d4bde7e8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_110"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a7cb9126_1eee_4cdb_bba3_313c4a5b0f5d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_95"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a82fbb8f_c4ac_4165_8c89_08afc6bd6586 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_27"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_a845bfa8_1e57_4be2_bc01_e3569f88c7d5 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_69"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_aa1884d8_eda2_44fc_bc93_709c42872d02 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.BMP_aa7c74cc_72cb_4af5_b944_7aa2b2b14496 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.BMP_ac5ff35e_3c36_4fa2_8ed6_3d0b15b80b2c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_85"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_ae6f3efc_3410_48a7_bcfd_ea4656c47ad3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.BMP_aeb45e84_9fd5_4ccd_b32a_753177901620 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_71"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b058b328_acd3_4b1b_bd72_4c5e8d307663 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_57"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b0a27e38_db7b_46cf_8eac_2bc941e97c8a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_102"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b3291a3f_2a2c_4bdb_a5bd_c74bb7fc51a0 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_100"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b34c4c49_0550_4a42_bc43_3f91bc53fe52 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b3970c75_057d_4ae4_8b3c_abd213e19b43 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_58"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b42aa5f6_027a_4306_a7c8_2f575d5193d7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b56fc659_897e_4302_8b5b_b5efb6be861c = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b5bcce8b_2608_4970_85e0_ee44b4184f8d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_17"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b6402f6c_faf0_44e2_9f1f_73db3ea95a6e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b695fdf5_40d6_4a0d_8ce8_c5e6c887a10f = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_103"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_b8ce39c2_9547_4625_b518_1ce950dafedd = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_76"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_ba9bd476_7fe0_4639_ab98_da0f8fbf99e8 = function() {
	this.initialize(img.BMP_ba9bd476_7fe0_4639_ab98_da0f8fbf99e8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,958,2115);


(lib.BMP_bc316529_3ac5_4736_bc67_3f046ca7eca1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_94"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_bd5ab5ef_b696_45d2_b546_03192e4166ad = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_51"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c07d2671_dd4f_438f_b7c1_1bf7bc147bbe = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_106"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c08f4154_3d66_44e5_a26a_e8770eb2dfa9 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_34"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c21b20a6_b3a5_42d5_85d9_7789fdce7022 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c2216604_77bd_4a35_92a6_d4adf2962bd3 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_79"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c529e65a_7ea5_4c8a_be4b_283a44c1bf60 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c77bac63_d08e_47db_88cc_d0b74df57072 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_32"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_c87dc6f7_eada_43ef_8036_fcc15321f307 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.BMP_cd0d2951_0ab3_4fb2_8808_166fb48dac77 = function() {
	this.initialize(img.BMP_cd0d2951_0ab3_4fb2_8808_166fb48dac77);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,958,2115);


(lib.BMP_cdb0dc22_4b3b_4f69_90a3_4ff9c63ee011 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_40"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d2516f04_11c2_4eff_9eb2_82ac59798d1e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_77"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d27e897b_2bc5_40e0_abbf_edda98cc1709 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d2a4597e_fc32_4c5f_9197_c44aa262d36f = function() {
	this.initialize(img.BMP_d2a4597e_fc32_4c5f_9197_c44aa262d36f);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,981,2259);


(lib.BMP_d2cd2fb0_1dc6_4ec0_9973_72dcb33db519 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_44"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d439e2e1_33dd_49bc_998a_e748251fb1eb = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_98"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d4bfeb31_fba5_47e6_b92d_625b04023482 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d5125fd5_e413_49d4_b9f9_a3b3e189f614 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_41"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_d57f29c6_e6b6_4204_8337_ff0003a0fccf = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_da6c6ac0_e3ae_42fd_b111_7c819dbd6581 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.BMP_dc707585_749b_4bd7_8440_87f3aa891868 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.BMP_dd150289_65b3_4170_b676_30bad4741950 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.BMP_de0b260f_7e3b_472e_a4b3_02da5ced62ef = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.BMP_df79a5d3_afaa_4f42_8437_ac0650437cd7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.BMP_dfef345a_0f2e_4022_8202_95453af346e0 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e0d94be8_1f4f_481c_8e12_c3dda57936d8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_52"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e189abd1_cbf1_4786_b09b_ebf851b34c54 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e2c2f058_3598_4ece_9908_9badb5d2ae3d = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e2cbc517_0508_4aa6_8278_61c0d3a55243 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e541a397_b278_4fad_8133_85a5e813db7a = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_99"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e83797e2_b6ed_4287_b3da_1184a6cb3e7e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.BMP_e954dd2c_e36c_42b8_b886_76150e4d93eb = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_64"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_eac79bb7_70fe_4b66_a47d_a2f3dd2804a7 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_110"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_eb63cbdb_72db_4b2b_a2a2_12a05fac624e = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_110"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_ebbcaa75_ac9b_40c8_b0b3_c5a8f51d3434 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_103"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_ec4afae6_13ba_4b76_8937_2b51f85539c2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.BMP_eeb7251e_5e07_4aed_bd57_69ef997fa1b9 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_66"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f022bed6_d898_4b1f_9c2d_a55b556924ad = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_82"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f204693c_71fd_48a0_8d7a_4ec2a3d1a268 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f23b9eda_5ddf_4890_aa6c_8feb0ce426b4 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_104"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f387bd58_a3df_4bd6_a5ba_44bcc3d66b33 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_68"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f400b63e_4412_4b84_b0f1_880b22c19c23 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_95"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f58000a5_1760_4a9c_9382_028aadc195d8 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_96"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_f8a9dfaa_30ca_4f7f_853c_8063ade2d2b2 = function() {
	this.initialize(img.BMP_f8a9dfaa_30ca_4f7f_853c_8063ade2d2b2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,967,2169);


(lib.BMP_f97950e7_3926_4b4e_ad52_636ec8c58d43 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_82"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.BMP_fc26c70a_6d15_4dd6_a6a0_5779888a31c5 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_107"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.BMP_fcb07e95_ccdc_472c_8327_217968d8f997 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_31"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BMP_ffe257fb_6fc3_4ab7_9627_a1d72d614b0f = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.资源33x = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.资源33x1 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_114"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.资源44png复制2 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_113"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.资源544 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.istockphoto809856984612x612 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_111"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.kisspngfireworksroyaltyfreestockphotographybloomoffireworks5aa185cbca38163751245815205349878283 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_110"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.pngfindcommessagebubblepng632891 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_111"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.pngfindcommessagebubblepng632891png复制 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.pngimgcomfence_PNG62 = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_111"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.RIP = function() {
	this.initialize(ss["Ass1_Jieyi Liang_Friends_atlas_112"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.soil = function() {
	this.initialize(img.soil);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5736,3835);


(lib.vecteezy_cartoonbushbushes_19201231 = function() {
	this.initialize(img.vecteezy_cartoonbushbushes_19201231);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,5272,1758);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.grassland = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.istockphoto809856984612x612();
	this.instance.setTransform(220.05,-165,0.3596,0.2729,0,0,180);

	this.instance_1 = new lib.istockphoto809856984612x612();
	this.instance_1.setTransform(-220.05,-164,0.3596,0.2729);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-220,-165,440.1,165);


(lib.fencing = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.pngimgcomfence_PNG62();
	this.instance.setTransform(189,-82.65,0.1571,0.1571);

	this.instance_1 = new lib.pngimgcomfence_PNG62();
	this.instance_1.setTransform(0,-82.65,0.1571,0.1571);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-82.6,389,82.6);


(lib.补间31 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.资源44png复制2();
	this.instance.setTransform(-40.25,-65.9,0.3312,0.3312);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.2,-65.9,80.5,131.9);


(lib.补间30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.资源44png复制2();
	this.instance.setTransform(-40.25,-65.9,0.3312,0.3312);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.2,-65.9,80.5,131.9);


(lib.补间22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.CachedBmp_42();
	this.instance.setTransform(-277.95,-75.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-277.9,-75.1,556,150);


(lib.补间21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.CachedBmp_41();
	this.instance.setTransform(-277.95,-75.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-277.9,-75.1,556,150);


(lib.补间15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.CachedBmp_40();
	this.instance.setTransform(-109.8,-125.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.8,-125.7,220,251);


(lib.补间14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.CachedBmp_39();
	this.instance.setTransform(-109.8,-125.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.8,-125.7,220,251);


(lib.补间2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.CachedBmp_38();
	this.instance.setTransform(-31.1,-32.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.1,-32.5,62,65);


(lib.补间1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.CachedBmp_37();
	this.instance.setTransform(-61.4,-32.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.4,-32.9,123,66);


(lib.Bushes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.vecteezy_cartoonbushbushes_19201231();
	this.instance.setTransform(-97,-66.7,0.0379,0.0379);

	this.instance_1 = new lib.vecteezy_cartoonbushbushes_19201231();
	this.instance_1.setTransform(232,-66.7,0.0379,0.0379,0,0,180);

	this.instance_2 = new lib.vecteezy_cartoonbushbushes_19201231();
	this.instance_2.setTransform(-232,-66.7,0.0379,0.0379);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-232,-66.7,464,66.7);


(lib.boyrun2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-66,-146,0.1653,0.1653);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-66,-146,132.3,145.7);


(lib.boyrun1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-45,-155,0.1299,0.1299);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45,-155,103.9,150.2);


(lib.bouncering = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AEgAAQAAAqhUAeQhVAeh3AAQh2AAhVgeQhUgeAAgqQAAgqBUgeQBVgdB2AAQB3AABVAdQBUAeAAAqg");
	this.shape.setTransform(-0.0032,-42.5405,1.5115,4.1262,29.9988);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.4,-86.1,88.8,87.1);


(lib.bestfriend = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.text = new cjs.Text("BEST FRIEND FOREVER!", "16px 'MV Boli'", "#FF0000");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 218;
	this.text.parent = this;
	this.text.setTransform(0,-20.75);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ArBCeQgEgCgBgEIAAgCQAAgDABgCQADgEAEgBQAEgBADACQALAHAOgDQATgEAYgBQAXAAAXABQAWACASgBIABAAQARgBASgCQATgEAaABQAbACARACQAQADASgDQAFgBADADQADACABAEIAAACQAAADgCADQgDADgEABQgVADgTgDQgQgCgagCQgYgBgRADQgTADgTABQgTABgXgCQgXgBgWAAQgVABgRAEIgNABQgPAAgMgIgAkWCkIAAAAQgPgDgVAAIgtgBQgEAAgDgDQgCgDAAgEIAAgBQAAgEADgDQADgCAEAAIAsABIAAAAQAYAAAQAEIABAAQAMACAPgGIAAAAQAVgIAaAFQAVAEATgBIAAAAQAUgBASgEIAAAAQAVgFAZAKQAEABACAEIABAEIgBADQgBAEgEACQgEACgEgCQgTgHgQADIAAAAQgUAFgVABQgVABgYgEQgUgEgPAGQgPAFgMAAIgNgBgAw8ChIgggLQgEgBgCgDQgCgEABgEQACgEADgCIAFgBIADAAIAhALQAPAFARgDQAUgDAVgBQAUgCARABIAAAAQAPACAYgBQAaAAAVACQAUADATAAQASAAAPgGQASgHAZgBQAbgBAVALQAEACABAEIABADIgBAEQgCAEgEABQgEACgEgCQgRgJgVABQgVABgPAGQgTAHgWAAQgUAAgVgDQgUgCgYAAQgaABgQgCQgPgBgTACIgnAEIgOABQgPAAgNgEgAKXCjQgPgEgTAAIgoABQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIAogBIAAAAQAVAAASAFQAOADAUgDIAAAAIApgIQAVgFAbAEQAXAEARABIAAAAQASABATgBQAFAAADACQADADAAAEIAAABQAAAEgDADQgCADgFAAQgUABgTgBQgSgBgZgEQgWgEgSAEQgUAFgWADIAAAAQgMACgKAAQgLAAgJgCgAC8CjQgRgDgbAAIgtAAQgRAAgVgEIAAAAIglgEQgQgBgTAFQgYAGgVgCQgEgBgDgDQgCgDAAgDIAAgBQAAgEAEgDQADgDAEABQASACAUgGIAAAAQAXgGATACIAmAEIAAABQAUADAQAAIAsAAQAdAAATAEQAPADAMgDIABAAQAPgEAdAAQAEAAADADQADACAAAFIAAAAQAAAEgDADQgDADgEAAQgaAAgOADIAAAAQgIACgJAAQgJAAgKgCgAIOCjQgagEgQAAIglAAIguAAIgoAAQgOAAgTAEQgXAEgWgIQgEgBgCgEIgBgEIAAgDQACgEAEgCQADgCAEABQASAHARgEIABAAQAVgEAPAAIABAAIAnAAIAAAAIAuAAIAmAAQARAAAbAEQAWAEAKgGQADgCAEABQAEABACAEQACACAAADIAAACQgBAEgEACQgJAHgSAAIgSgCgAQcCjQgTgDgSgBIgmgDQgUgBgbADQgeAEgLgCQgEgBgCgEQgCgCAAgDIAAgCQABgEADgCQAEgDAEABQAJACAagEIAAAAQAdgDAVABIAAAAIAmADQATABAUADQAQACAKgEIAAAAQAIgEAEgMIAAAAQAFgQACgUIAAAAQACgUgCgTQAAgEACgDQADgEAEAAIABAAQADAAADACQADADABAEQACAVgCAWQgCAXgGASIAAgBIgCAGQgDAHgFAGQgFAGgIADIAAABQgJAEgNAAIgPgBgAxZCBIgEgBQgEgCgCgEQgBgEACgDQAIgSgEgQQgGgWABgVIAAAAQABgSgBgSIAAAAQAAgRgEgXQgDgZADgZIAEgcIAAgfIABgFIAAAAIACgCIABgBQACgCADAAQAYgHASAFQAPADASgFIABAAQAXgFAbADQAaADAUAEQATAEAOgDQASgCAYACIAAAAQATADALgEQAEgCADACQAEABACAEIABAEIgBADQgBAEgEACQgOAHgagEQgVgCgQACQgRADgXgEQgUgEgYgDQgXgDgVAFQgYAGgSgFQgMgDgPAEIAAAXQAAAGgEAZQgDAWADAWQAEAYAAASIAAAAQABATgBATIAAABQgBARAFASQAHAXgMAZQgCAEgEABIgDABIAAAAgARVAlQgEgBgDgDQgCgDAAgEIAFgoIABAAQAEgZgBgQQAAgQgEgXQgFgXgFgMQgDgIgIgBQgMgCgYABIgrACQgEAAgDgDQgDgCAAgFIAAAAQAAgEACgDQADgDAEAAIArgCIABAAQAZgBAOACIAAAAQANACAIAJIACADIAEAHQAFAOAFAZQAFAZAAASQABARgFAbIAAAAIgFAnQgBAEgDADQgDACgDAAIgBAAIAAAAgAIJiEQgcgDgSgFQgPgEgUAAQgTAAgWADQgVAEgQAEIAAAAQgSAGgcgLQgEgBgBgEIgBgEIABgEQABgEAEgBQAEgCAEACQATAHANgDIABAAQAQgFAXgEQAYgDAUAAQAWAAASAFQARAEAbADQAXADAJgDIABAAQALgFAdgEQAfgEAQAJQAEACABAEIABADIgBAEQgCAEgEABQgEACgEgCQgMgGgXADQgaAEgKAEIAAAAQgHADgNAAIgXgCgAn8iEQgOgEgSgBIgvAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIAwAAIAAAAQAUABAQAEQAOADAVgDIAtgJQAZgGARADIAfAEIAAAAQAPACAYABQAYABATgBQAFAAADACQADADAAAEIAAABQAAAEgDADQgCADgFAAQgUABgZgBQgZgBgPgCIgggEQgOgCgUAEIgvAJQgOACgLAAQgKAAgIgBgADZiFQgUgEgUgBIAAAAIgnABQgTAAgSAEQgSAEgcgFQgZgDgRAAIgjAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIAjAAQASAAAbADIAAAAQAXAEAQgDQATgEAVAAIAogBIABAAQAUABAWAEIAAAAQATAEASgEIAAAAQAWgEASAAQAEAAADADQADADAAAEQAAAEgDADQgDADgEAAQgQAAgTAEQgLACgMAAQgLAAgLgCgAjLiIQgUgBgWAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAQAWAAAWABQAUACASgCQATgCAVAAIABAAIAlAAIAAAAIAoABQAEAAADADQADADAAAEQAAAEgDADQgDADgEAAIgogBIAAAAIgmAAIAAAAQgUAAgSACIgXABIgTgBgAqwiIQgYgBgVgEQgRgEgPADQgRAEgcABQgEAAgDgDQgDgDAAgEIAAAAQAAgEADgDQADgDAEAAQAagBAPgDQATgEAVAEIABAAQATAEAWABQAXABATgCQAVgDAQADQAEABACADQACADAAADIAAACQgBAEgDACQgEACgEAAQgNgDgRADQgPACgQAAIgPgBgAKViJQgEgBgDgDQgCgDAAgDIAAgBQAAgEAEgDQADgDAEABQASACAVgDQAXgCAUABIAmACIABAAQASABATgBIAAAAQAUgBAYAAQAVABAQgEIABAAQAUgFAZAFQAWAEALAAQAFAAADADQADACAAAEIAAABQAAAEgDADQgDADgEAAQgNAAgZgEQgVgEgQADQgSAFgZgBQgWAAgUABQgUABgUgBIgmgCQgTgBgVACIgYACIgTgBg");
	this.shape.setTransform(0.2095,-14.984);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,204,0,0.8)").s().p("ARQCVQAFgFADgIIAAANgANxCVIAAgBQAAgEgDgCQgDgDgFAAQgTABgSgBIAAAAQgRAAgXgFQgagEgWAFIgpAIIAAAAQgTADgPgDQgSgFgVAAIAAAAIgoABQgEAAgDADQgDADAAAEIgDAAQAAgDgBgCQgDgEgEgBQgEgBgDADQgKAFgWgDQgbgFgRAAIgmAAIguAAIAAAAIgnAAIAAAAQgQABgVADIAAAAQgSAEgSgHQgEgBgDACQgEACgCAEIAAADIgCAAIAAAAQAAgEgDgDQgDgDgEAAQgdABgPADIgBAAQgMADgPgDQgTgEgdAAIgsAAQgQAAgUgDIAAgBIgmgEQgSgCgYAGIAAAAQgUAGgSgCQgEAAgDACQgEADAAAEIAAABIgDAAIgBgEQgCgEgEgBQgYgKgWAFIAAAAQgSAEgUABIAAAAQgSABgWgEQgagFgVAIIAAAAQgPAGgMgCIgBAAQgQgDgYgBIAAAAIgrgBQgFAAgDADQgDACAAAEIAAABIgCAAIAAgCQgBgEgDgCQgDgDgFABQgRADgRgDQgRgCgagCQgbAAgTADQgSADgRAAIAAAAQgSABgXgBQgXgCgXAAQgYABgTAEQgOADgLgGQgDgDgEABQgEABgCAEQgCACAAADIgCAAIgBgDQgBgEgDgCQgWgLgaABQgaABgSAHQgPAGgSAAQgTAAgUgCQgVgDgaAAQgYABgPgCIAAAAQgQgBgVACQgVABgUAEQgRACgPgFIghgLIgDAAIAAgCIADgBQAEgBACgEQAMgZgHgXQgFgRABgSIAAgBQACgTgCgTIAAAAQAAgRgDgZQgEgWAEgWQADgZAAgGIAAgXQAPgDAMACQASAFAZgGQAUgFAXADQAYADAVAEQAWAEARgCQAQgDAVADQAaADAOgHQAEgCABgDIABgEIADAAIAAAAQAAAEADADQADADAEAAQAcgBASgEQAOgDARAEQAVAEAYACQAZABAVgDQARgCANACQAEABAEgDQADgCABgEIAAgCIADAAQAAAEADADQADADAEAAIAvABQASAAAOAEQARAEAagFIAvgJQAUgEAOACIAgAEQAPACAZABQAZABAUgBQAFAAADgDQACgDAAgEIACAAQAAAEADADQADADAEAAQAWAAAUACQAXABATgCQASgCAUAAIAAAAIAmAAIAAAAIAoABQAEAAADgDQADgDAAgEIADAAQAAAEADADQADADAEAAIAjAAQARAAAZAEQAcAEASgEQASgEATAAIAngBIAAAAQAUABAUAEQAXAFAWgFQATgEAQAAQAEAAADgDQADgDAAgEIADAAIABAEQABAEAEABQAcALATgGIgBAAQAQgEAVgEQAWgDAUAAQATAAAQAEQARAFAcADQAgAEALgFIAAAAQALgEAZgEQAXgDAMAGQAEACAEgCQAEgBACgDIABgFIACAAQAAADACADQADAEAEAAQAVACAWgDQAVgCATABIAnACQATACAUgCQAUgBAWAAQAZABATgFQAQgDAUAEQAZAFAOgBQAEAAACgDQADgDAAgEIADAAIAAAAQAAAFADACQADADAEAAIArgCQAYAAAMABQAIABADAIQAFAMAFAXQAEAXABAQQAAAQgEAZIAAAAIgGAoQAAAEACADQADAEAEAAIABAAIAAACIgBAAQgEAAgDAEQgCADAAAEQACATgCAUIAAAAQgBAUgGAQIAAABQgEALgIAEIAAABQgKAEgQgDQgUgDgSgBIgngDIAAAAQgVgBgdADIAAAAQgaAEgJgCQgEgBgEADQgDACgBAEIAAACgARWiUIACAAIAAADIgCgDg");
	this.shape_1.setTransform(0,-14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.7,-31.6,225.9,38.7);


(lib.ClipGroup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ar9NGIAA6LIX7AAIAAaLg");
	mask.setTransform(76.6,83.775);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4D9BF").s().p("Aj2LmQgGgxgZhjIgYhaQggAngaBaIgoCNQgTAygeALIgbAAQgeghAcijIAhicQgvAOgyBzIgiBSQgRApgKAJQgVARgTgMIgQgQQgJhbBDh+QAWgnAagmIAWgeQgxAdgxBIQgaAmgcAxQgMASgUAEQgKACgIgBQgfgIgCgXIAEgVQAxiDCbh9QBNg+BEglQHBpYGMkdQB7hZBngvQA0gXAbgGIAcA9Qk6DulbGvQitDWhuCoIBFAkQBMAwAhA9QAmBGgfA4QgLAWgRgBQgSgBgNgeQgXg0g3goIgygdQAWB4AJBTQAUC4ggAXQgSANgPAAQgnAAgNhgg");
	this.shape.setTransform(76.625,83.7588);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0.1,0,153.1,167.5), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmrETIAAomINXAAIAAImg");
	mask.setTransform(42.75,27.55);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D2614").s().p("AiLEEQgigJgXgLQgcgNgUgUQgagUgVg3QgOgmgMg5QgThUgHgPQgXg4gxgEIgBgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAgBQAQgSAVgLQgOgCgIABQgMAAgLAGIgBAAIAAgBQgBAAAAAAQAAAAAAAAQAAAAgBgBQAAAAAAgBQAjgxAQgQQANgNAPgHIgLgCQgPgCgIgDIgBABQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIAAgBIABgBIAfgdIgLARQAAABgBAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAABAAQAAAAAAAAQABAAAAAAQAdADAlgJQgpAYglApQgBABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAABAAQAAAAABAAQAjACAsgQQAZgIAzgYQgtAugLBRQAAABAAAAQAAABAAAAQABABAAAAQAAAAABAAQAAABABAAQAAAAAAAAQABAAAAAAQAAAAABgBIBDgjQAogVAYgTQgeApgLAoQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAAAAAAAQABAAAAAAQA7gJA9gqQAjgYBCg8QgGARgNAZIgWApIAAADQABABAAAAQAAAAAAABQABAAAAAAQAAAAABAAQAzAAA9gqQAogcAZgdQgDAagSA+QAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAmgWAYgqQgHAmgMAfQAAABAAAAQgBABABAAQAAABAAAAQAAABABAAQAAAAABABQAAAAAAAAQABAAAAAAQABAAAAgBQA5gfAMgwQAWAfAFA+QAAAAAAABQAAAAAAABQABAAAAAAQABAAAAAAQABABAAAAQABAAAAgBQABAAAAAAQABAAAAgBQAKgTACgYQACgXgGgWQAhAQAUAXQABAAAAABQABAAAAAAQABAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQgMgdgegWQgRgMgpgWQA5gDAkAWIAEADQgVgGgQACIgFAAQAbANAWAbQAYAgAOA2QABAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgBABQgcgTgKgDIgEgCIALAMQASAVAFAQQAAABAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQAAgBgBAAIgggBQgRADgKAOQgMAQgKAYIgPAqIgcBUIgNAjQgJAUgKAMQAAABAAAAQgBABAAAAQgBAAAAAAQgBAAgBgBQgHAKgZARIg9AtQg3AkhNAFIglACQhHAAg7gQg");
	this.shape.setTransform(42.7667,27.551);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0,0,85.5,55.1), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgiAjIAAhFIBFAAIAABFg");
	mask.setTransform(3.5,3.5);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4D9BF").s().p("AgcASQgFgJgBgJIAAgWIBCgMQAGAWgGAUQgHAagWABIgCAAQgTAAgKgRg");
	this.shape.setTransform(3.5065,3.4777);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,7,7), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkCEQIAAofIIFAAIAAIfg");
	mask.setTransform(25.9,27.225);

	// 图层_3
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(7.35,0);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(7.4,0,44,54), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgbAfIAAg9IA3AAIAAA9g");
	mask.setTransform(2.775,3.125);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4D9BF").s().p("AgbAJIATgnQARAGATAKIgQAtQgXgPgQgHg");
	this.shape.setTransform(2.775,3.125);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0,0,5.6,6.3), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkXCgIAAk/IIvAAIAAE/g");
	mask.setTransform(28.025,16);

	// 图层_3
	this.instance = new lib.CachedBmp_35();

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,56,32), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgTAQIAAgfIAnAAIAAAfg");
	mask.setTransform(1.975,1.625);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FECB27").s().p("AgTAEQATgGAQgKIADgDIABADQgCAPgdANQgEgIgEgEg");
	this.shape.setTransform(1.975,1.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,4,3.2), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag5AYIAAgwIBzAAIAAAwg");
	mask.setTransform(5.825,2.45);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FECB27").s().p("AAAgEQAcgGAegOIAAAPQgXAWhcALQAmgOATgOg");
	this.shape.setTransform(5.825,2.45);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(0,0,11.7,4.9), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgoAkIAAhHIBRAAIAABHg");
	mask.setTransform(4.075,3.55);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4D9BF").s().p("AgogUIBGgOIALA1QgcAIgoAIg");
	this.shape.setTransform(4.075,3.575);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0.1,8.2,7), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AglAaIAAgzIBKAAIAAAzg");
	mask.setTransform(3.75,2.625);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F4D9BF").s().p("AglAHIAIggIBCAPQgIAPgGAVQgkgIgYgLg");
	this.shape.setTransform(3.75,2.625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,7.5,5.3), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApICwIAAlfISRAAIAAFfg");
	mask.setTransform(58.475,17.6);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCFF93").s().p("AgtBpQhgAIg6A6IgugDQiUgOiXgjIgogJQBqiLC3hQQCWhCB7AAQDoAAChBWQCFBHBRB/QhwAZhYAQQhvAThyAHQhHhRiGAKg");
	this.shape.setTransform(58.475,17.6);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0,0,117,35.2), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjuCDIAAkFIHdAAIAAEFg");
	mask.setTransform(23.85,13.05);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#930323").s().p("AiJBsQg1gXgWg2QgFgJgIgZQgHgWgGgMQBcAcBxgPQA6gIBgggQAZgJApgWQATgKAhgZQgJA7gJAfQgOAwgZAiQgvBChlARQgeAGgcAAQg7AAg2gXg");
	this.shape.setTransform(23.85,13.0696);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0,0,47.7,26.1), null);


(lib.ClipGroup_9_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AtRGvIAAtdIajAAIAANdg");
	mask_1.setTransform(85,43.05);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9F3900").s().p("AnCGKQivgOhAhrQgVgigGgmIgDggQgNAkgDAqQgCAUABAOQhMhBAKhgQADgeAMgeIAKgYQgYALgZAhQgMAQgHAPQgNhaAdhAQAUgvAygvIgMARQg4BNgFBlQgBAFAFABQAFABACgEQAYglAwgdQgXAyAAA7QAAAyARBAQACAEAEAAQAFAAABgEIALgtQAGgZAIgRQAEBBANAlQAUA3AsATQAEACADgDQAEgCgCgEQgYg+AHhJQADgYgUgTIgigjQgTgcgBgtQgBglAMglQAKggAmgXQApgaAWAhQACADAEAAQAFgBAAgEIARhhQAIg4ACgqQAygbBEgSQAvgNBNgPQDLgnB8gHQDOgNCMATQBBAJBpAiQAOAFAiAPQAfAOASAFQAAAXAHAtQAEAbAAApIAABDQAAADACACQADACADgBQAhgKAYAmQARAbAJApQAJAogPArQgRAugkASQgCgDgEACQgEABgBAEQgBBjg3BfQgDAFAFADQAEADAEgDQAzgvAdgmQAmgwAQg2QAJAiABAuQAAAFAFABQAFAAACgFQAfhNgEhOQgEhUgthAQAZAIAVAaQASAVAKAdQACAEAFAAQAFgBAAgEQgBgtgdgsIg5hNQghgsABhIQAHAkAVAbIBBBTQAsA8AABOQAAAmgJAbQgGgSgWgYIgUgUQAxB7gwBgQgYAwgiAXQAFgUAAgiIgBgfQgoCeihAwQgyAPg5ADg");
	this.shape_1.setTransform(85.0095,43.052);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_1, new cjs.Rectangle(0,0.1,170,86), null);


(lib.ClipGroup_8_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AjKGxIAAthIGVAAIAANhg");
	mask_1.setTransform(20.275,43.325);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9863E").s().p("AjEEcIADiUQABgwAEhmQAFhjABg1IAAh8QgBhGgJg1IAUAzQAMAfAPARQAPASAjgKQAHgCAtgTQBwgwBgg5QAcBBAKAbQgvAfhBAhQiDBDhfANIAMJfQgcAKgzAMQAEg+AChXg");
	this.shape_1.setTransform(20.275,43.325);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_1, new cjs.Rectangle(0,0,40.6,86.7), null);


(lib.ClipGroup_7_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AjgGNIAAsZIHBAAIAAMZg");
	mask_1.setTransform(22.475,39.675);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D9863E").s().p("AAkGIQAMhbATh3QAnjuAhiOQg7gKhLgWQiUgqhRg2IAThGQA1AXA+AVIB1AjQAZAIAhACQApADASgKQAUgKAXgaQAfgkAHgGQgdBGggCAQgmCYgSBjQgTBlghDvg");
	this.shape.setTransform(22.475,39.675);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_1, new cjs.Rectangle(0,0,45,79.4), null);


(lib.ClipGroup_6_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AmWBIIAAiPIMtAAIAACPg");
	mask_1.setTransform(40.725,7.15);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D9863E").s().p("AjdAzQiHgigyhQQCxAqDsAAIB/gHQCYgNB5geQgtAxhBAgQg+AfhSAPQhBAMhXADIgeABQhrAAhVgVg");
	this.shape_1.setTransform(40.725,7.1723);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_1, new cjs.Rectangle(0,0,81.5,14.3), null);


(lib.ClipGroup_5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AmjBQIAAifINHAAIAACfg");
	mask_1.setTransform(42,8);

	// 图层_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#207100").s().p("AmjAOQAWg7AMgcIMagGIALBMQhCAeg1ARQhCAWg8AGQhQAIhPAAQjeAAjVhCg");
	this.shape.setTransform(42,8.0021);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_1, new cjs.Rectangle(0,0,84,16), null);


(lib.ClipGroup_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ag+BZIAAixIB9AAIAACxg");
	mask_1.setTransform(6.275,8.85);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9E8807").s().p("AgVA1QgRgQgHgdIgIgzQgEgbgFgRIBigBIAbCxQg2gIgegcg");
	this.shape_1.setTransform(6.275,8.85);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_1, new cjs.Rectangle(0,0,12.6,17.7), null);


(lib.ClipGroup_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhFBXIAAitICKAAIAACtg");
	mask_1.setTransform(6.95,8.7);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#9E8807").s().p("AgFhVIBKgBQgGAjgNAqQgQAzgnAcQgWAPgqACQAoh1AYg3g");
	this.shape_1.setTransform(6.95,8.7);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_1, new cjs.Rectangle(0,0,13.9,17.4), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhMBEIAAiHICZAAIAACHg");
	mask_1.setTransform(7.725,6.8);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EFCAA6").s().p("AhMAuQATg9ASg0IB0AsQgJAhgOA6QhFgCg9gUg");
	this.shape_1.setTransform(7.725,6.8);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(0,0,15.5,13.6), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AhPBPIAAidICfAAIAACdg");
	mask_1.setTransform(7.975,7.9);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EFCAA6").s().p("AhPgoIB1gmQAXA2ATA5QhIAng2AHQgThMgOgrg");
	this.shape_1.setTransform(7.975,7.9);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(0,0,16,15.8), null);


(lib.ClipGroup_10_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AmrETIAAomINXAAIAAImg");
	mask_1.setTransform(42.775,27.55);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D2614").s().p("AiKEEQgjgJgWgLQgcgNgUgUQgcgVgUg2QgOglgMg6QgShSgHgRQgYg4gxgEIgBgBIABgCQAOgRAWgMQgcgEgQAJIgCgBIgCgBIAAgBQAjgxAQgQQAMgMAQgIIgLgCQgPgCgIgDIgBABQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAAAAAgBIAAgBIABgBQAOgOARgPIgLARQAAABgBAAQAAABAAAAQAAABAAAAQABAAAAABQAAAAAAABQAAAAABAAQAAAAAAAAQABAAAAAAQAdADAmgJQgrAZgkAoQAAABgBAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAABQAAAAAAABQABAAAAAAQAAAAABAAQAkACAsgQQAZgIAygYQgsAtgMBSQAAABAAAAQABABAAAAQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAQAAAAAAAAQABAAAAgBIBDgjQAogVAYgTQgcAngNAqQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQABAAAAABQAAAAABAAQAAAAAAAAQABAAAAAAQA7gJA9gqQAigXBDg9QgGARgNAZIgWApIAAADQABABAAAAQAAAAAAABQABAAAAAAQABAAAAAAQAzAAA+gqQAqgeAWgbQgCAUgHAYIgMAsQAAAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAngWAXgqQgFAjgOAiQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAQAAAAAAAAQABAAAAgBQA5gfAMgwQAXAgAEA9QAAAAAAABQABAAAAABQAAAAABAAQAAAAABAAQAAABABAAQAAAAABgBQAAAAAAAAQABAAAAgBQALgTACgYQACgXgHgWQAhAQAVAXQAAAAABABQAAAAABAAQAAAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQgMgdgegWQgRgNgpgVQA5gDAkAWIAEADQgVgGgQACIgEAAQAaANAWAbQAOATAKAWQAHARAIAcIgBABIgCABQgdgTgIgDIgEgCIAKAMQASAWAFAPQAAABAAAAQAAABAAAAQAAAAgBAAQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAgBAAAAIgBAAIgggBQgRADgKAOQgMAQgKAYIgPAqIgcBUIgNAjQgJAUgKAMQAAABAAAAQgBABAAAAQgBAAAAAAQgBAAgBgBQgIALgYAQQgoAegVAPQg2AkhOAFIgkACQhIAAg6gQg");
	this.shape_1.setTransform(42.7625,27.551);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10_1, new cjs.Rectangle(0,0,85.6,55.1), null);


(lib.ClipGroup_9_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgiAjIAAhFIBFAAIAABFg");
	mask_2.setTransform(3.5,3.5);

	// 图层_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F4D9BF").s().p("AgcASQgFgJgBgJIAAgWIBCgMQAGAWgGAUQgHAagWABIgCAAQgTAAgKgRg");
	this.shape_2.setTransform(3.5125,3.4777);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_2, new cjs.Rectangle(0,0,7,7), null);


(lib.ClipGroup_8_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AkCEQIAAofIIFAAIAAIfg");
	mask_2.setTransform(25.925,27.225);

	// 图层_3
	this.instance = new lib.CachedBmp_18();
	this.instance.setTransform(7.4,0);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_2, new cjs.Rectangle(7.4,0,44,54), null);


(lib.ClipGroup_7_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgbAfIAAg9IA3AAIAAA9g");
	mask_2.setTransform(2.775,3.125);

	// 图层_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F4D9BF").s().p("AgbAJIAUgnQAQAGATAKQgFARgLAcQgWgPgRgHg");
	this.shape_1.setTransform(2.775,3.125);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_2, new cjs.Rectangle(0,0,5.6,6.3), null);


(lib.ClipGroup_6_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgeAlIAAhKIA9AAIAABKg");
	mask_2.setTransform(3.075,3.75);

	// 图层_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F4D9BF").s().p("AgegMQAegTATgGIAMA2QgUAIgUAMQgLgUgKgdg");
	this.shape_2.setTransform(3.075,3.75);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_2, new cjs.Rectangle(0,0,6.2,7.5), null);


(lib.ClipGroup_5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AkXCgIAAk/IIvAAIAAE/g");
	mask_2.setTransform(28.025,16);

	// 图层_3
	this.instance_1 = new lib.CachedBmp_17();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_2, new cjs.Rectangle(0,0,56,32), null);


(lib.ClipGroup_4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgTAQIAAgfIAmAAIAAAfg");
	mask_2.setTransform(1.95,1.625);

	// 图层_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FECB27").s().p("AgTAEQATgGAQgKIADgDIAAADQgCAQgcAMg");
	this.shape_2.setTransform(1.95,1.6);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_2, new cjs.Rectangle(0,0,3.9,3.2), null);


(lib.ClipGroup_3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("Ag5AYIAAgwIBzAAIAAAwg");
	mask_2.setTransform(5.825,2.45);

	// 图层_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FECB27").s().p("AAAgEQAcgGAegOIAAAPQgXAWhcALQAngOASgOg");
	this.shape_2.setTransform(5.825,2.45);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_2, new cjs.Rectangle(0,0,11.7,4.9), null);


(lib.ClipGroup_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AgoAkIAAhHIBRAAIAABHg");
	mask_2.setTransform(4.1,3.55);

	// 图层_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F4D9BF").s().p("AgogUIBFgOIAMA1QgdAIgnAIg");
	this.shape_2.setTransform(4.1,3.575);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_2, new cjs.Rectangle(0,0.1,8.2,7), null);


(lib.ClipGroup_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AglAaIAAgzIBLAAIAAAzg");
	mask_2.setTransform(3.775,2.625);

	// 图层_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F4D9BF").s().p("AglAHIAHggIBEAPQgJAOgHAWQgjgHgYgMg");
	this.shape_2.setTransform(3.775,2.625);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_2, new cjs.Rectangle(0,0,7.6,5.3), null);


(lib.元件3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AEgAAQAAAqhUAeQhVAeh3AAQh2AAhVgeQhUgeAAgqQAAgqBUgeQBVgdB2AAQB3AABVAdQBUAeAAAqg");
	this.shape.setTransform(0.0233,0.0072,0.7019,0.4018,29.9988);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-28.8,0,28.9,0).s().p("AjLBIQhUgdgBgrQABgpBUgfQBUgdB3AAQB3AABVAdQBUAfAAApQAAArhUAdQhVAeh3AAQh3AAhUgeg");
	this.shape_1.setTransform(0.0233,0.0072,0.7019,0.4018,29.9988);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.元件3, new cjs.Rectangle(-18.7,-11.7,37.4,23.5), null);


(lib.元件309 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AEgAAQAAAqhUAeQhVAeh3AAQh2AAhVgeQhUgeAAgqQAAgqBUgeQBVgdB2AAQB3AABVAdQBUAeAAAqg");
	this.shape.setTransform(185,50.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(155.2,39.2,59.70000000000002,22.4);


(lib.Yes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("successwav");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(98));

	// 图层_1
	this.text = new cjs.Text("YESSS", "12px 'MV Boli'");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 47;
	this.text.parent = this;
	this.text.setTransform(0,-17.75);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Ajfh8IG/AAIAAD5Im/AAg");
	this.shape.setTransform(1.0754,-10.3514,1.0928,0.7685);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AjfB9IAAj5IG/AAIAAD5g");
	this.shape_1.setTransform(1.0754,-10.3514,1.0928,0.7685);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.0928,scaleY:0.7685,x:1.0754,y:-10.3514}},{t:this.shape,p:{scaleX:1.0928,scaleY:0.7685,x:1.0754,y:-10.3514}},{t:this.text,p:{scaleX:1,scaleY:1,x:0,y:-17.75}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.6477,scaleY:1.1588,x:1.6579,y:-10.5406}},{t:this.shape,p:{scaleX:1.6477,scaleY:1.1588,x:1.6579,y:-10.5406}},{t:this.text,p:{scaleX:1.5078,scaleY:1.5078,x:0.05,y:-21.7}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.1269,scaleY:0.7925,x:1.2058,y:-10.403}},{t:this.shape,p:{scaleX:1.1269,scaleY:0.7925,x:1.2058,y:-10.403}},{t:this.text,p:{scaleX:1.0313,scaleY:1.0313,x:0.1,y:-18}}]},1).to({state:[]},2).wait(96));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.5,-26,78.1,31.1);


(lib.startgame = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.text = new cjs.Text("FIND OUT MORE", "16px 'MV Boli'", "#FF0000");
	this.text.textAlign = "center";
	this.text.lineHeight = 28;
	this.text.lineWidth = 153;
	this.text.parent = this;
	this.text.setTransform(0,-59.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AsKhvIYVAAIAADfI4VAAg");
	this.shape.setTransform(-0.3,-55.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AsKBwIAAjfIYVAAIAADfg");
	this.shape_1.setTransform(-0.3,-55.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AuWiDIctAAIAAEHI8tAAg");
	this.shape_2.setTransform(-0.35,-56.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AuVCEIAAkHIcsAAIAAEHg");
	this.shape_3.setTransform(-0.35,-56.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:0,y:-59.2}}]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.text,p:{scaleX:1.1789,scaleY:1.1789,x:0.05,y:-61.15}}]},1).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:0,y:-59.2}}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.2,-70.5,185.7,43.8);


(lib.ring = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AEgAAQAAAqhUAeQhVAeh3AAQh2AAhVgeQhUgeAAgqQAAgqBUgeQBVgdB2AAQB3AABVAdQBUAeAAAqg");
	this.shape.setTransform(-0.0034,-4.0957,0.7019,0.4019);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.2,-9.2,42.5,10.2);


(lib.No = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("gamefailedwav");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(118));

	// 图层_1
	this.text = new cjs.Text("NOOOO", "12px 'MV Boli'");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 47;
	this.text.parent = this;
	this.text.setTransform(0,-17.75);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Ajfh8IG/AAIAAD5Im/AAg");
	this.shape.setTransform(1.0754,-10.1514,1.0928,0.7685);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AjfB9IAAj5IG/AAIAAD5g");
	this.shape_1.setTransform(1.0754,-10.1514,1.0928,0.7685);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1.0928,scaleY:0.7685,x:1.0754,y:-10.1514}},{t:this.shape,p:{scaleX:1.0928,scaleY:0.7685,x:1.0754,y:-10.1514}},{t:this.text,p:{scaleX:1,scaleY:1,x:0,y:-17.75}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.6477,scaleY:1.1588,x:1.6579,y:-10.2906}},{t:this.shape,p:{scaleX:1.6477,scaleY:1.1588,x:1.6579,y:-10.2906}},{t:this.text,p:{scaleX:1.5078,scaleY:1.5078,x:0.05,y:-21.75}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.6477,scaleY:1.1588,x:1.6579,y:-10.2906}},{t:this.shape,p:{scaleX:1.6477,scaleY:1.1588,x:1.6579,y:-10.2906}},{t:this.text,p:{scaleX:1.5078,scaleY:1.5078,x:0.05,y:-21.75}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1.1546,scaleY:0.812,x:1.2266,y:-10.1833}},{t:this.shape,p:{scaleX:1.1546,scaleY:0.812,x:1.2266,y:-10.1833}},{t:this.text,p:{scaleX:1.0566,scaleY:1.0566,x:0.1,y:-18.2}}]},1).to({state:[]},1).wait(116));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.5,-25.8,78.1,31);


(lib.hugering = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AEgAAQAAAqhUAeQhVAeh3AAQh2AAhVgeQhUgeAAgqQAAgqBUgeQBVgdB2AAQB3AABVAdQBUAeAAAqg");
	this.shape.setTransform(-0.0032,-42.5405,1.5115,4.1262,29.9988);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#9DC8DB","#C4DEE9"],[0,1],-28.8,0,28.9,0).s().p("AjLBIQhUgdgBgrQABgpBUgfQBUgdB3AAQB3AABVAdQBUAfAAApQAAArhUAdQhVAeh3AAQh3AAhUgeg");
	this.shape_1.setTransform(-0.0032,-42.5405,1.5115,4.1262,29.9988);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.4,-86.1,88.8,87.1);


(lib.bulb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_1 = function() {
		playSound("ideawav");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(1).call(this.frame_1).wait(22));

	// 图层_1
	this.instance = new lib._5a230d977ab1282200749715122466795026();
	this.instance.setTransform(24.9,-41.5,0.0534,0.0534,0,14.9894,-165.0106);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:0.0693,scaleY:0.0693,skewX:14.9875,skewY:-165.0125,x:32.3,y:-46.1},0).wait(1).to({scaleX:0.0534,scaleY:0.0534,skewX:14.9894,skewY:-165.0106,x:24.9,y:-41.5},0).wait(1).to({_off:true},1).wait(19));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.3,-59.5,64.6,67.3);


(lib.back2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.text = new cjs.Text("BACK", "12px 'MV Boli'", "#FF0000");
	this.text.textAlign = "center";
	this.text.lineHeight = 18;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(1.9,-8.85,0.7966,0.7966);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ACsBPIgBAAQgVgFgUgCQgTgCgQACQgRACgYgBQgYgCgNgDQgLgDgZAJQgEABgDgCQgEgBgBgEIgBgEIABgEQACgEAEgBQAhgMAOAFQAMADAVACQAWABAPgCQASgDAWADQAVACAXAFIAAAAQATAEAOgGIAAAAQARgHANgHIAFgCIADABQAEABACADQACAEgBAEQgBAEgEACIgFADIgDABIgYAMIAAAAQgMAFgOAAQgJAAgKgCgAgvBKQgSgGgUgBIgpgBQgRAAgVADQgXAEgPgBQgMAAgLgIQgGgDgFgGIgEgEQgLgPgCgTIAAgBQgBgSACgXIAAAAQACgSAAgMIAAgBIAAgBIAAgBIAAgBIAAgIIAAgBIABgDIACgDIAAgBQADgCADgBQAagCASABIAAAAIAkACIAAAAQARACAVgBQAXgCATABIApgBQAEAAADADQADADAAAEIAAAAQAAAEgCADQgDADgEAAIgqABQgTgBgVACQgXABgTgCIgjgCIAAAAIggABIAAABIAAABQgGAIgEAEQAKAJAAgVQAAANgCAUQgCAVABARQABAPAKALQAKAKALABQAOABAUgDIAAAAQAWgEAUAAIAAAAIApABQAXABAUAHQAEABACAEIABAEIAAADQgCAEgDACIgFABIgDAAgADuAlQgDgCgBgEQgDgVABgTIAAgiQgCgIgQgEQgVgGgOAEIAAAAQgTAHgXgEQgSgEgQAAIAAAAQgSABgWgCQgVgCgTACQgVACgTgBQgEAAgDgDQgDgDAAgEIAAAAQAAgEADgDQADgDAEAAQASABAUgCIAAAAQAVgCAWACIABAAQAVACAQgBIABAAQARAAAVAEIAAAAQARADAOgFIABAAQATgGAbAHQALADAHAEIAHAGQAIAHAAALIAAAkQgBARADATQABAEgDADQgCAEgEAAIgCAAQgDAAgDgCg");
	this.shape.setTransform(1.6867,-6.436);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,204,0,0.8)").s().p("ADwBDIADgCIAAACgAgkBDIgBgFQgCgEgEgBQgUgGgXgCIgpgBIAAAAQgTAAgXAEIAAAAQgUADgNAAQgLgCgKgKQgKgKgBgQQgBgRABgVQADgUgBgNIAAgBIAAgBIAhgBIAAAAIAjACQASADAXgCQAWgBASAAIAqgBQAEAAADgDQADgDgBgEIAEAAQgBAFADACQADADAEAAQATABAVgCQATgBAVABQAXACARgBIAAAAQAQAAATAEQAWAEATgHIAAAAQAPgEAVAGQAPAEACAIIAAAiQgBAUAEAUQAAAEADACQADACAEAAIAAACIgGACQgMAIgRAGIgBAAQgOAGgTgEIAAAAQgWgEgVgDQgWgDgTADQgPACgVgBQgVgBgMgEQgPgEghALQgEABgCAEIgBAFgAjyBDIAAgOIAEAEQAGAGAGAEgAjygqQAFgEAFgIQAAAPgFAAQgCAAgDgDgADrhCIAIAAIAAAGIgIgGg");
	this.shape_1.setTransform(1.85,-6.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{x:1.9,y:-8.85}}]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text,p:{x:0.6,y:9.3}}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.8,-14.5,84.1,38);


(lib.back = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.text = new cjs.Text("BACK", "8px 'MV Boli'", "#FF0000");
	this.text.textAlign = "center";
	this.text.lineHeight = 13;
	this.text.lineWidth = 224;
	this.text.parent = this;
	this.text.setTransform(0,-25.85);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("ABxBcIAAAAQgWgBgXgGQgTgEgSADIAAgBQgUAEgZgDIAAAAQgVgDgPAEQgSAFgbgDIAAAAIgigDQgEgBgDgDQgDgDAAgDIAAgBQAAgEADgDQAEgDAEABIAjADIAAAAQAXACAPgEQASgFAaAEIAAAAQAVADASgDIAAAAQAWgEAXAGIAAAAQAVAFAUABIAAAAQATABALgGIABAAQARgIAeAFQAEABACADQACADAAADIAAABQgBAEgDADQgDACgFgBQgWgDgMAFIgBAAQgNAHgTAAIgIAAgADOBRQgDgDAAgEIAAAAQAAgEADgDQALgNAAgPIAAAAIAAgkQAAgRAEgVQADgOgHgIQgJgJgPgBIgmgCIgBAAIgnAAQgEAAgDgDQgDgDAAgEIAAgBQAAgEADgDQADgCAEAAIAoAAIAAAAIAnACQAQABALAHIAGAEIAEAEQAPAPgFAZQgEATAAAPIAAAkIAAAAQABASgLAPIgBACIgFAGQgDADgEABIgBAAQgEAAgDgDgAiYBUIgngCQgTgBgLgHIgEgDIgCgCQgKgKAAgcIAAAAIABguIAAAAQABgRgDgGQgIgKAJgiIABgBIAAgBIACgCIACgCIAAAAQADgCADABIAugCQATgBAQABQAQABAPgBIAAAAIAnABIAsABQAYAAATACIAAAAQATACAUgEQAXgDAUADQAEABACADQACADAAADIAAABQgBAEgDADQgDACgEgBQgRgCgUADQgWAEgWgCQgSgCgXAAIgtgBIglgBQgQABgRgBQgPgBgSABIgoABQgEAQACAFQAHAJgCAaIgBAtIAAAAQAAASAFAGQAIAGAOABIAmACQAFAAACADQADADAAAEIAAAAQAAAEgDADQgDADgEAAIAAAAg");
	this.shape.setTransform(0.0268,-21.7632);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,204,0,0.8)").s().p("ADjBNIABgCIAAACgADJBNQAAgDgCgDQgDgDgEgBQgegFgRAJIAAAAQgMAGgSgCIgBAAQgUAAgUgGIgBAAQgXgFgVADIgBAAQgSADgVgDIAAAAQgagDgSAFQgPAEgWgDIgBAAIgjgDQgEAAgDADQgDACgBAEIAAABIgCAAQAAgEgDgDQgDgDgEAAIgngCQgOAAgHgGQgGgGAAgSIAAAAIABgtQACgbgHgJQgBgFADgPIAogCQASAAAPAAQARACARgCIAkABIAtABQAXAAATACQAVADAXgFQATgDARADQAEAAADgCQAEgCAAgEIABgCIACAAQAAAEADADQADADAEAAIAoABIAAAAIAmACQAQABAIAJQAIAIgDANQgEAVAAASIAAAkIAAAAQAAAOgMANQgDADAAAEgAjjBNIAAgFIACACIAEADgADdhMIAHAAIAAAFIgHgFg");
	this.shape_1.setTransform(0,-22.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.1,-31,228.2,33);


(lib.WarpedAsset_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.BMP_34473b6d_68ed_4a0d_832c_b11be83a2083();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,243,398);


(lib.WarpedAsset_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.BMP_4400f580_25f6_4c05_ac5d_37693f9b1f0e();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,975,1253);


(lib.WarpedAsset_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.BMP_33549304_d507_4587_b165_f7c0ccd34aa3();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,975,1253);


(lib.补间28 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.Bushes("synched",0);
	this.instance.setTransform(215.8,24.9,1,1,0,0,0,0,-33.4);

	this.instance_1 = new lib.fencing("synched",0);
	this.instance_1.setTransform(219.95,-10.55,1.1568,1.1567,0,0,0,194.5,-41.4);

	this.instance_2 = new lib.Bushes("synched",0);
	this.instance_2.setTransform(-215.8,24.9,1,1,0,0,0,0,-33.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-447.8,-58.2,895.6,116.5);


(lib.补间27 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.Bushes("synched",0);
	this.instance.setTransform(214.55,24.9,1,1,0,0,0,0,-33.4);

	this.instance_1 = new lib.fencing("synched",0);
	this.instance_1.setTransform(218.7,-10.55,1.1568,1.1567,0,0,0,194.5,-41.4);

	this.instance_2 = new lib.Bushes("synched",0);
	this.instance_2.setTransform(-214.5,24.9,1,1,0,0,0,0,-33.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-446.5,-58.2,893.1,116.5);


(lib.补间26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.grassland("synched",0);
	this.instance.setTransform(-220.05,2.4,1,1,0,0,0,0,-82.5);
	var instanceFilter_1 = new cjs.ColorFilter(0.72,0.72,0.72,1,71.4,71.4,71.4,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-222,-167,444,169);

	this.instance_1 = new lib.grassland("synched",0);
	this.instance_1.setTransform(220.05,-2.35,1,1,0,0,0,0,-82.5);
	var instance_1Filter_2 = new cjs.ColorFilter(0.72,0.72,0.72,1,71.4,71.4,71.4,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-222,-167,444,169);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-440.1,-84.8,880.2,169.7);


(lib.补间25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.grassland("synched",0);
	this.instance.setTransform(-220.05,2.4,1,1,0,0,0,0,-82.5);
	var instanceFilter_1 = new cjs.ColorFilter(0.72,0.72,0.72,1,71.4,71.4,71.4,0);
	this.instance.filters = [instanceFilter_1];
	this.instance.cache(-222,-167,444,169);

	this.instance_1 = new lib.grassland("synched",0);
	this.instance_1.setTransform(220.05,-2.35,1,1,0,0,0,0,-82.5);
	var instance_1Filter_2 = new cjs.ColorFilter(0.72,0.72,0.72,1,71.4,71.4,71.4,0);
	this.instance_1.filters = [instance_1Filter_2];
	this.instance_1.cache(-222,-167,444,169);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));
	this.timeline.addTween(cjs.Tween.get(instanceFilter_1).wait(1));
	this.timeline.addTween(cjs.Tween.get(instance_1Filter_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-440.1,-84.8,880.2,169.7);


(lib.PuppetShape_16复制7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_6("synched",0);

	this.instance_1 = new lib.BMP_23feb85f_fdf8_4b94_bb56_5053d22f4f56();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,243,398);


(lib.PuppetShape_16复制4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_6("synched",0);

	this.instance_1 = new lib.BMP_656d62d4_88ae_4460_be1d_21b4f1cd4697();
	this.instance_1.setTransform(-43.3,77.75);

	this.instance_2 = new lib.BMP_a30c09c5_769c_47b5_afab_3ea426fec37a();
	this.instance_2.setTransform(-41.3,72.55);

	this.instance_3 = new lib.BMP_e2cbc517_0508_4aa6_8278_61c0d3a55243();
	this.instance_3.setTransform(-39.4,67.4);

	this.instance_4 = new lib.BMP_465e09f9_1b6b_4f1e_bfe0_ded5286a164d();
	this.instance_4.setTransform(-37.3,62.25);

	this.instance_5 = new lib.BMP_dd150289_65b3_4170_b676_30bad4741950();
	this.instance_5.setTransform(-35,57.15);

	this.instance_6 = new lib.BMP_e2c2f058_3598_4ece_9908_9badb5d2ae3d();
	this.instance_6.setTransform(-32.55,52.1);

	this.instance_7 = new lib.BMP_aa7c74cc_72cb_4af5_b944_7aa2b2b14496();
	this.instance_7.setTransform(-30.05,47.05);

	this.instance_8 = new lib.BMP_8414b78f_0e73_43eb_a08c_8d8a1e39c2c2();
	this.instance_8.setTransform(-27.55,42);

	this.instance_9 = new lib.BMP_b42aa5f6_027a_4306_a7c8_2f575d5193d7();
	this.instance_9.setTransform(-24.55,37);

	this.instance_10 = new lib.BMP_463f73b4_15c1_42bf_bffe_0694372d3863();
	this.instance_10.setTransform(-21.55,32);

	this.instance_11 = new lib.BMP_7e8c41ac_207b_4be3_b471_0b291b5c81f0();
	this.instance_11.setTransform(-18.3,27.1);

	this.instance_12 = new lib.BMP_729ecdba_ed40_45fa_a92a_6866ba43a9fc();
	this.instance_12.setTransform(-14.8,22.3);

	this.instance_13 = new lib.BMP_c87dc6f7_eada_43ef_8036_fcc15321f307();
	this.instance_13.setTransform(-11.25,17.4);

	this.instance_14 = new lib.BMP_1259510f_6cfd_49f9_be7e_54f6306909c7();
	this.instance_14.setTransform(-7.8,11.8);

	this.instance_15 = new lib.BMP_86929627_a4aa_4c0e_91ea_b1b82064f8af();
	this.instance_15.setTransform(-3.75,5.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.3,0,314,398);


(lib.PuppetShape_16复制3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_6("synched",0);

	this.instance_1 = new lib.BMP_998101f4_0620_4255_a9ca_31c77513a9a8();
	this.instance_1.setTransform(-8.7,0.5);

	this.instance_2 = new lib.BMP_1a0b1a22_6784_4beb_b860_dceaa5d601d2();
	this.instance_2.setTransform(-12.8,6.1);

	this.instance_3 = new lib.BMP_92e00c94_08e2_4822_aed2_7e7fd50f79af();
	this.instance_3.setTransform(-16.7,11.8);

	this.instance_4 = new lib.BMP_ae6f3efc_3410_48a7_bcfd_ea4656c47ad3();
	this.instance_4.setTransform(-20.8,17.4);

	this.instance_5 = new lib.BMP_2d707a79_0a64_4bbd_b08c_646a543df14b();
	this.instance_5.setTransform(-24.1,23.25);

	this.instance_6 = new lib.BMP_ec4afae6_13ba_4b76_8937_2b51f85539c2();
	this.instance_6.setTransform(-27.45,28.85);

	this.instance_7 = new lib.BMP_860bf159_8cc4_439b_bf40_a0d54a81b1ca();
	this.instance_7.setTransform(-30.35,33.4);

	this.instance_8 = new lib.BMP_0b81795a_4f44_44ee_bd6e_26a13d16a198();
	this.instance_8.setTransform(-32.7,38.1);

	this.instance_9 = new lib.BMP_8739c21a_d800_425b_8c07_7baaa1b76c5a();
	this.instance_9.setTransform(-35.4,42.8);

	this.instance_10 = new lib.BMP_f204693c_71fd_48a0_8d7a_4ec2a3d1a268();
	this.instance_10.setTransform(-37.4,47.75);

	this.instance_11 = new lib.BMP_0f0a23e3_38d8_44b8_8204_4a6fd58f3e06();
	this.instance_11.setTransform(-39.1,52.55);

	this.instance_12 = new lib.BMP_de0b260f_7e3b_472e_a4b3_02da5ced62ef();
	this.instance_12.setTransform(-40.65,57.45);

	this.instance_13 = new lib.BMP_0c7cd311_49d8_40b6_9af7_ef49393e71ba();
	this.instance_13.setTransform(-41.9,62.45);

	this.instance_14 = new lib.BMP_a65297fe_b79e_4729_9230_536a21ab1ff0();
	this.instance_14.setTransform(-42.7,67.5);

	this.instance_15 = new lib.BMP_e83797e2_b6ed_4287_b3da_1184a6cb3e7e();
	this.instance_15.setTransform(-43.05,72.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43,0,315.4,398);


(lib.PuppetShape_16复制2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_6("synched",0);

	this.instance_1 = new lib.BMP_42aed579_c10f_4722_ba29_f3975e067405();
	this.instance_1.setTransform(-34.8,108.1);

	this.instance_2 = new lib.BMP_d27e897b_2bc5_40e0_abbf_edda98cc1709();
	this.instance_2.setTransform(-34.7,101.25);

	this.instance_3 = new lib.BMP_b56fc659_897e_4302_8b5b_b5efb6be861c();
	this.instance_3.setTransform(-34.45,94.2);

	this.instance_4 = new lib.BMP_c529e65a_7ea5_4c8a_be4b_283a44c1bf60();
	this.instance_4.setTransform(-34,87.2);

	this.instance_5 = new lib.BMP_7bfd816e_f4f8_4d03_a8e8_01bd2e158171();
	this.instance_5.setTransform(-33.2,80.4);

	this.instance_6 = new lib.BMP_9af6ea72_4691_4619_b29e_896803e9502e();
	this.instance_6.setTransform(-32.25,73.4);

	this.instance_7 = new lib.BMP_a69e7237_9cb9_435f_8f55_76b14e17ad4a();
	this.instance_7.setTransform(-30.75,66.65);

	this.instance_8 = new lib.BMP_1e7974e5_0531_4193_b259_fc6ba08edca1();
	this.instance_8.setTransform(-29.25,59.8);

	this.instance_9 = new lib.BMP_3cf7d1c5_1dc3_42ce_abf1_1a579965add6();
	this.instance_9.setTransform(-27.35,53.05);

	this.instance_10 = new lib.BMP_dfef345a_0f2e_4022_8202_95453af346e0();
	this.instance_10.setTransform(-25.3,46.3);

	this.instance_11 = new lib.BMP_1077c2f4_d443_44d3_8e42_cc444f2dceef();
	this.instance_11.setTransform(-23.25,39);

	this.instance_12 = new lib.BMP_97b868ca_b987_4364_a57d_8ac4def82c40();
	this.instance_12.setTransform(-20.7,31.15);

	this.instance_13 = new lib.BMP_09628f30_96af_4e66_bc2d_35b68915eab4();
	this.instance_13.setTransform(-17.95,23.5);

	this.instance_14 = new lib.BMP_dc707585_749b_4bd7_8440_87f3aa891868();
	this.instance_14.setTransform(-14.9,15.75);

	this.instance_15 = new lib.BMP_d4bfeb31_fba5_47e6_b92d_625b04023482();
	this.instance_15.setTransform(-11.9,8.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,298.6,398);


(lib.PuppetShape_16复制 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_6("synched",0);

	this.instance_1 = new lib.BMP_da6c6ac0_e3ae_42fd_b111_7c819dbd6581();

	this.instance_2 = new lib.BMP_b6402f6c_faf0_44e2_9f1f_73db3ea95a6e();
	this.instance_2.setTransform(-2.95,7.85);

	this.instance_3 = new lib.BMP_df79a5d3_afaa_4f42_8437_ac0650437cd7();
	this.instance_3.setTransform(-6,15.55);

	this.instance_4 = new lib.BMP_246c67c8_10d8_48fa_91ac_ed93b59ae9be();
	this.instance_4.setTransform(-9.1,23.35);

	this.instance_5 = new lib.BMP_02b74297_c1d9_4c85_89cb_6a56eb83b7bf();
	this.instance_5.setTransform(-11.85,30.9);

	this.instance_6 = new lib.BMP_aa1884d8_eda2_44fc_bc93_709c42872d02();
	this.instance_6.setTransform(-14.45,37.85);

	this.instance_7 = new lib.BMP_3a75fcb3_4074_493b_a42f_e25c604e59ea();
	this.instance_7.setTransform(-17.15,44.85);

	this.instance_8 = new lib.BMP_58e49e98_6e8b_4045_8855_1961f59b04ba();
	this.instance_8.setTransform(-19.45,51.75);

	this.instance_9 = new lib.BMP_1158e789_a00e_4910_abf2_0d9d7082a3d1();
	this.instance_9.setTransform(-21.9,58.95);

	this.instance_10 = new lib.BMP_ffe257fb_6fc3_4ab7_9627_a1d72d614b0f();
	this.instance_10.setTransform(-24.2,65.9);

	this.instance_11 = new lib.BMP_7367bd0b_104c_4ff0_ae5f_3e0d06481f17();
	this.instance_11.setTransform(-26.25,72.9);

	this.instance_12 = new lib.BMP_9129269d_9503_41e4_9fa8_ceadf14bc18a();
	this.instance_12.setTransform(-28.2,79.95);

	this.instance_13 = new lib.BMP_c21b20a6_b3a5_42d5_85d9_7789fdce7022();
	this.instance_13.setTransform(-29.85,86.95);

	this.instance_14 = new lib.BMP_6ec5101e_21ef_4790_8dc9_85c297e53d62();
	this.instance_14.setTransform(-31.6,94.1);

	this.instance_15 = new lib.BMP_b34c4c49_0550_4a42_bc43_3f91bc53fe52();
	this.instance_15.setTransform(-33.2,101.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33.2,0,294,398);


(lib.PuppetShape_15复制 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_93442360_1895_4deb_b4d4_5c3787bfada3();
	this.instance_1.setTransform(154,-5.85);

	this.instance_2 = new lib.BMP_6fd98cfa_4d61_40dd_9d0b_f810e95dad23();
	this.instance_2.setTransform(153.95,-10.75);

	this.instance_3 = new lib.BMP_57aa3ec1_9d2b_4b7b_87e3_9d3385d16a9d();
	this.instance_3.setTransform(153.95,-15.65);

	this.instance_4 = new lib.BMP_f58000a5_1760_4a9c_9382_028aadc195d8();
	this.instance_4.setTransform(153.95,-20.5);

	this.instance_5 = new lib.BMP_bc316529_3ac5_4736_bc67_3f046ca7eca1();
	this.instance_5.setTransform(153.95,-25.25);

	this.instance_6 = new lib.BMP_138cda8c_1e77_4545_b053_50e1c98cccee();
	this.instance_6.setTransform(153.95,-30);

	this.instance_7 = new lib.BMP_22c19331_f36d_470c_9338_23df1a0d8841();
	this.instance_7.setTransform(153.95,-34.7);

	this.instance_8 = new lib.BMP_2e365981_7a85_432b_b1dd_a3a958ba368e();
	this.instance_8.setTransform(153.95,-39.45);

	this.instance_9 = new lib.BMP_665f5be6_f634_4c34_979a_554d519cded1();
	this.instance_9.setTransform(153.95,-44.05);

	this.instance_10 = new lib.BMP_ac5ff35e_3c36_4fa2_8ed6_3d0b15b80b2c();
	this.instance_10.setTransform(153.95,-48.55);

	this.instance_11 = new lib.BMP_7e72b04a_8c11_4135_84ab_5dd98f41f9e4();
	this.instance_11.setTransform(153.95,-53.2);

	this.instance_12 = new lib.BMP_f97950e7_3926_4b4e_ad52_636ec8c58d43();
	this.instance_12.setTransform(153.95,-57.65);

	this.instance_13 = new lib.BMP_7f496313_ca86_46d0_92f3_53aa178f5b98();
	this.instance_13.setTransform(153.95,-62.2);

	this.instance_14 = new lib.BMP_2a6c6181_4334_4f29_bc7c_705e0aaf4824();
	this.instance_14.setTransform(153.95,-66.7);

	this.instance_15 = new lib.BMP_b8ce39c2_9547_4625_b518_1ce950dafedd();
	this.instance_15.setTransform(153.95,-71.05);

	this.instance_16 = new lib.BMP_68eff3db_b7a0_49a6_a67c_c6177007bbe1();
	this.instance_16.setTransform(154,-75.45);

	this.instance_17 = new lib.BMP_021f507c_fe80_4db7_b28f_a0fb860700d4();
	this.instance_17.setTransform(154,-79.85);

	this.instance_18 = new lib.BMP_a845bfa8_1e57_4be2_bc01_e3569f88c7d5();
	this.instance_18.setTransform(154,-84);

	this.instance_19 = new lib.BMP_07cca3dc_2d6b_4a4d_8229_67d3256e222a();
	this.instance_19.setTransform(154.05,-88.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-88.3,1449.1,1341.3);


(lib.PuppetShape_13复制4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_8b9b6307_3cff_4096_9621_ef12af4b8844();
	this.instance_1.setTransform(154.05,-79.8);

	this.instance_2 = new lib.BMP_47a60fa9_0497_4df7_baf8_45b098119bed();
	this.instance_2.setTransform(154.05,-79.8);

	this.instance_3 = new lib.BMP_2845a9cb_3717_4544_b14f_5c48af5620f3();
	this.instance_3.setTransform(154.05,-79.8);

	this.instance_4 = new lib.BMP_31683047_955a_451c_a2ad_cdae48f163bb();
	this.instance_4.setTransform(154.05,-79.8);

	this.instance_5 = new lib.BMP_73b431d4_84e9_4b7a_9913_ae2d0d3cc44a();
	this.instance_5.setTransform(154.05,-79.8);

	this.instance_6 = new lib.BMP_1fc913b0_2e0d_4dc5_8d63_759ce09f1488();
	this.instance_6.setTransform(154.05,-79.8);

	this.instance_7 = new lib.BMP_194088ad_d06b_4be7_9365_50d40a245927();
	this.instance_7.setTransform(154.05,-79.85);

	this.instance_8 = new lib.BMP_52a82f38_d5ba_4ecc_b874_865815c4ffbe();
	this.instance_8.setTransform(154.05,-79.85);

	this.instance_9 = new lib.BMP_b5bcce8b_2608_4970_85e0_ee44b4184f8d();
	this.instance_9.setTransform(154.05,-79.85);

	this.instance_10 = new lib.BMP_78981d08_888c_4144_aa33_2b66f93be196();
	this.instance_10.setTransform(154.05,-79.85);

	this.instance_11 = new lib.BMP_1a4a6810_ab9e_40ca_a223_391e982305df();
	this.instance_11.setTransform(154.05,-79.85);

	this.instance_12 = new lib.BMP_8cdc5a21_fd70_4da8_a36e_04f051a6c866();
	this.instance_12.setTransform(154.05,-79.85);

	this.instance_13 = new lib.BMP_0fc8712f_57d9_46bc_9704_69b379bfe214();
	this.instance_13.setTransform(154.05,-79.85);

	this.instance_14 = new lib.BMP_1ea9e92f_c03e_4363_a5ae_27b83b918c4b();
	this.instance_14.setTransform(154.05,-79.85);

	this.instance_15 = new lib.BMP_36240579_f902_4422_89d3_d392ac1ffb8d();
	this.instance_15.setTransform(154.05,-79.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-79.8,1497.1,1332.8);


(lib.PuppetShape_12复制4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_eeb7251e_5e07_4aed_bd57_69ef997fa1b9();
	this.instance_1.setTransform(154.05,-71.9);

	this.instance_2 = new lib.BMP_22f0890b_1124_480c_b3cd_086796d5d315();
	this.instance_2.setTransform(154.05,-72.4);

	this.instance_3 = new lib.BMP_1172f37e_78f6_4b7a_90d4_4f80632b3a17();
	this.instance_3.setTransform(154.05,-73.3);

	this.instance_4 = new lib.BMP_39481c03_b4d1_4d3c_9dd7_7d3dde51be4a();
	this.instance_4.setTransform(154.05,-73.8);

	this.instance_5 = new lib.BMP_65f52934_207a_4c07_beaa_3a33dd20e860();
	this.instance_5.setTransform(154.05,-74.2);

	this.instance_6 = new lib.BMP_b058b328_acd3_4b1b_bd72_4c5e8d307663();
	this.instance_6.setTransform(154.05,-75.05);

	this.instance_7 = new lib.BMP_1c5ab76d_0902_49aa_83ab_0dc2ec96637d();
	this.instance_7.setTransform(154.05,-75.5);

	this.instance_8 = new lib.BMP_9dc9bd1a_91f1_4526_9545_9d7210145c10();
	this.instance_8.setTransform(154.05,-75.95);

	this.instance_9 = new lib.BMP_bd5ab5ef_b696_45d2_b546_03192e4166ad();
	this.instance_9.setTransform(154.05,-76.4);

	this.instance_10 = new lib.BMP_17dbe07d_f4b3_4e15_85e9_3795226f7ba4();
	this.instance_10.setTransform(154.05,-77.2);

	this.instance_11 = new lib.BMP_d2cd2fb0_1dc6_4ec0_9973_72dcb33db519();
	this.instance_11.setTransform(154.05,-77.5);

	this.instance_12 = new lib.BMP_1a073860_49d2_43c7_8af0_a35bf77fcfb2();
	this.instance_12.setTransform(154.05,-77.9);

	this.instance_13 = new lib.BMP_fcb07e95_ccdc_472c_8327_217968d8f997();
	this.instance_13.setTransform(154.05,-78.65);

	this.instance_14 = new lib.BMP_29cb9bb4_1607_48ca_bf5a_9abeb078ba72();
	this.instance_14.setTransform(154.05,-79);

	this.instance_15 = new lib.BMP_9d592c17_dfa4_4f15_b4f1_e18952a11a42();
	this.instance_15.setTransform(154.05,-79.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-79.4,1492.1,1332.4);


(lib.PuppetShape_9复制4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_7826b409_c1c5_49a7_9d28_8e71a39de371();
	this.instance_1.setTransform(154.05,-79.85);

	this.instance_2 = new lib.BMP_3b2c8d29_65a1_4c05_a7f9_d8f47fc4b3ca();
	this.instance_2.setTransform(154.05,-80.7);

	this.instance_3 = new lib.BMP_e189abd1_cbf1_4786_b09b_ebf851b34c54();
	this.instance_3.setTransform(154.05,-81.85);

	this.instance_4 = new lib.BMP_60ee80d9_78f8_4a70_819f_c5df93e529f2();
	this.instance_4.setTransform(154.05,-82.7);

	this.instance_5 = new lib.BMP_9822633b_de4b_47bb_aad7_8f202bbe3dc2();
	this.instance_5.setTransform(154.05,-83.55);

	this.instance_6 = new lib.BMP_2ea02083_f40a_4c12_bc48_b213d6fde114();
	this.instance_6.setTransform(154.05,-84.35);

	this.instance_7 = new lib.BMP_0c0215f1_8028_4531_a57a_f774d47f3664();
	this.instance_7.setTransform(154.05,-85.25);

	this.instance_8 = new lib.BMP_74866099_b0fe_4372_a9eb_1302c4205ec7();
	this.instance_8.setTransform(154.05,-86.05);

	this.instance_9 = new lib.BMP_a82fbb8f_c4ac_4165_8c89_08afc6bd6586();
	this.instance_9.setTransform(154.05,-86.9);

	this.instance_10 = new lib.BMP_3c870421_59c0_4c09_b5c2_51660c11ffc6();
	this.instance_10.setTransform(154.05,-87.7);

	this.instance_11 = new lib.BMP_c77bac63_d08e_47db_88cc_d0b74df57072();
	this.instance_11.setTransform(154.05,-88.45);

	this.instance_12 = new lib.BMP_4c8d72a2_a8b1_41bf_92b7_9127ec3b940d();
	this.instance_12.setTransform(154.05,-89.3);

	this.instance_13 = new lib.BMP_c08f4154_3d66_44e5_a26a_e8770eb2dfa9();
	this.instance_13.setTransform(154.05,-90.05);

	this.instance_14 = new lib.BMP_247f7da0_3113_462a_a66a_dd3a85b40831();
	this.instance_14.setTransform(154.05,-90.85);

	this.instance_15 = new lib.BMP_d5125fd5_e413_49d4_b9f9_a3b3e189f614();
	this.instance_15.setTransform(154.05,-91.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-91.6,1497.1,1344.6);


(lib.PuppetShape_8复制12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_7f61aaf2_4620_428b_b0d0_8199b1d82b44();
	this.instance_1.setTransform(154.05,-92.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(20));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-92.4,1473.1,1345.4);


(lib.PuppetShape_8复制6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_9b167905_a9c8_4a40_82cc_27e8a24f33ea();
	this.instance_1.setTransform(154.05,-92.45);

	this.instance_2 = new lib.BMP_a2aee37e_8e44_46d0_ae1b_d08909b20d7c();
	this.instance_2.setTransform(154.05,-91.4);

	this.instance_3 = new lib.BMP_21063e66_3ba4_4d0d_8f29_cd1747bab8df();
	this.instance_3.setTransform(154.05,-90.4);

	this.instance_4 = new lib.BMP_cdb0dc22_4b3b_4f69_90a3_4ff9c63ee011();
	this.instance_4.setTransform(154.05,-89.1);

	this.instance_5 = new lib.BMP_39fe64a9_c7d0_4e0a_83d3_6e5ac81a9460();
	this.instance_5.setTransform(154.05,-88);

	this.instance_6 = new lib.BMP_62ce02b4_ad02_4f1f_91e4_a0a1c130ce8d();
	this.instance_6.setTransform(154.05,-86.85);

	this.instance_7 = new lib.BMP_0074bb31_d3d7_4c2b_8d4c_e2de28919d34();
	this.instance_7.setTransform(154.05,-85.4);

	this.instance_8 = new lib.BMP_598ad700_b6f7_4e3d_b510_fe844e9b6053();
	this.instance_8.setTransform(154.05,-84.15);

	this.instance_9 = new lib.BMP_9789ff62_8425_48b9_95b1_a4f978a85e06();
	this.instance_9.setTransform(154.05,-82.95);

	this.instance_10 = new lib.BMP_e0d94be8_1f4f_481c_8e12_c3dda57936d8();
	this.instance_10.setTransform(154.05,-81.3);

	this.instance_11 = new lib.BMP_22819c11_a526_4461_b29d_6499bd4837c6();
	this.instance_11.setTransform(154.05,-79.95);

	this.instance_12 = new lib.BMP_81a9e7c3_c9f1_4c8b_994a_a9c17c6fe25e();
	this.instance_12.setTransform(154.05,-78.55);

	this.instance_13 = new lib.BMP_b3970c75_057d_4ae4_8b3c_abd213e19b43();
	this.instance_13.setTransform(154.05,-76.75);

	this.instance_14 = new lib.BMP_4d5067ed_449a_471c_92f6_07c7982a8457();
	this.instance_14.setTransform(154.05,-75.3);

	this.instance_15 = new lib.BMP_e954dd2c_e36c_42b8_b886_76150e4d93eb();
	this.instance_15.setTransform(154.05,-73.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-92.4,1481.1,1345.4);


(lib.PuppetShape_8复制5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_b695fdf5_40d6_4a0d_8ce8_c5e6c887a10f();
	this.instance_1.setTransform(148.7,-0.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.9,975,1254);


(lib.PuppetShape_8复制3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_26b679c2_34a8_4f49_a075_b145af616971();
	this.instance_1.setTransform(155.25,-1093);

	this.instance_2 = new lib.BMP_6aea30a4_9771_48f7_9511_d949c53a09d1();
	this.instance_2.setTransform(155.2,-1056.55);

	this.instance_3 = new lib.BMP_d2a4597e_fc32_4c5f_9197_c44aa262d36f();
	this.instance_3.setTransform(155.1,-1020.3);

	this.instance_4 = new lib.BMP_7743ee04_b567_47a2_82da_b45bce5c7968();
	this.instance_4.setTransform(155,-983.85);

	this.instance_5 = new lib.BMP_60586941_0b38_4bee_a76f_417c4b942e26();
	this.instance_5.setTransform(154.95,-947.6);

	this.instance_6 = new lib.BMP_332ea57d_16d1_4228_8327_61e38414cc39();
	this.instance_6.setTransform(154.85,-911.15);

	this.instance_7 = new lib.BMP_ba9bd476_7fe0_4639_ab98_da0f8fbf99e8();
	this.instance_7.setTransform(154.8,-874.9);

	this.instance_8 = new lib.BMP_876b56da_2732_4da5_9cf7_313b46d9898d();
	this.instance_8.setTransform(154.7,-838.45);

	this.instance_9 = new lib.BMP_a4016fb1_7dae_4e8a_a236_2928d7afdda8();
	this.instance_9.setTransform(154.65,-802.15);

	this.instance_10 = new lib.BMP_d57f29c6_e6b6_4204_8337_ff0003a0fccf();
	this.instance_10.setTransform(154.55,-765.65);

	this.instance_11 = new lib.BMP_771653ca_97be_44bc_8df8_72dd57224c29();
	this.instance_11.setTransform(154.5,-729.35);

	this.instance_12 = new lib.BMP_41d4e2c6_edb5_4552_8ba0_b96996772216();
	this.instance_12.setTransform(154.45,-692.9);

	this.instance_13 = new lib.BMP_6cbea746_b0f4_4e88_85a1_d0711508f537();
	this.instance_13.setTransform(154.4,-656.6);

	this.instance_14 = new lib.BMP_f387bd58_a3df_4bd6_a5ba_44bcc3d66b33();
	this.instance_14.setTransform(154.35,-620.15);

	this.instance_15 = new lib.BMP_aeb45e84_9fd5_4ccd_b32a_753177901620();
	this.instance_15.setTransform(154.3,-583.8);

	this.instance_16 = new lib.BMP_8b8e7fd3_ae9b_4409_9724_3ca2d3782150();
	this.instance_16.setTransform(154.25,-547.45);

	this.instance_17 = new lib.BMP_d2516f04_11c2_4eff_9eb2_82ac59798d1e();
	this.instance_17.setTransform(154.2,-510.95);

	this.instance_18 = new lib.BMP_c2216604_77bd_4a35_92a6_d4adf2962bd3();
	this.instance_18.setTransform(154.15,-474.65);

	this.instance_19 = new lib.BMP_f022bed6_d898_4b1f_9c2d_a55b556924ad();
	this.instance_19.setTransform(154.1,-438.2);

	this.instance_20 = new lib.BMP_5c904ad5_5025_42f5_b8f1_f35588e982fe();
	this.instance_20.setTransform(154.1,-401.8);

	this.instance_21 = new lib.BMP_074ba4b5_665c_4976_8efc_0e0af54178e1();
	this.instance_21.setTransform(154.05,-365.3);

	this.instance_22 = new lib.BMP_1478b51e_f891_414e_8a02_ff76424ee2cc();
	this.instance_22.setTransform(154.05,-328.95);

	this.instance_23 = new lib.BMP_874e8f4b_4a2f_4c55_b340_5c89f1c790fc();
	this.instance_23.setTransform(154.05,-292.5);

	this.instance_24 = new lib.BMP_8217304c_ab8b_4e60_bf14_165b96aeed63();
	this.instance_24.setTransform(154,-256.1);

	this.instance_25 = new lib.BMP_5bff00e2_c1b9_4ba3_b2d0_e3696d3728e4();
	this.instance_25.setTransform(154,-219.6);

	this.instance_26 = new lib.BMP_285c01a2_00c4_4832_984f_8a06ac4922a8();
	this.instance_26.setTransform(154,-183.2);

	this.instance_27 = new lib.BMP_5b6dd3b1_2a9c_4b9d_9a4a_aeb014b0615b();
	this.instance_27.setTransform(154,-146.7);

	this.instance_28 = new lib.BMP_11ce32bb_318c_48e6_a1c0_bec7696c8d83();
	this.instance_28.setTransform(154,-110.35);

	this.instance_29 = new lib.BMP_e541a397_b278_4fad_8133_85a5e813db7a();
	this.instance_29.setTransform(154,-73.8);

	this.instance_30 = new lib.BMP_9b66bf67_28b5_45c4_afbb_54e45d9968f2();
	this.instance_30.setTransform(153.6,-37.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1093,1147.3,2346);


(lib.PuppetShape_8复制2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_83c5ad44_6e3e_4a0d_9219_32fba3610b62();
	this.instance_1.setTransform(148.7,-0.95);

	this.instance_2 = new lib.BMP_b3291a3f_2a2c_4bdb_a5bd_c74bb7fc51a0();
	this.instance_2.setTransform(154,-55.65);

	this.instance_3 = new lib.BMP_6bf45faf_e615_4252_be7c_598bcbccac16();
	this.instance_3.setTransform(154,-110.35);

	this.instance_4 = new lib.BMP_a7cb9126_1eee_4cdb_bba3_313c4a5b0f5d();
	this.instance_4.setTransform(154,-164.95);

	this.instance_5 = new lib.BMP_96bc8d6f_9833_482b_b275_e031fcbccef2();
	this.instance_5.setTransform(154,-219.6);

	this.instance_6 = new lib.BMP_731b6c13_d4c0_4868_bb2b_e96bbdb699ed();
	this.instance_6.setTransform(154.05,-274.3);

	this.instance_7 = new lib.BMP_9eb21181_a039_4318_a8f3_43237b8dbf93();
	this.instance_7.setTransform(154.05,-328.95);

	this.instance_8 = new lib.BMP_6271ce67_8cd6_48bd_b84a_f7dda1a3bfdc();
	this.instance_8.setTransform(154.1,-383.6);

	this.instance_9 = new lib.BMP_68ad80ee_26c2_4ca2_9246_1de3a0ff71db();
	this.instance_9.setTransform(154.1,-438.2);

	this.instance_10 = new lib.BMP_9e08b91a_b38f_4af3_97c1_55699c159171();
	this.instance_10.setTransform(154.15,-492.7);

	this.instance_11 = new lib.BMP_3a975cbe_3a24_4d30_8105_1c1fd14f66b2();
	this.instance_11.setTransform(154.25,-547.45);

	this.instance_12 = new lib.BMP_63a6afc5_30a6_4087_8aa4_ac9a7d4cb43c();
	this.instance_12.setTransform(154.3,-602.05);

	this.instance_13 = new lib.BMP_89ed1879_f162_4899_aedd_699fc3d5cda9();
	this.instance_13.setTransform(154.4,-656.6);

	this.instance_14 = new lib.BMP_616afaf9_298d_4763_83ff_a1ab3fa2a152();
	this.instance_14.setTransform(154.45,-711.15);

	this.instance_15 = new lib.BMP_31ffaee5_4b11_4750_aee3_360f7e86acee();
	this.instance_15.setTransform(154.55,-765.65);

	this.instance_16 = new lib.BMP_370ec49d_0b79_4455_9e61_924055af0a22();
	this.instance_16.setTransform(154.65,-820.3);

	this.instance_17 = new lib.BMP_cd0d2951_0ab3_4fb2_8808_166fb48dac77();
	this.instance_17.setTransform(154.8,-874.9);

	this.instance_18 = new lib.BMP_f8a9dfaa_30ca_4f7f_853c_8063ade2d2b2();
	this.instance_18.setTransform(154.9,-929.35);

	this.instance_19 = new lib.BMP_5bdd1a53_80c8_49ff_abe6_f52214b2c7d4();
	this.instance_19.setTransform(155,-983.85);

	this.instance_20 = new lib.BMP_423e1008_986d_466e_9f99_82c25859bb5d();
	this.instance_20.setTransform(155.15,-1038.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1038.4,1139.2,2291.5);


(lib.PuppetShape_8复制 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_136a677c_bb20_49f5_9566_112a30d8b874();
	this.instance_1.setTransform(151.2,-92.45);

	this.instance_2 = new lib.BMP_7d48466a_f8d1_407f_8c02_111d515fccbc();
	this.instance_2.setTransform(150.25,-83.2);

	this.instance_3 = new lib.BMP_a5e771e1_1320_402c_9136_ef0cc8c5791c();
	this.instance_3.setTransform(149.55,-73.5);

	this.instance_4 = new lib.BMP_04e0ff08_a8c3_4f11_aae4_7c466cbd9fdb();
	this.instance_4.setTransform(148.9,-63.7);

	this.instance_5 = new lib.BMP_9b122fbb_af45_43f5_867b_475177f08bf7();
	this.instance_5.setTransform(148.4,-53.75);

	this.instance_6 = new lib.BMP_2e212a8e_6ab0_4ccc_8044_9b2fbe736e29();
	this.instance_6.setTransform(148.35,-43.55);

	this.instance_7 = new lib.BMP_0946ec2a_0ae4_423a_82ff_e143dc9c7a9c();
	this.instance_7.setTransform(148.25,-33.2);

	this.instance_8 = new lib.BMP_f400b63e_4412_4b84_b0f1_880b22c19c23();
	this.instance_8.setTransform(148.9,-22.7);

	this.instance_9 = new lib.BMP_d439e2e1_33dd_49bc_998a_e748251fb1eb();
	this.instance_9.setTransform(150.75,-11.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-92.4,1473.2,1345.4);


(lib.PuppetShape_7复制8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_b0a27e38_db7b_46cf_8eac_2bc941e97c8a();
	this.instance_1.setTransform(148.7,-0.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.9,975,1254);


(lib.PuppetShape_7复制2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_0b0fc6b1_d067_4c04_9cc5_f5fc154bb3cf();
	this.instance_1.setTransform(148.7,-0.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.9,975,1254);


(lib.PuppetShape_5复制 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_4("synched",0);
	this.instance.setTransform(0.05,0);

	this.instance_1 = new lib.BMP_fc26c70a_6d15_4dd6_a6a0_5779888a31c5();
	this.instance_1.setTransform(147.65,-0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-0.6,975,1259);


(lib.PuppetShape_3复制2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_4("synched",0);
	this.instance.setTransform(0.05,0);

	this.instance_1 = new lib.BMP_67cf4822_70ca_47cb_bdb8_74bc299fb298();
	this.instance_1.setTransform(147.65,-0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-0.5,975,1259);


(lib.PuppetShape_2复制4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_4("synched",0);
	this.instance.setTransform(0.05,0);

	this.instance_1 = new lib.BMP_1e740e63_0544_4ccd_8062_0dd5bb2dd5e0();
	this.instance_1.setTransform(147.65,-0.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-0.5,975,1259);


(lib.PuppetShape_2复制3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_4("synched",0);
	this.instance.setTransform(0.05,0);

	this.instance_1 = new lib.BMP_f23b9eda_5ddf_4890_aa6c_8feb0ce426b4();
	this.instance_1.setTransform(148.55,-0.6);

	this.instance_2 = new lib.BMP_03108360_12bd_4165_b4f3_78c24891a65c();
	this.instance_2.setTransform(154.4,-0.6);

	this.instance_3 = new lib.BMP_a69f3c54_d0ef_4c1b_b799_cc55d4bde7e8();
	this.instance_3.setTransform(160.7,-0.6);

	this.instance_4 = new lib.BMP_eb63cbdb_72db_4b2b_a2a2_12a05fac624e();
	this.instance_4.setTransform(159,-0.6);

	this.instance_5 = new lib.BMP_7a6187f4_760f_4a45_b592_edea07bae90c();
	this.instance_5.setTransform(154.6,-0.6);

	this.instance_6 = new lib.BMP_69420efe_85a1_43e0_8690_fe8a154fccaf();
	this.instance_6.setTransform(151.25,-0.6);

	this.instance_7 = new lib.BMP_303b7a85_a3b5_4a17_93cd_927b0c8eea93();
	this.instance_7.setTransform(148.75,-0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-0.6,975,1257);


(lib.PuppetShape_2复制 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_4("synched",0);
	this.instance.setTransform(0.05,0);

	this.instance_1 = new lib.BMP_c07d2671_dd4f_438f_b7c1_1bf7bc147bbe();
	this.instance_1.setTransform(147.65,-0.6);

	this.instance_2 = new lib.BMP_0880430b_d551_46a6_b9b0_b1a05a7afd52();
	this.instance_2.setTransform(148.7,-0.6);

	this.instance_3 = new lib.BMP_77f902ec_7304_4f95_a52c_0b882136750a();
	this.instance_3.setTransform(150.15,-0.6);

	this.instance_4 = new lib.BMP_a0474b53_1ca3_4424_9a68_61ee65b2d16e();
	this.instance_4.setTransform(152.75,-0.6);

	this.instance_5 = new lib.BMP_2e3d36a1_ef76_48c3_90f2_1e6036bdcc36();
	this.instance_5.setTransform(155.8,-0.6);

	this.instance_6 = new lib.BMP_eac79bb7_70fe_4b66_a47d_a2f3dd2804a7();
	this.instance_6.setTransform(161.95,-0.6);

	this.instance_7 = new lib.BMP_26aaa295_8ecd_43d3_bd88_99e0f293f37e();
	this.instance_7.setTransform(159.15,-0.6);

	this.instance_8 = new lib.BMP_629fbc6f_8bf8_4449_add7_09b47a0f81a3();
	this.instance_8.setTransform(153.6,-0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-0.6,975,1259);


(lib.PuppetShape_1复制 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_4("synched",0);
	this.instance.setTransform(0.05,0);

	this.instance_1 = new lib.BMP_6e276610_0ea5_4dad_bb56_c85b3db63769();
	this.instance_1.setTransform(147.65,-0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-0.6,975,1259);


(lib.PuppetShape_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.WarpedAsset_1("synched",0);

	this.instance_1 = new lib.BMP_ebbcaa75_ac9b_40c8_b0b3_c5a8f51d3434();
	this.instance_1.setTransform(148.7,-0.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.9,975,1254);


(lib.Group_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_1();
	this.instance.setTransform(3.8,2.6,1,1,0,0,0,3.8,2.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(0,0,7.5,5.3), null);


(lib.Group_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_2();
	this.instance.setTransform(4,3.6,1,1,0,0,0,4,3.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(0,0,8.2,7.1), null);


(lib.Group_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_3();
	this.instance.setTransform(5.8,2.5,1,1,0,0,0,5.8,2.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,11.7,4.9), null);


(lib.Group_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_4();
	this.instance.setTransform(1.9,1.6,1,1,0,0,0,1.9,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,4,3.3), null);


(lib.Group_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_5();
	this.instance.setTransform(28,16,1,1,0,0,0,28,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(0,0,56.1,32), null);


(lib.Group_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_6();
	this.instance.setTransform(2.8,3.1,1,1,0,0,0,2.8,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(0,0,5.6,6.3), null);


(lib.Group_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_7();
	this.instance.setTransform(25.9,27.2,1,1,0,0,0,25.9,27.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,51.8,54.5), null);


(lib.Group_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_8();
	this.instance.setTransform(3.5,3.5,1,1,0,0,0,3.5,3.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,7,7), null);


(lib.Group = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_9();
	this.instance.setTransform(42.8,27.6,1,1,0,0,0,42.8,27.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,85.6,55.1), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoKPyIAA/jIQUAAIAAfjg");
	mask.setTransform(52.25,100.975);

	// 图层_3
	this.instance = new lib.CachedBmp_34();
	this.instance.setTransform(6.5,24.5);

	this.instance_1 = new lib.Group();
	this.instance_1.setTransform(42.8,41.1,1,1,0,0,0,42.8,27.6);
	this.instance_1.alpha = 0.6016;
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.CachedBmp_33();
	this.instance_2.setTransform(0,0.05);

	this.instance_3 = new lib.Group_1();
	this.instance_3.setTransform(41.4,81.9,1,1,0,0,0,3.5,3.5);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.CachedBmp_32();
	this.instance_4.setTransform(37.9,78.4);

	this.instance_5 = new lib.Group_2();
	this.instance_5.setTransform(46.95,104.85,1,1,0,0,0,25.9,27.2);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.CachedBmp_31();
	this.instance_6.setTransform(9.65,75.95);

	this.instance_7 = new lib.Group_3();
	this.instance_7.setTransform(78.45,87.7,1,1,0,0,0,2.8,3.1);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.CachedBmp_30();
	this.instance_8.setTransform(75.65,84.6);

	this.instance_9 = new lib.Group_4();
	this.instance_9.setTransform(46.25,144.65,1,1,0,0,0,28,16);
	this.instance_9.compositeOperation = "multiply";

	this.instance_10 = new lib.CachedBmp_29();
	this.instance_10.setTransform(13.15,128.65);

	this.instance_11 = new lib.Group_5();
	this.instance_11.setTransform(84.15,192.3,1,1,0,0,0,1.9,1.6);
	this.instance_11.compositeOperation = "multiply";

	this.instance_12 = new lib.CachedBmp_28();
	this.instance_12.setTransform(62.3,181.2);

	this.instance_13 = new lib.Group_6();
	this.instance_13.setTransform(17.6,198.85,1,1,0,0,0,5.8,2.5);
	this.instance_13.compositeOperation = "multiply";

	this.instance_14 = new lib.CachedBmp_27();
	this.instance_14.setTransform(2.85,189.4);

	this.instance_15 = new lib.Group_7();
	this.instance_15.setTransform(60.55,157.65,1,1,0,0,0,4,3.6);
	this.instance_15.compositeOperation = "multiply";

	this.instance_16 = new lib.Group_8();
	this.instance_16.setTransform(23.1,158.95,1,1,0,0,0,3.8,2.6);
	this.instance_16.compositeOperation = "multiply";

	this.instance_17 = new lib.CachedBmp_26();
	this.instance_17.setTransform(16.8,154.05);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8,this.instance_9,this.instance_10,this.instance_11,this.instance_12,this.instance_13,this.instance_14,this.instance_15,this.instance_16,this.instance_17];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(0,0.1,104.5,201.9), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AoKPyIAA/jIQUAAIAAfjg");
	mask_1.setTransform(52.25,100.975);

	// 图层_3
	this.instance = new lib.ClipGroup_0();
	this.instance.setTransform(52.2,101,1,1,0,0,0,52.2,101);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,104.5,202), null);


(lib.Group_10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_1_1();
	this.instance.setTransform(8,7.9,1,1,0,0,0,8,7.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_10, new cjs.Rectangle(0,0,16,15.8), null);


(lib.Group_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.ClipGroup_2_1();
	this.instance.setTransform(7.7,6.8,1,1,0,0,0,7.7,6.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(0,0,15.5,13.6), null);


(lib.Group_8_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_3_1();
	this.instance_1.setTransform(7,8.7,1,1,0,0,0,7,8.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_8_1, new cjs.Rectangle(0,0,13.9,17.4), null);


(lib.Group_7_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_4_1();
	this.instance_1.setTransform(6.2,8.8,1,1,0,0,0,6.2,8.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_7_1, new cjs.Rectangle(0,0,12.6,17.7), null);


(lib.Group_6_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_5_1();
	this.instance_1.setTransform(42,8,1,1,0,0,0,42,8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_6_1, new cjs.Rectangle(0,0,84,16), null);


(lib.Group_5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_6_1();
	this.instance_1.setTransform(40.7,7.2,1,1,0,0,0,40.7,7.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_5_1, new cjs.Rectangle(0,0,81.5,14.4), null);


(lib.Group_4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_7_1();
	this.instance_1.setTransform(22.4,39.6,1,1,0,0,0,22.4,39.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4_1, new cjs.Rectangle(0,0,45,79.4), null);


(lib.Group_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_8_1();
	this.instance_1.setTransform(20.2,43.3,1,1,0,0,0,20.2,43.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3_1, new cjs.Rectangle(0,0,40.6,86.7), null);


(lib.Group_2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_9_1();
	this.instance_1.setTransform(85,43.1,1,1,0,0,0,85,43.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_1, new cjs.Rectangle(0,0,170,86.1), null);


(lib.Group_1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_10();
	this.instance_1.setTransform(23.9,13.1,1,1,0,0,0,23.9,13.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_1, new cjs.Rectangle(0,0,47.7,26.2), null);


(lib.Group_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_11();
	this.instance_1.setTransform(58.5,17.6,1,1,0,0,0,58.5,17.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_11, new cjs.Rectangle(0,0,117,35.2), null);


(lib.ClipGroup_0_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EgZYAgnMAAAhBNMAywAAAMAAABBNg");
	mask_1.setTransform(162.45,208.65);

	// 图层_3
	this.instance_18 = new lib.Group_11();
	this.instance_18.setTransform(168.1,20.6,1,1,0,0,0,58.5,17.6);
	this.instance_18.alpha = 0.3008;
	this.instance_18.compositeOperation = "screen";

	this.instance_19 = new lib.CachedBmp_25();
	this.instance_19.setTransform(97.8,3);

	this.instance_20 = new lib.Group_1_1();
	this.instance_20.setTransform(162,135.3,1,1,0,0,0,23.9,13.1);
	this.instance_20.compositeOperation = "multiply";

	this.instance_21 = new lib.CachedBmp_24();
	this.instance_21.setTransform(93.55,59.3);

	this.instance_22 = new lib.Group_2_1();
	this.instance_22.setTransform(163.4,100,1,1,0,0,0,85,43.1);
	this.instance_22.alpha = 0.5;
	this.instance_22.compositeOperation = "multiply";

	this.instance_23 = new lib.CachedBmp_23();
	this.instance_23.setTransform(78.45,0);

	this.instance_24 = new lib.Group_3_1();
	this.instance_24.setTransform(214.55,202.65,1,1,0,0,0,20.2,43.3);
	this.instance_24.compositeOperation = "multiply";

	this.instance_25 = new lib.Group_4_1();
	this.instance_25.setTransform(115.05,205.75,1,1,0,0,0,22.4,39.6);
	this.instance_25.compositeOperation = "multiply";

	this.instance_26 = new lib.Group_5_1();
	this.instance_26.setTransform(161,157.15,1,1,0,0,0,40.7,7.2);
	this.instance_26.alpha = 0.5;
	this.instance_26.compositeOperation = "multiply";

	this.instance_27 = new lib.CachedBmp_22();
	this.instance_27.setTransform(92.65,141.65);

	this.instance_28 = new lib.Group_6_1();
	this.instance_28.setTransform(159.1,249.95,1,1,0,0,0,42,8);
	this.instance_28.alpha = 0.3984;
	this.instance_28.compositeOperation = "multiply";

	this.instance_29 = new lib.Group_7_1();
	this.instance_29.setTransform(196.25,250.75,1,1,0,0,0,6.2,8.8);
	this.instance_29.alpha = 0.6992;
	this.instance_29.compositeOperation = "multiply";

	this.instance_30 = new lib.Group_8_1();
	this.instance_30.setTransform(121.2,251.2,1,1,0,0,0,7,8.7);
	this.instance_30.alpha = 0.6992;
	this.instance_30.compositeOperation = "multiply";

	this.instance_31 = new lib.CachedBmp_21();
	this.instance_31.setTransform(-0.75,69.15);

	this.instance_32 = new lib.Group_9();
	this.instance_32.setTransform(121.7,299,1,1,0,0,0,7.7,6.8);
	this.instance_32.compositeOperation = "multiply";

	this.instance_33 = new lib.CachedBmp_20();
	this.instance_33.setTransform(97,292.2);

	this.instance_34 = new lib.Group_10();
	this.instance_34.setTransform(188.1,297.9,1,1,0,0,0,8,7.9);
	this.instance_34.compositeOperation = "multiply";

	this.instance_35 = new lib.CachedBmp_19();
	this.instance_35.setTransform(180.1,290);

	var maskedShapeInstanceList = [this.instance_18,this.instance_19,this.instance_20,this.instance_21,this.instance_22,this.instance_23,this.instance_24,this.instance_25,this.instance_26,this.instance_27,this.instance_28,this.instance_29,this.instance_30,this.instance_31,this.instance_32,this.instance_33,this.instance_34,this.instance_35];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.instance_28},{t:this.instance_27},{t:this.instance_26},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_1, new cjs.Rectangle(0,0,324.9,417.3), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EgZYAgnMAAAhBNMAywAAAMAAABBNg");
	mask_2.setTransform(162.45,208.65);

	// 图层_3
	this.instance_1 = new lib.ClipGroup_0_1();
	this.instance_1.setTransform(162.5,210.8,1,1,0,0,0,162.5,210.8);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0,0,324.9,417.3), null);


(lib.Group_9_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_1 = new lib.ClipGroup_1_2();
	this.instance_1.setTransform(3.8,2.6,1,1,0,0,0,3.8,2.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_9_1, new cjs.Rectangle(0,0,7.6,5.3), null);


(lib.Group_8_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_2_2();
	this.instance_2.setTransform(4.1,3.6,1,1,0,0,0,4.1,3.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_8_2, new cjs.Rectangle(0,0,8.2,7.1), null);


(lib.Group_7_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_3_2();
	this.instance_2.setTransform(5.8,2.5,1,1,0,0,0,5.8,2.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_7_2, new cjs.Rectangle(0,0,11.7,4.9), null);


(lib.Group_6_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_4_2();
	this.instance_2.setTransform(1.9,1.6,1,1,0,0,0,1.9,1.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_6_2, new cjs.Rectangle(0,0,3.9,3.3), null);


(lib.Group_5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_5_2();
	this.instance_2.setTransform(28,16,1,1,0,0,0,28,16);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_5_2, new cjs.Rectangle(0,0,56.1,32), null);


(lib.Group_4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_6_2();
	this.instance_2.setTransform(3.1,3.8,1,1,0,0,0,3.1,3.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_4_2, new cjs.Rectangle(0,0,6.2,7.5), null);


(lib.Group_3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_7_2();
	this.instance_2.setTransform(2.8,3.1,1,1,0,0,0,2.8,3.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_3_2, new cjs.Rectangle(0,0,5.6,6.3), null);


(lib.Group_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_8_2();
	this.instance_2.setTransform(25.9,27.2,1,1,0,0,0,25.9,27.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_2_2, new cjs.Rectangle(0,0,51.9,54.5), null);


(lib.Group_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_9_2();
	this.instance_2.setTransform(3.5,3.5,1,1,0,0,0,3.5,3.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_1_2, new cjs.Rectangle(0,0,7,7), null);


(lib.Group_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance_2 = new lib.ClipGroup_10_1();
	this.instance_2.setTransform(42.8,27.6,1,1,0,0,0,42.8,27.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Group_12, new cjs.Rectangle(0,0,85.6,55.1), null);


(lib.ClipGroup_0_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("ApoPyIAA/jITRAAIAAfjg");
	mask_2.setTransform(61.725,100.975);

	// 图层_3
	this.instance_36 = new lib.CachedBmp_16();
	this.instance_36.setTransform(25.4,24.5);

	this.instance_37 = new lib.Group_12();
	this.instance_37.setTransform(61.7,41.1,1,1,0,0,0,42.8,27.6);
	this.instance_37.alpha = 0.6016;
	this.instance_37.compositeOperation = "multiply";

	this.instance_38 = new lib.CachedBmp_15();
	this.instance_38.setTransform(18.85,0);

	this.instance_39 = new lib.Group_1_2();
	this.instance_39.setTransform(60.3,81.9,1,1,0,0,0,3.5,3.5);
	this.instance_39.compositeOperation = "multiply";

	this.instance_40 = new lib.CachedBmp_14();
	this.instance_40.setTransform(56.8,78.4);

	this.instance_41 = new lib.Group_2_2();
	this.instance_41.setTransform(65.85,104.85,1,1,0,0,0,25.9,27.2);
	this.instance_41.compositeOperation = "multiply";

	this.instance_42 = new lib.CachedBmp_13();
	this.instance_42.setTransform(28.6,75.95);

	this.instance_43 = new lib.Group_3_2();
	this.instance_43.setTransform(97.35,87.7,1,1,0,0,0,2.8,3.1);
	this.instance_43.compositeOperation = "multiply";

	this.instance_44 = new lib.CachedBmp_12();
	this.instance_44.setTransform(94.55,84.6);

	this.instance_45 = new lib.Group_4_2();
	this.instance_45.setTransform(30.35,90.15,1,1,0,0,0,3.1,3.8);
	this.instance_45.compositeOperation = "multiply";

	this.instance_46 = new lib.CachedBmp_11();
	this.instance_46.setTransform(-0.05,86.35);

	this.instance_47 = new lib.Group_5_2();
	this.instance_47.setTransform(65.2,144.65,1,1,0,0,0,28,16);
	this.instance_47.compositeOperation = "multiply";

	this.instance_48 = new lib.CachedBmp_10();
	this.instance_48.setTransform(32.05,128.65);

	this.instance_49 = new lib.Group_6_2();
	this.instance_49.setTransform(103.1,192.3,1,1,0,0,0,1.9,1.6);
	this.instance_49.compositeOperation = "multiply";

	this.instance_50 = new lib.CachedBmp_9();
	this.instance_50.setTransform(81.15,181.2);

	this.instance_51 = new lib.Group_7_2();
	this.instance_51.setTransform(36.5,198.85,1,1,0,0,0,5.8,2.5);
	this.instance_51.compositeOperation = "multiply";

	this.instance_52 = new lib.CachedBmp_8();
	this.instance_52.setTransform(21.75,189.4);

	this.instance_53 = new lib.Group_8_2();
	this.instance_53.setTransform(79.55,157.65,1,1,0,0,0,4.1,3.6);
	this.instance_53.compositeOperation = "multiply";

	this.instance_54 = new lib.Group_9_1();
	this.instance_54.setTransform(42,158.95,1,1,0,0,0,3.8,2.6);
	this.instance_54.compositeOperation = "multiply";

	this.instance_55 = new lib.CachedBmp_7();
	this.instance_55.setTransform(35.75,154.05);

	var maskedShapeInstanceList = [this.instance_36,this.instance_37,this.instance_38,this.instance_39,this.instance_40,this.instance_41,this.instance_42,this.instance_43,this.instance_44,this.instance_45,this.instance_46,this.instance_47,this.instance_48,this.instance_49,this.instance_50,this.instance_51,this.instance_52,this.instance_53,this.instance_54,this.instance_55];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0_2, new cjs.Rectangle(0,0,123.5,202), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("ApoPyIAA/jITRAAIAAfjg");
	mask_3.setTransform(61.725,100.975);

	// 图层_3
	this.instance_2 = new lib.ClipGroup_0_2();
	this.instance_2.setTransform(61.7,101,1,1,0,0,0,61.7,101);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0,0,123.5,202), null);


(lib.元件2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.PuppetShape_1("synched",1,false);
	this.instance.setTransform(9,0.05,0.1221,0.1221,0,0,180,487.4,626.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.元件2, new cjs.Rectangle(-50.3,-76.5,100.69999999999999,153.1), null);


(lib.元件1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// 图层_1
	this.instance = new lib.PuppetShape_7复制2("synched",1,false);
	this.instance.setTransform(-9,0.05,0.1221,0.1221,0,0,0,487.4,626.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.元件1, new cjs.Rectangle(-50.3,-76.5,100.69999999999999,153.1), null);


(lib.naughtyboy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// botton
	this.boy1 = new lib.ClipGroup_14();
	this.boy1.name = "boy1";
	this.boy1.setTransform(0.05,46.25,0.3882,0.3882,0,0,0,61.7,101.1);
	new cjs.ButtonHelper(this.boy1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.boy1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.9,7,48,78.6);


// stage content:
(lib.Ass1_JieyiLiang_Friends = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,19,26,37,68,78,101,130,187,188,189,284,361,408,507,558];
	this.streamSoundSymbolsList[37] = [{id:"laughingWAV",startFrame:37,endFrame:67,loop:1,offset:0}];
	this.streamSoundSymbolsList[78] = [{id:"stretch1WAV",startFrame:78,endFrame:101,loop:1,offset:0}];
	this.streamSoundSymbolsList[101] = [{id:"stetch2WAV",startFrame:101,endFrame:122,loop:1,offset:0}];
	this.streamSoundSymbolsList[130] = [{id:"magicWAV",startFrame:130,endFrame:187,loop:1,offset:0}];
	this.streamSoundSymbolsList[189] = [{id:"springwav",startFrame:189,endFrame:283,loop:1,offset:0}];
	this.streamSoundSymbolsList[284] = [{id:"jumpsoundver26093wav",startFrame:284,endFrame:363,loop:1,offset:0}];
	// timeline functions:
	this.frame_0 = function() {
		this.clearAllSoundStreams();
		 
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.start.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并停止播放影片。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndPlay(9);
		});
	}
	this.frame_19 = function() {
		playSound("ImpactsBoardWoodHitByLargeMetalPole");
	}
	this.frame_26 = function() {
		playSound("laughwav");
	}
	this.frame_37 = function() {
		var soundInstance = playSound("laughingWAV",0);
		this.InsertIntoSoundStreamData(soundInstance,37,67,1);
	}
	this.frame_68 = function() {
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		
		
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.bulb.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并继续从该帧播放。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndPlay();
		});
	}
	this.frame_78 = function() {
		var soundInstance = playSound("stretch1WAV",0);
		this.InsertIntoSoundStreamData(soundInstance,78,101,1);
	}
	this.frame_101 = function() {
		var soundInstance = playSound("stetch2WAV",0);
		this.InsertIntoSoundStreamData(soundInstance,101,122,1);
	}
	this.frame_130 = function() {
		var soundInstance = playSound("magicWAV",0);
		this.InsertIntoSoundStreamData(soundInstance,130,187,1);
	}
	this.frame_187 = function() {
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.circle.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并继续从该帧播放。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndPlay();
		});
	}
	this.frame_188 = function() {
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.movieClip_4.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并继续从该帧播放。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.movieClip_4.gotoAndPlay();
		});
	}
	this.frame_189 = function() {
		var soundInstance = playSound("springwav",0);
		this.InsertIntoSoundStreamData(soundInstance,189,283,1);
	}
	this.frame_284 = function() {
		var soundInstance = playSound("jumpsoundver26093wav",0);
		this.InsertIntoSoundStreamData(soundInstance,284,363,1);
	}
	this.frame_361 = function() {
		playSound("fallwav");
	}
	this.frame_408 = function() {
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.no.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并继续从该帧播放。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndPlay(410);
		});
		
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.yes.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并继续从该帧播放。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndPlay(510);
		});
	}
	this.frame_507 = function() {
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		var _this = this;
		/*
		单击指定元件实例时将执行相应函数。
		*/
		_this.back.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并停止播放影片。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndStop(408);
		});
	}
	this.frame_558 = function() {
		var _this = this;
		/*
		停止播放影片剪辑/视频
		停止播放指定影片剪辑或视频。
		*/
		_this.stop();
		
		var _this = this;
		/*
		双击指定元件实例以执行相应函数。
		*/
		_this.back2.on('click', function(){
		/*
		将播放头移动到时间轴中的指定帧编号并停止播放影片。
		可在主时间轴或影片剪辑时间轴上使用。
		*/
		_this.gotoAndStop(408);
		});
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(7).call(this.frame_26).wait(11).call(this.frame_37).wait(31).call(this.frame_68).wait(10).call(this.frame_78).wait(23).call(this.frame_101).wait(29).call(this.frame_130).wait(57).call(this.frame_187).wait(1).call(this.frame_188).wait(1).call(this.frame_189).wait(95).call(this.frame_284).wait(77).call(this.frame_361).wait(47).call(this.frame_408).wait(99).call(this.frame_507).wait(51).call(this.frame_558).wait(1));

	// Start
	this.start = new lib.startgame();
	this.start.name = "start";
	this.start.setTransform(119.95,276.75,1,1,0,0,0,0,-33.6);
	new cjs.ButtonHelper(this.start, 0, 1, 2, false, new lib.startgame(), 3);

	this.text = new cjs.Text("FRIENDS", "40px 'MV Boli'");
	this.text.textAlign = "center";
	this.text.lineHeight = 64;
	this.text.lineWidth = 185;
	this.text.parent = this;
	this.text.setTransform(114.1,65.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text},{t:this.start}]}).to({state:[]},9).wait(550));

	// Bad_Ending
	this.text_1 = new cjs.Text("YOU LOST YOUR FRIEND :(", "16px 'MV Boli'", "#FF0000");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 28;
	this.text_1.lineWidth = 224;
	this.text_1.parent = this;
	this.text_1.setTransform(209.95,55.4);

	this.instance = new lib.RIP();
	this.instance.setTransform(67,151,0.3888,0.3888);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AoBCiIAAAAQgRgEgTACIgBAAQgXACgZgEQgEgBgDgDQgCgDAAgDIABgCQAAgEAEgCQADgCAEAAQAWAEAVgCIAAAAQAYgDAUAGIAAAAQAQAEAQgCIAAAAIAkgFIAAAAQATgBAXADQAUACASgFQAEgCAEACQAEACABAEIAAADIgBAFQgCADgEACQgWAHgYgDQgVgDgRABIAAAAIgjAFIAAgBIgPACQgNAAgMgEgAqXCmQgSAAgWgKQgSgHgSAFIABAAQgXAGgUABQgTABgZgEQgXgEgOACIglAGQgYAFgVgKQgEgCgBgEIgBgDIABgEQACgEAEgBQAEgCAEACQAPAHARgEIABAAIAlgGQARgCAaAEQAXAEARgBQASgBAUgFIAAgBQAYgGAYAKQASAIAPAAQAPAAAagIQAEgBADACQAEACABAEIAAADIgBAFQgCAEgEABQgdAIgRAAIAAAAgAJjCdQgEgBgCgEIgBgEIABgEQACgDAEgCQADgCAEACQAVAIANgDIABAAQARgGAXgCQAXgCASACQAQACAUgCQAWgDAWACQAUACASgEQAYgEAXAKQADACACAEIAAADIgBAEQgBAEgEACQgEABgEgCQgQgHgSADQgVAEgXgCQgUgCgUADQgWACgSgCQgQgCgVACQgVACgQAFIAAAAQgGACgIAAQgPAAgSgIgAxlCgQgUgDgQABQgEABgDgDQgDgDgBgEIAAgBQAAgDADgDQACgDAEgBQATgBAXAEIAAAAQAVAEAWgDQAagEAQADIABAAQAOADAVgDQAYgDAPAAQAEAAADADQACADAAAEIAAAAQAAAFgDACQgDADgEAAQgNAAgWADQgZADgRgEQgOgCgWAEQgLABgLAAQgOAAgOgDgAPfCgIgngEQgQgCgRAEQgEABgEgCQgDgDgBgEIgBgCQAAgDACgCQACgEAEgBQAVgFAUADIAAAAIAmAEQAUACAUgCIABAAIAvgCIAAAAQAaAAAOACIABAAQAMACAQgGIAAAAQAUgHAWgCQAIgBAEgCIABgFQADgDAEgBIABAAQADAAADACQADACABAEQADALgMAHIgBABQgGADgMACIgLABQgOADgNAEIAAAAQgWAIgRgDIAAAAQgNgCgYAAIguACIgWABIgWgBgAiwCcIAAAAQgSgFgQADQgUAEgYAAIAAAAQgXAAgUgDQgRgCgRAFQgEABgDgCQgEgCgBgEIgBgDIACgFQACgDAEgBQAUgHAVADQATADAWAAIABAAQAVAAASgDQAVgEAWAFIAAAAQASAFAQgDQAVgDARABIAAAAQAQACAXAAIAvAAQAVgBAVgCIAAAAQAZgDAPAHQAEACACADIAAAEIAAAEQgCAEgEABQgEACgEgCQgLgEgSACIgBAAQgWACgWABIgvAAQgYAAgRgCQgPgBgRADQgJACgIAAQgNAAgNgEgAD4CeIgmgGQgQgCgVAEQgYAFgSgBIgBAAIgpAAQgFAAgDgDQgDgCAAgFIAAAAQAAgEADgDQADgDAEAAIArAAIAAAAQARABAVgFQAZgEAUADIAkAFQASADATgDQAEAAAEACQADADAAAEIAAABQAAAEgCACQgCAEgEAAIgWACIgUgCgAE3CeQgEAAgDgDQgDgDAAgEIAAAAQAAgEAEgDQADgDAEAAQAWABAOgCIAAAAQAQgBAYABQAXABASgDQAVgEAVADIAAAAQATADAWABIAAAAQAVABAVgCIAAAAQAXgBAQACQAEABACADQACADAAADIAAABQAAAFgEACQgDADgEgBQgOgCgUABIgBAAQgWACgWgBIAAAAQgXgBgUgDQgSgCgSADQgUADgZgBQgWgBgPABQgKACgOAAIgPgBgAyhCeQgFAAgCgDIgGgHQgHgFgHgFIAAAAIgBAAQgSgJAEgjIAAAAIAGgpQABgOgDgWQgDgVABgWQAAgTgCgRQgEgTAFgXIAAgBQAEgPAAgPQgFgDACgGQgBgEAFgGIAAgBIADgDIAFgBIACAAIAEACQAKAGASgEIABAAQAagFATACIAAAAQASACAXgCIApgCQASgBASABIAAAAIAoABIAAAAQAXAAATgBIAAAAQAUAAAVABQAEABADADQACADAAADIAAABQAAAEgDADQgDACgEAAQgUgBgTAAQgUABgXAAIAAAAIgpgBIAAAAIgiAAIgpACQgZACgTgCIAAAAQgRgCgXAEIAAAAQgQAEgLgCQAAAQgEASQgFATADAQQADASAAAWQgBAUADAUQADAYgBAQIgGApIAAABQgCASAHAGIAAAAQAPAJAKAMQACADAAADIAAABQAAAEgDADQgDACgEAAIAAAAgAS7BwQgEgBgCgDQgCgEABgEQADgTgDgRQgFgUgBgVIgCgqIAAAAQAAgXAFgTQAFgSADgUQACgSgEgKIAAABQgGgIgSgFQgEgBgCgEIgCgFIABgCQABgEADgCQAEgDAEABQAPAEAJAGIABABQAIAFADAHIAAAAQAIAOgDAaQgDAWgFASQgFARAAAUIAAAAIACAoQABAUAEATQAEAVgEAXQgBAEgDACQgDACgDAAIgCAAgAAPiDIgkgEQgRgCgWABIgBAAQgYABgYgFQgVgEgPACIABAAQgRADgYAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAQAWAAAPgDIAAAAQASgDAZAFIAAAAQAVAFAWgBIAAAAQAZgBATACIAiAEQARACASgGIABAAQAWgHAWADQAEABACADQACADAAADIAAACQAAAEgEACQgDADgEgBQgSgDgSAGIAAAAQgRAFgSAAIgHAAgAsWiKIAAAAQgWgHgWACIgiAEQgEABgDgDQgEgCAAgEIgBgCQAAgDACgDQACgDAFgBIAkgEQAZgCAaAIIAAAAQAUAGALgFIAAAAQAQgIAXAAIAAAAQAWAAASADQAPADAZAAQAYABAUgCQAEAAADADQADACAAAEIAAABQAAAEgCADQgDADgEAAQgUACgagBQgaAAgRgEQgQgCgTAAQgSAAgNAGIgBAAQgIAEgLAAQgMAAgOgEgAIaiGQgWAAgVgHQgRgGgOAEIAAAAQgSAFgbgBQgEAAgDgDQgDgDAAgEIAAAAQAAgEAEgDQADgDAEAAQAXABAPgEIABgBQATgFAXAIQASAGATAAQAUAAATgCIAAAAIAogDIABAAIAoAAIAAAAQATABAQgCQATgDAbACQAZACAUADIABAAQAQADAPgFQAEgCADACQAEACACAEIAAADIgBAEQgBAEgEABQgUAIgWgEIAAAAQgTgDgZgCQgYgCgRADQgSACgUgBIgoAAIgnADQgUACgVAAIAAAAgAFjiJQgSgDgXABIAAAAQgYABgVgCQgTgBgLABQgMABgagBQgXgCgUACQgUACgVgBQgEAAgDgDQgDgDAAgEIAAAAQABgEADgDQADgDAEAAQATABATgCQAVgCAZACQAYABALgBIAAAAQAMgBAVABQAUACAXgBIABAAQAZgBATAEIAAAAQARADAUgFQADgCAEACQAEACABAEIAAADIgBAFQgCAEgEABQgPAEgOAAQgIAAgIgCgAOZiKIgpgGIAAABQgRgDgRAGQgEACgEgCQgDgBgCgEIgBgEIABgEQACgEAEgBQAWgJAWAEIABAAIAnAFQATACAUgBIAAAAIAogCIAAAAQAUAAAQgCIABAAQATgCAZACQAXADAQgEIABAAQAUgEAXAIQADABACAEIABAEIAAADQgCAEgDACQgEACgEgBQgRgGgQADQgTAEgagDQgXgCgRACQgSACgUAAIgoACIAAAAIgSAAIgYgBgAj8iJIgpgBIgjgBIgogCIAAAAQgTgBgUADQgVACgVgDQgTgCgQABIgBAAQgTACgYgEIAAAAQgTgDgRAGQgEACgEgCQgDgBgCgEIgBgEIABgEQACgEAEgBQAVgJAZAEIABAAQAVAEAQgCIABAAQATgBAUACIAAAAQATADATgCQAVgDAVABIAAAAIAoACIAiABIAqABQAYABASgDQAEAAADACQADADABAEIAAABQAAADgCADQgCADgEABQgNACgRAAIgQAAg");
	this.shape.setTransform(211.8697,59.3831);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,204,0,0.8)").s().p("ASgCVIALgBQAMgCAGgEIAAAHgAOJCVIgBgDQgBgEgEgCQgXgKgYAEQgSAEgUgCQgWgCgWADQgUACgQgCQgSgCgXACQgWACgSAFIAAAAQgOAEgVgIQgEgCgDACQgEABgCAEIAAAEIgEAAQABgDgDgDQgCgDgEgBQgPgCgYABIAAAAQgVABgVAAIAAAAQgWgBgSgDIgBAAQgVgDgVADQgSADgWAAQgYgCgRACIAAAAQgOACgWgBQgEAAgDADQgDACAAAFIAAAAIgDAAIAAgBQgBgEgDgDQgEgCgEAAQgTACgSgCIgkgFQgTgEgaAFQgVAFgQgBIgBAAIgrAAQgEAAgDADQgDADAAAEIgCAAIgBgEQgCgEgEgBQgOgHgZACIgBAAQgVADgVABIgvAAQgXAAgQgCIAAAAQgRgCgVAEQgQADgSgFIAAAAQgWgFgVAEQgRADgWAAIgBAAQgWgBgTgCQgVgDgUAHQgEABgCADIgCAFIgCAAIgBgDQgBgEgEgCQgEgCgEACQgSAFgUgDQgXgDgTACIAAAAIgkAFIAAAAQgQACgQgEIAAAAQgTgGgZACIAAAAQgUADgXgEQgEAAgDACQgEACAAAEIAAACIgDAAIgBgDQgBgEgDgCQgEgCgEABQgaAHgPABQgOgBgTgHQgXgKgYAGIgBAAQgUAGgSABQgRABgXgEQgagEgRACIglAGIgBAAQgRAEgPgHQgEgCgEACQgEABgBAEIgBAEIgCAAQAAgEgDgDQgDgDgEAAQgPgBgYADQgUADgPgCIgBAAQgQgDgaADQgWAEgUgEIgBAAQgXgFgTACQgEAAgCADQgDADAAAEIgCAAQgBgEgCgDQgKgLgPgJIAAAAQgHgGACgTIAAAAIAGgpQACgQgDgYQgDgUAAgUQAAgWgDgSQgCgQAEgUQAEgRAAgQQALACAQgEIABAAQAWgEARACIAAAAQATACAZgCIAqgCIAhAAIAAAAIApABIAAAAQAXAAAUgBQATAAAUABQAEAAADgCQADgDAAgEIAAgBIAEAAIAAACQAAAEAEACQADADAEgBIAigEQAWgCAWAHIAAAAQAdAIARgIIAAAAQANgGASgBQAUAAAPADQARADAaABQAaABAUgCQAEAAADgDQADgDAAgEIABAAIABAEQACAEAEABQADACAEgCQARgGAUADIgBAAQAZAEASgCIABAAQARgBASACQAVADAVgCQAUgDATABIAAAAIAoACIAkABIAoAAQAbACATgDQAEgBACgDQACgDAAgDIAEAAQAAAEACADQADADAFAAQAXAAARgDIgBAAQAQgCAUAEQAYAFAZgCIAAAAQAWAAARACIAkAEQAVACAWgIIgBAAQASgFASADQAEABAEgDQADgCABgFIAAgBIACAAQAAAEADADQADADAEAAQAVABAUgCQAUgCAYACQAZABAMgBQALgBATABQAVACAYgBIAAAAQAXgBASADQAVAFAYgHQAEgCACgDIACgFIACAAQAAAEACADQADADAEAAQAcABARgGIAAABQAOgEARAGQAVAHAWgBQAVABAUgDIAngCIAoAAQAUABATgCQAQgDAYACQAZACATADIAAAAQAXAEATgIQAEgBABgEIACgEIADAAIAAADQACAEAEACQADACAEgCQARgGARACIAAAAIAqAGQAUACAVgCIAAAAIAogBQAUAAASgCQARgCAXACQAaADAUgEQAPgDARAGQAEABAEgCQAEgCABgEIABgDIACAAIACAFQACAEAEABQASAEAGAIIAAAAQAFAKgDARQgDAVgFASQgFATAAAXIAAAAIACAqQACAUAEAVQADARgDATQgBAEACADQADAEAEABIABAAIAAADIgBAAQgEABgDADIgBAFQgEACgIABQgWACgUAHIAAAAQgQAGgMgCIAAAAQgPgCgaAAIAAAAIgvACIgBAAQgUACgTgCIgngEIAAAAQgTgDgWAFQgEABgCAEQgCACAAADgAy8CVIAAgKIAAAAIAAAAQAIAFAGAFgAS8iUIABAAIAAABIgBgBg");
	this.shape_1.setTransform(211.85,59.3);

	this.back = new lib.back();
	this.back.name = "back";
	this.back.setTransform(371.45,309.3);
	new cjs.ButtonHelper(this.back, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance},{t:this.text_1,p:{y:55.4}}]},409).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance},{t:this.text_1,p:{y:56.25}},{t:this.back}]},98).to({state:[]},1).wait(51));

	// Happy_Ending
	this.text_2 = new cjs.Text("Friends are the ones who may fight sometimes, but always reach out for help while needed.", "14px 'MV Boli'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.lineWidth = 338;
	this.text_2.parent = this;
	this.text_2.setTransform(210.8,254.45);

	this.instance_1 = new lib.资源544();
	this.instance_1.setTransform(208,119,0.3074,0.3244);

	this.instance_2 = new lib.ClipGroup_13();
	this.instance_2.setTransform(169.3,189.75,0.3082,0.308,7.194,0,0,163,211.1);

	this.instance_3 = new lib.bestfriend("synched",0);
	this.instance_3.setTransform(207.35,74.7,1,1,0,0,0,0,-14.9);

	this.back2 = new lib.back2();
	this.back2.name = "back2";
	this.back2.setTransform(365.4,286.8,1,1,0,0,0,0,-7.4);
	new cjs.ButtonHelper(this.back2, 0, 1, 2, false, new lib.back2(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.text_2}]},508).to({state:[{t:this.instance_3},{t:this.back2}]},50).wait(1));

	// firework
	this.instance_4 = new lib.kisspngfireworksroyaltyfreestockphotographybloomoffireworks5aa185cbca38163751245815205349878283();
	this.instance_4.setTransform(0,103,0.3871,0.3316);

	this.text_3 = new cjs.Text("Friends are the ones who may fight sometimes, but always reach out for help while needed.", "14px 'MV Boli'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.lineWidth = 338;
	this.text_3.parent = this;
	this.text_3.setTransform(210.8,247.05);

	this.instance_5 = new lib.资源544();
	this.instance_5.setTransform(208,115,0.3074,0.3244);

	this.instance_6 = new lib.ClipGroup_13();
	this.instance_6.setTransform(169.3,185.75,0.3082,0.308,7.194,0,0,163,211.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4,p:{x:0,y:103}}]},508).to({state:[]},8).to({state:[{t:this.instance_4,p:{x:3,y:58}}]},8).to({state:[]},9).to({state:[{t:this.instance_4,p:{x:3,y:24}}]},9).to({state:[]},9).to({state:[{t:this.instance_4,p:{x:3,y:0}},{t:this.instance_6},{t:this.instance_5},{t:this.text_3}]},7).wait(1));

	// TEXT
	this.yes = new lib.Yes();
	this.yes.name = "yes";
	this.yes.setTransform(161.85,85.4);
	new cjs.ButtonHelper(this.yes, 0, 1, 2, false, new lib.Yes(), 3);

	this.no = new lib.No();
	this.no.name = "no";
	this.no.setTransform(276.95,75.2,1,1,0,0,0,0.5,-10.2);
	new cjs.ButtonHelper(this.no, 0, 1, 2, false, new lib.No(), 3);

	this.text_4 = new cjs.Text("", "12px 'MVBoli'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 100;
	this.text_4.parent = this;
	this.text_4.setTransform(523.65,82.55);

	this.text_5 = new cjs.Text("OR", "12px 'MV Boli'", "#FF0000");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 43;
	this.text_5.parent = this;
	this.text_5.setTransform(219,67.65);

	this.text_6 = new cjs.Text("Saving Your Friend!", "16px 'MV Boli'", "#FF0000");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 28;
	this.text_6.lineWidth = 161;
	this.text_6.parent = this;
	this.text_6.setTransform(219.65,37.85);

	this.instance_7 = new lib.pngfindcommessagebubblepng632891();
	this.instance_7.setTransform(332,23,0.2817,0.2816,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.no},{t:this.yes}]},408).to({state:[]},1).wait(150));

	// crying_boy
	this.instance_8 = new lib.补间30("synched",0);
	this.instance_8.setTransform(384.25,195.9);
	this.instance_8._off = true;

	this.instance_9 = new lib.补间31("synched",0);
	this.instance_9.setTransform(283.25,195.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},383).to({state:[{t:this.instance_9,p:{scaleX:1,scaleY:1,y:195.9}}]},15).to({state:[{t:this.instance_9,p:{scaleX:1.1463,scaleY:1.1463,y:206.8}}]},11).to({state:[]},99).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(383).to({_off:false},0).to({_off:true,x:283.25},15).wait(161));

	// trap_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_378 = new cjs.Graphics().p("AFWWyQidg3gYh3QgZh2B7hxQB8hxCTkpQCSkoDEAHQDEAHBMF3QBMF2iiChQijChjFAoQhUARhNAAQhoAAhbgfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(378).to({graphics:mask_graphics_378,x:116.799,y:148.9494}).wait(181));

	// boy_scene4
	this.instance_10 = new lib.boyrun1("synched",0);
	this.instance_10.setTransform(274.05,219.4,1,1,0,0,0,0,-77.4);
	this.instance_10._off = true;

	this.instance_11 = new lib.Bitmap6();
	this.instance_11.setTransform(121,204,0.1476,0.1475);

	var maskedShapeInstanceList = [this.instance_10,this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},363).to({state:[{t:this.instance_11}]},15).to({state:[]},31).wait(150));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(363).to({_off:false},0).to({_off:true,regY:0,scaleX:0.1476,scaleY:0.1475,x:121,y:204},15).wait(181));

	// soilmask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_361 = new cjs.Graphics().p("AFtWyQidg3gYh3Qgah2B8hxQB8hxDGgpQDGgoCdA4QCdA3AZB1QAYB3h7BxQh8ByjFAnQhVARhNAAQhoAAhagfg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(361).to({graphics:mask_1_graphics_361,x:114.5331,y:148.9494}).wait(198));

	// soil
	this.instance_12 = new lib.soil();
	this.instance_12.setTransform(104.65,241.4,0.0211,0.0192,-12.7015);
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(361).to({_off:false},0).to({_off:true},48).wait(150));

	// boy_scene3
	this.instance_13 = new lib.PuppetShape_8复制("synched",1,false);
	this.instance_13.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_13._off = true;

	this.instance_14 = new lib.PuppetShape_7复制8("synched",1,false);
	this.instance_14.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);

	this.movieClip_5 = new lib.元件2();
	this.movieClip_5.name = "movieClip_5";
	this.movieClip_5.setTransform(151.5,218.45);
	this.movieClip_5._off = true;

	this.instance_15 = new lib.boyrun1("synched",0);
	this.instance_15.setTransform(147.65,218.6,1,1,0,0,0,0,-77.4);
	this.instance_15._off = true;

	this.instance_16 = new lib.boyrun2("synched",0);
	this.instance_16.setTransform(157.3,217.2,1,1,0,0,0,0,-72.8);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_13}]},269).to({state:[{t:this.instance_14}]},9).to({state:[{t:this.movieClip_5}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},5).to({state:[{t:this.instance_15}]},5).to({state:[{t:this.instance_16}]},4).to({state:[]},1).wait(196));
	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(269).to({_off:false},0).to({_off:true},9).wait(281));
	this.timeline.addTween(cjs.Tween.get(this.movieClip_5).wait(283).to({_off:false},0).to({_off:true,regY:-77.4,x:147.65,y:218.6,mode:"synched",startPosition:0},5).wait(271));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(283).to({_off:false},5).to({_off:true,regY:-72.8,x:157.3,y:217.2},5).to({_off:false,regY:-77.4,x:200,y:219.2},5).to({_off:true,regY:-72.8,x:210,y:217.2},5).to({_off:false,regY:-77.4,x:220,y:219.2},5).to({_off:true,regY:-72.8,x:230,y:217.2},5).to({_off:false,regY:-77.4,x:235,y:219.2},5).to({_off:true,regY:-72.8,x:240,y:217.2},5).to({_off:false,regY:-77.4,x:250,y:219.2},5).to({_off:true,regY:-72.8,x:255,y:217.2},5).to({_off:false,regY:-77.4,x:260,y:219.2},5).to({_off:true,regY:-72.8,x:265,y:217.2},5).to({_off:false,regY:-77.4,x:275,y:219.2},5).to({_off:true,regY:-72.8,x:280,y:217.2},5).to({_off:false,regY:-77.4,x:285,y:219.2},5).to({_off:true,regY:-72.8,x:290,y:217.2},4).wait(197));
	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(288).to({_off:false},5).to({_off:true,regY:-77.4,x:200,y:219.2},5).to({_off:false,regY:-72.8,x:210,y:217.2},5).to({_off:true,regY:-77.4,x:220,y:219.2},5).to({_off:false,regY:-72.8,x:230,y:217.2},5).to({_off:true,regY:-77.4,x:235,y:219.2},5).to({_off:false,regY:-72.8,x:240,y:217.2},5).to({_off:true,regY:-77.4,x:250,y:219.2},5).to({_off:false,regY:-72.8,x:255,y:217.2},5).to({_off:true,regY:-77.4,x:260,y:219.2},5).to({_off:false,regY:-72.8,x:265,y:217.2},5).to({_off:true,regY:-77.4,x:275,y:219.2},5).to({_off:false,regY:-72.8,x:280,y:217.2},5).to({_off:true,regY:-77.4,x:285,y:219.2},5).to({_off:false,regY:-72.8,x:290,y:217.2},4).to({_off:true},1).wait(196));

	// smoke
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#EAEAEA").s().p("AjLBIQhUgdgBgrQABgpBUgfQBUgdB3AAQB3AABVAdQBUAfAAApQAAArhUAdQhVAeh3AAQh3AAhUgeg");
	this.shape_2.setTransform(254.7466,33.8043,0.7019,0.4019);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(234,234,234,0.965)").s().p("AAAAyQhSgBg8gQQg9gQACgUQACgWBAgNQBAgOBSADQBUADA3AUQA3AUgDASQgCATg7AKQg2AJhJAAIgOAAg");
	this.shape_3.setTransform(254.2295,32.5273);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(234,234,234,0.933)").s().p("AAAA8QhRgCg+gUQg+gVAEgYQADgaBGgPQBFgPBSAGQBSAGAzAcQAzAbgFAVQgFAVg7AIQgxAGhAAAIgZAAg");
	this.shape_4.setTransform(253.7378,31.2392);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(234,234,234,0.898)").s().p("AgBBFQhPgCg/gZQhAgYAGgdQAFgeBLgRQBKgRBRAKQBRAJAvAkQAwAigIAXQgIAYg6AFQgpAEgxAAIgvgBg");
	this.shape_5.setTransform(253.2359,29.9438);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(234,234,234,0.867)").s().p("AgCBPQhNgEhBgcQhBgdAHghQAIgjBPgSQBQgSBPAMQBRANArArQArArgKAZQgKAZg7ADQgfACgkAAIhDgBg");
	this.shape_6.setTransform(252.7594,28.6422);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(234,234,234,0.831)").s().p("AgCBYQhMgEhCghQhDghAJgmQAJgmBVgUQBVgUBPAPQBPAQAnAzQAoAzgNAbQgNAbg6ABIghABQgtAAg2gDg");
	this.shape_7.setTransform(252.2823,27.3821);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(234,234,234,0.8)").s().p("AB/BmQg6gBhJgFQhKgFhDglQhEglALgqQALgrBagVQBZgWBOATQBPATAjA7QAjA6gPAeQgPAcg2AAIgEAAg");
	this.shape_8.setTransform(251.8172,26.181);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(234,234,234,0.765)").s().p("AB8BxIiBgJQhIgGhFgpQhFgpAMguQANgwBfgXQBfgXBNAWQBOAWAfBDQAfBCgSAgQgRAcgxAAIgJAAg");
	this.shape_9.setTransform(251.3814,25.0005);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(234,234,234,0.733)").s().p("AB4B8Ih+gMQhHgGhGgtQhHgtAPgzQAOg0BkgYQBjgZBNAZQBNAZAbBLQAbBKgUAhQgSAdgsAAIgQgBg");
	this.shape_10.setTransform(250.9687,23.8388);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(234,234,234,0.698)").s().p("AB1CHIh9gPQhFgHhIgxQhIgxARg3QAQg5BpgaQBogaBMAcQBMAcAXBTQAYBSgXAjQgUAegpAAIgTgCg");
	this.shape_11.setTransform(250.565,22.6711);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(234,234,234,0.667)").s().p("ABxCSQg4gKhDgIQhDgIhJg1QhJg2ASg7QASg9BugbQBtgcBLAfQBMAfATBbQATBagaAlQgVAegnAAQgKAAgMgCg");
	this.shape_12.setTransform(250.1776,21.5122);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(234,234,234,0.631)").s().p("ABtCeQg4gNhBgIQhCgJhKg6QhLg5AUhAQAUhBB0geQBygdBKAjQBLAhAPBkQAPBigdAnQgWAegmAAQgLAAgNgCg");
	this.shape_13.setTransform(249.822,20.3498);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(234,234,234,0.6)").s().p("ABpCoQg4gOg/gJQhAgKhMg9QhMg+AWhEQAVhGB5gfQB3gfBKAmQBJAlALBrQALBqgeApQgYAfglAAQgMAAgOgEg");
	this.shape_14.setTransform(249.4825,19.1767);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(234,234,234,0.565)").s().p("ABkCzQg3gQg9gKQg/gLhNhBQhOhCAYhJQAXhKB+ggQB8ghBJApQBJAoAHBzQAHBygiArQgYAggkAAQgOAAgPgFg");
	this.shape_15.setTransform(249.1871,18.0361);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(234,234,234,0.533)").s().p("ABfC+Qg3gSg8gLQg9gLhOhGQhPhHAZhMQAZhOCDgiQCCgjBIAsQBHAsADB6QADB6gjAtQgaAhgjAAQgPAAgQgGg");
	this.shape_16.setTransform(248.9098,16.8843);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(234,234,234,0.498)").s().p("ACAH1QhOgzhTgeQhVgehyi5Qhyi5AnjLQAmjNDChZQDAhZBlB1QBlB0gBFFQgCFEg3B2QgmBSgyAAQgVAAgYgPg");
	this.shape_17.setTransform(248.6856,15.7273,0.7019,0.4019);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(234,234,234,0.498)").s().p("ABdDLQg4gXg6gMQg7gMhQhJQhRhIAZhUQAZhVCIgjQCGgkBHAvQBGAwADCEQACCEgmAwQgaAggiAAQgQAAgSgHg");
	this.shape_18.setTransform(247.8865,12.8856);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(234,234,234,0.498)").s().p("ABgDLQg5gZg6gMQg8gMhQhGQhQhHAWhWQAWhYCIgjQCHgkBGAwQBGAwAGCHQAGCGgmAwQgZAfghAAQgRAAgTgJg");
	this.shape_19.setTransform(247.144,10.0505);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(234,234,234,0.498)").s().p("ABiDNQg6gcg6gMQg7gMhRhEQhQhFAUhZQAUhaCIgkQCHgkBFAyQBFAxAKCIQAKCJgmAwQgYAeggAAQgSAAgVgKg");
	this.shape_20.setTransform(246.388,7.1929);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(234,234,234,0.498)").s().p("ABkDOQg6geg6gMQg8gMhQhDQhRhEAShbQAShcCIgkQCGgkBFAzQBFAyANCKQAOCLgmAwQgXAegfAAQgTAAgXgMg");
	this.shape_21.setTransform(245.6474,4.3646);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(234,234,234,0.498)").s().p("ABmDPQg7ghg6gMQg8gMhQhBQhRhBAPheQAQhfCIgjQCGgkBFAzQBEAzARCMQARCNglAwQgWAdgfAAQgUAAgYgNg");
	this.shape_22.setTransform(244.9181,1.5322);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(234,234,234,0.498)").s().p("ABoDQQg8gjg6gMQg8gMhRg/QhQhAANhgQANhhCIgkQCGgkBEA0QBEA0AVCOQAUCPglAxQgVAcgdAAQgWAAgZgPg");
	this.shape_23.setTransform(244.2251,-1.3028);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(234,234,234,0.498)").s().p("ABqDRQg9glg6gMQg8gMhRg+QhRg+ALhiQALhkCIgkQCGgkBEA1QBDA0AYCRQAYCRgkAxQgVAbgcAAQgWAAgbgQg");
	this.shape_24.setTransform(243.5103,-4.1193);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(234,234,234,0.498)").s().p("ABsDSQg+gog6gMQg8gMhRg7QhRg8AJhmQAIhmCIgkQCHgkBCA2QBDA1AcCTQAcCTgkAyQgUAagcAAQgXAAgcgSg");
	this.shape_25.setTransform(242.8221,-6.966);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(234,234,234,0.498)").s().p("ABuDTQg/gqg6gMQg8gMhRg6QhRg6AGhoQAGhpCIgkQCHgkBCA3QBCA2AfCVQAgCVgkAyQgTAagbAAQgXAAgegUg");
	this.shape_26.setTransform(242.1165,-9.779);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(234,234,234,0.498)").s().p("ABwDUQhAgsg6gMQg8gMhRg4QhRg5AEhqQADhsCIgjQCHgkBBA3QBCA3AjCXQAjCYgjAxQgTAagaAAQgYAAgfgWg");
	this.shape_27.setTransform(241.4344,-12.6061);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(234,234,234,0.498)").s().p("AByDVQhBgvg6gMQg8gMhRg2QhSg3AChtQABhuCIgjQCHgkBBA4QBBA3AnCZQAmCagjAyQgSAZgaAAQgYAAgggXg");
	this.shape_28.setTransform(240.7309,-15.4288);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(234,234,234,0.498)").s().p("AB0DWQhCgyg6gMQg8gMhRg0QhSg1gBhvQgBhxCIgjQCHgkBBA5QBAA4AqCbQArCcgjAyQgSAZgZAAQgZAAghgZg");
	this.shape_29.setTransform(240.015,-18.2405);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(234,234,234,0.498)").s().p("AB2DXQhDg0g6gMQg8gMhRgzQhSgzgDhyQgDhzCIgjQCGgkBAA6QBAA5AuCdQAuCfgjAyQgQAYgZAAQgaAAgigbg");
	this.shape_30.setTransform(239.311,-21.0823);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(234,234,234,0.498)").s().p("AB4DYQhEg3g6gMQg8gMhSgwQhRgygGh0QgFh2CIgjQCGgkBAA7QA/A6AyCfQAxCggiAzQgRAYgYAAQgaAAgjgdg");
	this.shape_31.setTransform(238.6228,-23.8916);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(234,234,234,0.498)").s().p("ACtIcQhhiNhUgeQhUgeh1h2Qh1h2gLkpQgLkrDBhZQDBhYBaCTQBZCUBMGTQBLGUgwB9QgXA7giAAQgmAAg0hMg");
	this.shape_32.setTransform(237.9031,-26.7152,0.7019,0.4019);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},98).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[]},281).wait(150));

	// boy_scene2
	this.instance_17 = new lib.PuppetShape_8复制2("synched",1,false);
	this.instance_17.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_17._off = true;

	this.instance_18 = new lib.PuppetShape_8复制3("synched",1,false);
	this.instance_18.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_18._off = true;

	this.instance_19 = new lib.PuppetShape_8复制5("synched",1,false);
	this.instance_19.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);

	this.movieClip_4 = new lib.元件1();
	this.movieClip_4.name = "movieClip_4";
	this.movieClip_4.setTransform(169.5,218.45);

	this.instance_20 = new lib.PuppetShape_15复制("synched",1,false);
	this.instance_20.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_20._off = true;

	this.instance_21 = new lib.PuppetShape_8复制6("synched",1,false);
	this.instance_21.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_21._off = true;

	this.instance_22 = new lib.PuppetShape_12复制4("synched",1,false);
	this.instance_22.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_22._off = true;

	this.instance_23 = new lib.PuppetShape_13复制4("synched",1,false);
	this.instance_23.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_23._off = true;

	this.instance_24 = new lib.PuppetShape_9复制4("synched",1,false);
	this.instance_24.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);
	this.instance_24._off = true;

	this.instance_25 = new lib.PuppetShape_8复制12("synched",1,false);
	this.instance_25.setTransform(160.5,218.5,0.1221,0.1221,0,0,0,487.4,626.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},78).to({state:[{t:this.instance_18}]},20).to({state:[{t:this.instance_19}]},30).to({state:[]},1).to({state:[{t:this.movieClip_4}]},59).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},19).to({state:[{t:this.instance_22}]},15).to({state:[{t:this.instance_23}]},15).to({state:[{t:this.instance_24}]},15).to({state:[{t:this.instance_25}]},15).to({state:[]},1).wait(290));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(78).to({_off:false},0).to({_off:true},20).wait(461));
	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(78).to({_off:false},20).to({_off:true},30).wait(431));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(189).to({_off:false},0).to({_off:true},19).wait(351));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(189).to({_off:false},19).to({_off:true},15).wait(336));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(208).to({_off:false},15).to({_off:true},15).wait(321));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(223).to({_off:false},15).to({_off:true},15).wait(306));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(238).to({_off:false},15).to({_off:true},15).wait(291));

	// nbmask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_188 = new cjs.Graphics().p("APDShQichagxirQgyiqBYiXQBXiYCtgsQCrgpCdBaQCcBaAyCqQAxCrhYCYQhYCXirAqQg4AOg2AAQhxAAhqg9g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(188).to({graphics:mask_2_graphics_188,x:160.7495,y:124.6054}).wait(371));

	// nauthyboy_crying
	this.instance_26 = new lib.PuppetShape_16复制("synched",1,false);
	this.instance_26.setTransform(277.4,224,0.201,0.201,0,0,0,121.4,199);
	this.instance_26._off = true;

	this.instance_27 = new lib.PuppetShape_16复制2("synched",1,false);
	this.instance_27.setTransform(277.4,224,0.201,0.201,0,0,0,121.4,199);
	this.instance_27._off = true;

	this.instance_28 = new lib.PuppetShape_16复制3("synched",1,false);
	this.instance_28.setTransform(277.4,224,0.201,0.201,0,0,0,121.4,199);
	this.instance_28._off = true;

	this.instance_29 = new lib.PuppetShape_16复制4("synched",1,false);
	this.instance_29.setTransform(277.4,224,0.201,0.201,0,0,0,121.4,199);
	this.instance_29._off = true;

	this.instance_30 = new lib.PuppetShape_16复制7("synched",1,false);
	this.instance_30.setTransform(277.4,224,0.201,0.201,0,0,0,121.4,199);

	var maskedShapeInstanceList = [this.instance_26,this.instance_27,this.instance_28,this.instance_29,this.instance_30];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},208).to({state:[{t:this.instance_27}]},15).to({state:[{t:this.instance_28}]},15).to({state:[{t:this.instance_29}]},15).to({state:[{t:this.instance_30}]},15).to({state:[]},16).wait(275));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(208).to({_off:false},0).to({_off:true},15).wait(336));
	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(208).to({_off:false},15).to({_off:true},15).wait(321));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(223).to({_off:false},15).to({_off:true},15).wait(306));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(238).to({_off:false},15).to({_off:true},15).wait(291));

	// nauthyboy2
	this.instance_31 = new lib.资源33x1();
	this.instance_31.setTransform(252,182,0.2732,0.2733);
	this.instance_31._off = true;

	var maskedShapeInstanceList = [this.instance_31];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(188).to({_off:false},0).to({_off:true},20).wait(351));

	// TEXT1
	this.text_7 = new cjs.Text("GET THROUGH THE WALL NOW!", "12px 'MV Boli'", "#FF0000");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 18;
	this.text_7.lineWidth = 261;
	this.text_7.parent = this;
	this.text_7.setTransform(200.3,75.45);

	this.instance_32 = new lib.pngfindcommessagebubblepng632891png复制();
	this.instance_32.setTransform(319.25,56,0.2986,0.2047,0,0,180);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_32},{t:this.text_7}]},187).to({state:[]},1).wait(371));

	// ring
	this.ringbutton = new lib.ring();
	this.ringbutton.name = "ringbutton";
	this.ringbutton.setTransform(254.75,33.8,1,1,0,0,0,0,-4.1);
	this.ringbutton._off = true;
	new cjs.ButtonHelper(this.ringbutton, 0, 1, 2, false, new lib.ring(), 3);

	this.button_3 = new lib.ring();
	this.button_3.name = "button_3";
	this.button_3.setTransform(214.05,175.25,1,1,29.9984,0,0,0.1,-4);
	new cjs.ButtonHelper(this.button_3, 0, 1, 2, false, new lib.ring(), 3);

	this.movieClip_6 = new lib.元件3();
	this.movieClip_6.name = "movieClip_6";
	this.movieClip_6.setTransform(213.95,175.05);
	new cjs.ButtonHelper(this.movieClip_6, 0, 1, 1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#000000").ss(1,1,1).p("AEgAAQAAAqhUAeQhVAeh3AAQh2AAhVgeQhUgeAAgqQAAgqBUgeQBVgdB2AAQB3AABVAdQBUAeAAAqg");
	this.shape_33.setTransform(213.9733,175.0572,0.7019,0.4018,29.9988);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-28.8,0,28.9,0).s().p("AjLBIQhUgdgBgrQABgpBUgfQBUgdB3AAQB3AABVAdQBUAfAAApQAAArhUAdQhVAeh3AAQh3AAhUgeg");
	this.shape_34.setTransform(213.9733,175.0572,0.7019,0.4018,29.9988);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#000000").ss(1,1,1).p("AiwhXQAGgVA4AMQA4AMBIAkQBJAlAxAnQAvApgGAUQgGAUg4gMQg4gLhJglQhJglgvgnQgwgoAGgUg");
	this.shape_35.setTransform(213.9558,175.0283);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-26.7,10.6,17.3,6.9).s().p("ABzBhQg4gLhJglQhJglgvgnQgwgoAGgUQAGgVA4AMQA4AMBIAkQBJAlAxAnQAvApgGAUQgEAMgYAAQgNAAgVgEg");
	this.shape_36.setTransform(213.9558,175.0283);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#000000").ss(1,1,1).p("AiyhKQAEgaA3ADQA2AFBJAfQBKAgAyAmQAyApgDAaQgEAag2gEQg4gEhJggQhJgfgygoQgygoADgZg");
	this.shape_37.setTransform(213.953,175.0314);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-35.8,31.4,17.1,3.8).s().p("AB5BiQg4gEhJggQhJgfgygoQgygoADgZQAEgaA3ADQA2AFBJAfQBKAgAyAmQAyApgDAaQgDAWgpAAIgOAAg");
	this.shape_38.setTransform(213.953,175.0314);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#000000").ss(1,1,1).p("Ai0g+QACgfA1gEQA1gDBKAaQBKAaA1AoQA0AogBAfQgBAfg1AEQg2AEhJgbQhLgag0goQg1goABgfg");
	this.shape_39.setTransform(213.95,175.0305);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-45,52.1,16.9,0.6).s().p("AgBBLQhLgag0goQg0goABgfQABgfA2gEQA1gDBJAaQBLAaA0AoQA1AogBAfQgBAfg1AEIgPAAQgxAAhAgXg");
	this.shape_40.setTransform(213.95,175.0305);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#000000").ss(1,1,1).p("Ai1gxQgBglA0gLQA0gLBLAUQBKAVA3ApQA3AoABAkQACAlg0ALQg1AMhLgVQhKgVg2gpQg3gogCgkg");
	this.shape_41.setTransform(213.95,175.0364);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-54.2,72.9,16.7,-2.6).s().p("AAEBZQhLgVg1gpQg3gogCgkQgCglA0gLQA0gLBMAUQBKAVA3ApQA2AoACAkQACAlg1ALQgSAEgVAAQgoAAgwgNg");
	this.shape_42.setTransform(213.95,175.0364);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#000000").ss(1,1,1).p("Ai3gkQgEgqAzgUQAzgSBMAPQBLAQA5AoQA5ApAEAqQAEAqgzATQgzAThMgQQhLgQg4gpQg5gogFgpg");
	this.shape_43.setTransform(213.9287,175.0374);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-63.3,93.6,16.5,-5.7).s().p("AAKBmQhLgQg4gpQg5gogFgpQgEgqAzgUQAzgSBMAPQBLAQA5AoQA5ApAEAqQAEAqgzATQgbAKgkAAQgdAAgjgHg");
	this.shape_44.setTransform(213.9287,175.0374);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#000000").ss(1,1,1).p("Ai4gYQgHgvAxgbQAygaBNAKQBMAKA7ApQA7ApAHAvQAGAwgxAaQgyAbhNgLQhLgKg7gpQg7gpgHgvg");
	this.shape_45.setTransform(213.95,175.037);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-72.5,114.3,16.3,-9).s().p("AAQBzQhMgKg7gpQg6gpgIgvQgGgvAygbQAxgaBNAKQBMAKA6ApQA7ApAHAvQAHAwgxAaQgkATgyAAQgTAAgWgDg");
	this.shape_46.setTransform(213.95,175.037);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#000000").ss(1,1,1).p("Ai6gLQgJg1AwgiQAwgjBNAFQBNAGA+ApQA9ApAJA0QAJA1gwAiQgwAjhOgGQhMgFg9gpQg+gpgJg0g");
	this.shape_47.setTransform(213.95,175.0062);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-81.7,135,16.1,-12.2).s().p("AAWCAQhNgFg8gpQg+gpgJg0QgJg1AwgiQAwgjBNAFQBNAGA+ApQA8ApAKA0QAJA1gwAiQgqAeg/AAIgVgBg");
	this.shape_48.setTransform(213.95,175.0062);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#000000").ss(1,1,1).p("Ai8ABQgLg6AvgqQAvgqBOAAQBNAAA/ApQBAAqAMA6QAMA6gvAqQgvAqhPgBQhNABg/gqQhAgpgMg6g");
	this.shape_49.setTransform(213.934,175.0003);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-90.8,155.8,15.9,-15.3).s().p("AhwBkQhAgpgMg6QgLg6AvgqQAvgqBOAAQBNAAA/ApQBAAqAMA6QAMA6gvAqQgvAqhPAAIgCAAQhMAAg+gqg");
	this.shape_50.setTransform(213.934,175.0003);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#000000").ss(1,1,1).p("Ai9ANQgOg+AtgyQAugyBPgFQBNgFBCApQBCAqAOA/QAPBAguAxQguAyhOAFQhOAFhCgpQhCgqgOhAg");
	this.shape_51.setTransform(213.9355,175.005);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-100,176.5,15.7,-18.5).s().p("AhtB3QhCgqgOhAQgOg+AtgyQAugyBPgFQBNgFBCApQBCAqAOA/QAPBAguAxQguAyhOAFIgTABQhDAAg6glg");
	this.shape_52.setTransform(213.9355,175.005);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#000000").ss(1,1,1).p("Ai/AaQgRhEAsg5QAtg5BQgLQBOgLBEAqQBEAqARBFQARBFgtA5QgsA5hPAKQhPALhEgpQhEgqgRhGg");
	this.shape_53.setTransform(213.9231,174.9852);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-109.2,197.3,15.4,-21.6).s().p("AhqCKQhEgqgRhGQgRhEAsg5QAtg5BQgLQBOgLBEAqQBEAqARBFQARBFgtA5QgsA5hPAKQgRACgQAAQg8AAg2ggg");
	this.shape_54.setTransform(213.9231,174.9852);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#000000").ss(1,1,1).p("AjBAnQgThKArhBQArhBBQgQQBPgQBGAqQBHAqAUBLQATBLgrBAQgrBBhQAQQhQAQhGgqQhGgqgUhLg");
	this.shape_55.setTransform(213.9226,175);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],-118.4,218.1,15.2,-24.8).s().p("AhnCbQhGgpgUhLQgThKArhAQArhCBQgPQBPgQBGAqQBHApAUBLQATBLgrBAQgrBBhQAPQgWAFgWAAQg3AAgzgfg");
	this.shape_56.setTransform(213.9226,175);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["rgba(157,200,219,0.2)","#FFFFFF"],[0,1],12.7,137.2,-1.5,-16.1).s().p("AjLBIQhUgdgBgrQABgpBUgfQBUgdB3AAQB3AABVAdQBUAfAAApQAAArhUAdQhVAeh3AAQh3AAhUgeg");
	this.shape_57.setTransform(213.916,175.0259,0.7019,1.9716,29.9988);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("rgba(0,0,0,0.933)").ss(1,1,1).p("AjSA/QgEgSAAgSQAAgRAEgSQADgLACgLQADgKAEgKQAHgXAJgXQAFgMAGgJQAFgKAHgJQAHgLAKgJQAJgKALgIQAKgIAMgFQAKgFALgDQAKgDAKgCQAZgFAUgDQAHgBAHgBQAJgBAIAAQAHABAHABQALACAKACQAYAIAUAQQAMAJAIAIQAKAJAJAKQAGAGAGAGQAFAFAFAEQAFAFAFAFQANANAIAPQAJANAGAQQAJAXABAYQACAXgEAaQgFAagKAWQgFALgGAJQgCAEgDAEQgGAJgJAGQgJAJgJAIQgKAHgKAGQgWAOgZAKQgLAFgKAEQgEACgEABQgGACgGADQgPAGgQACQgMADgNAAQgVAAgVgFQgYgFgWgMQgPgHgNgIQgigZgWgkQgPgYgGgbgAjSA+QgFgTABgTQgBgSAFgRQACgJACgIQADgIACgIQAGgVAIgVQAHgQACgFQAEgKAGgJQANgVATgQQAJgJAMgHQAKgHAMgEQAMgFAPgEQADgBAEgBQAMgDALgBQAOgDANgCQAEAAAEgBQAEgBAEAAQAOAAAPADQALACALAEQALAFALAGQAKAFAJAIQADACAEADQAOANANAMQAGAGAGAGQAFAGAHAFQAKAMALAMQAKALAHAPQAFAJAEAKQACAFABAFQAGATABASQACARgCASQgCASgGATQgGAVgKARQgCAEgCADQgCAEgDADQgEAHgGAFQgFAHgHAFQgRANgRAMQgTALgVAJQgLAFgLAEQgGACgFADQgTAHgQAFQgRAEgRAAQgSAAgUgEQgUgEgUgJQgFgCgGgDQgNgHgNgIQgjgZgWgkQgPgYgGgcg");
	this.shape_58.setTransform(214.3546,176.1464);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(157,200,219,0.212)","#FFFFFF"],[0,1],-119,225.6,13.6,-28.6).s().p("Ag7DPQgXgFgXgMQgOgHgNgIQgjgZgVgkQgPgYgGgbQgEgSAAgSQgBgRAEgSIAGgWIAGgUQAHgXAKgXIAKgVIAMgTQAIgLAJgJQAKgKAKgIQALgIAMgFQAKgFALgDIATgFQAZgFAUgDIAPgCQAIgBAJAAIAOACIAUAEQAYAIAUAQIAVARIATATIAMAMIAKAJIAKAKQAMANAJAPQAJANAGAQQAIAXACAYQACAXgFAaQgEAagKAWQgFALgGAJIgGAIQgGAJgIAGIgSARIgUANQgXAOgYAKIgWAJIgHADIgMAFQgQAGgPACQgMADgOAAQgUAAgWgFg");
	this.shape_59.setTransform(214.328,176.1417);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["rgba(153,194,211,0.255)","#F5F5F5"],[0,1],-128,237.6,14.5,-29.2).s().p("Ag3DRQgUgEgUgJIgLgFQgNgHgNgIQgjgZgWgkQgPgYgGgcIAAgBQgFgTABgTQgBgSAFgRIAEgRIAFgQQAGgVAIgVIAJgVQAEgKAGgJQANgVATgQQAJgJAMgHQAKgHAMgEQAMgFAPgEIAHgCIAXgEIAbgFIAIgBIAIgBQAOAAAPADQALACALAEQALAFALAGQAKAFAJAIIAHAFIAbAZIAMAMIAMALIAVAYQAKALAHAPQAFAJAEAKIADAKQAGATABASQACARgCASQgCASgGATQgGAVgKARIgEAHIgFAHIgKAMQgFAHgHAFQgRANgRAMQgTALgVAJIgWAJIgLAFIgjAMQgRAEgRAAQgSAAgUgEgAAAjSIgOACQgUADgZAFIgUAFQgLADgKAFQgMAFgKAIQgLAIgJAKQgKAJgHALIgMATIgLAVQgJAXgHAXIgHAUIgFAWQgEASAAARQAAASAEASQAGAbAPAYQAWAkAiAZQANAIAPAHQAWAMAYAFQAVAFAVAAQANAAAMgDQAQgCAPgGIAMgFIAIgDIAVgJQAZgKAWgOIAUgNIASgRQAJgGAGgJIAFgIQAGgJAFgLQAKgWAFgaQAEgagCgXQgBgYgJgXQgGgQgJgNQgIgPgNgNIgKgKIgKgJIgMgMIgTgTIgUgRQgUgQgYgIIgVgEIgOgCIgFAAIgMABg");
	this.shape_60.setTransform(214.3546,176.1464);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("rgba(0,0,0,0.867)").ss(0.9,1,1).p("AjhBIQgEgUADgUQABgSAHgSQAEgJADgIQADgIADgJQAHgWAGgYQAFgQACgGQADgLAFgKQALgXATgTQAKgKALgHQAMgIANgFQAMgFARgDQADgBAEgBQANgCAMgDQAPgDANgDQAEgBAEgBQAEgCAFAAQAOgCAQAEQAMACAMAFQAMAFAKAHQAKAHAIAKQADADADADQANAPANANQAGAIAGAFQAHAGAHAFQAKALAPAKQAMAKAJANQAGAJAFALQADAFABAGQAHASACAUQACASgCAUQgCATgGAVQgGAXgKASQgDAEgCADQgCAEgDAEQgFAHgHAEQgGAGgIAEQgTAMgTAKQgVAKgWAJQgMAFgLAFQgFADgGAEQgSAJgQAIQgQAHgRACQgTACgVgDQgWgDgVgIQgGgDgGgCQgPgHgOgIQgmgZgZgnQgSgagFgdgAjgBIQgEgTADgSQABgSAHgRQAEgMADgLQAFgLADgKQAIgYAHgaQAEgNAEgKQAEgLAGgKQAHgMAJgKQAJgLAMgJQALgJAMgGQALgEAMgEQAKgCALgCQAbgFAVgFQAHgBAIgDQAIgCAJAAQAHAAAIABQALACALADQAZAJATAUQALAKAIAKQAJALAJAKQAGAHAHAFQAGAFAFAFQAGAEAGAFQAPAKAJAOQAMAMAIAQQALAXACAaQACAYgFAdQgEAcgKAYQgFALgHAKQgDAEgDAEQgHAIgKAGQgLAHgJAHQgLAGgMAGQgZALgZAMQgMAFgLAGQgDABgEADQgGADgFADQgPAIgPAFQgMAFgNABQgVADgYgEQgZgEgZgLQgPgHgOgJQgmgZgYgmQgSgagFgcg");
	this.shape_61.setTransform(214.6628,177.3536);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["rgba(157,200,219,0.227)","#FFFFFF"],[0,1],-110.4,212.3,12.2,-29.2).s().p("Ag8DdQgYgEgZgLQgQgHgOgJQgmgZgYglQgRgagGgdIAAAAQgDgTACgSQABgSAHgSIAIgWIAIgWQAIgYAHgaQADgMAFgKQAEgMAGgJQAHgMAJgLQAJgLALgJQALgIANgGIAWgIIAWgFIAvgJQAHgBAJgEQAIgCAIABIAPAAQAMACAKAEQAaAIASAUIATAUIATAVQAGAHAHAGIALAJIALAJQAPALAKAOQALALAIARQALAXACAaQADAYgFAdQgFAcgKAXQgFAMgGAJIgHAJQgHAIgJAGIgVANIgWAMIgzAXIgWALIgIAEIgLAHQgOAIgQAFQgMAEgNACIgQABQgOAAgPgDg");
	this.shape_62.setTransform(214.6396,177.3397);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["rgba(150,187,204,0.306)","#EBEBEB"],[0,1],-128.3,236.4,14.2,-30.4).s().p("Ag3DfQgWgDgVgIIgMgFQgPgHgOgIQgmgZgZgnQgSgagFgdIAAgBQgEgUADgUQABgSAHgSIAHgRIAGgRQAHgWAGgYIAHgWQADgLAFgKQALgXATgTQAKgKALgHQAMgIANgFQAMgFARgDIAHgCIAZgFIAcgGIAIgCQAEgCAFAAQAOgCAQAEQAMACAMAFQAMAFAKAHQAKAHAIAKIAGAGIAaAcIAMANIAOALQAKALAPAKQAMAKAJANQAGAJAFALIAEALQAHASACAUQACASgCAUQgCATgGAVQgGAXgKASIgFAHIgFAIQgFAHgHAEQgGAGgIAEIgmAWIgrATIgXAKIgLAHIgiARQgQAHgRACIgPABQgMAAgNgCgAgCjdQgIADgHABIgwAKIgVAEIgXAIQgMAGgLAJQgMAJgJALQgJAKgHAMQgGAKgEALQgEAKgEANQgHAagIAYIgIAVIgHAXQgHARgBASQgDASAEATIAAABQAFAcASAaQAYAmAmAZQAOAJAPAHQAZALAZAEQAYAEAVgDQANgBAMgFQAPgFAPgIIALgGIAHgEIAXgLIAygXIAXgMIAUgOQAKgGAHgIIAGgIQAHgKAFgLQAKgYAEgcQAFgdgCgYQgCgagLgXQgIgQgMgMQgJgOgPgKIgMgJIgLgKQgHgFgGgHIgSgVIgTgUQgTgUgZgJQgLgDgLgCIgPgBIgEAAQgGAAgHACg");
	this.shape_63.setTransform(214.6628,177.3536);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("rgba(0,0,0,0.8)").ss(0.8,1,1).p("AjuBTQgDgUAFgUQACgRAKgUQAGgKAEgLQAFgMAEgLQAJgZAEgcQACgPAEgKQADgMAFgLQAGgNAJgMQAJgMAMgKQALgKAOgGQALgFANgDQAKgCANgCQAegFAVgGQAGgBAJgFQAIgDAJgBQAHAAAJABQANACALADQAaAKARAYQAKALAHAMQAJAMAJALQAHAIAHAGQAGAFAHADQAFAFAIADQARAJALANQAOAKAKAQQANAYADAcQADAZgFAgQgFAfgKAYQgGANgHAJQgDAFgEAEQgHAIgMAEQgMAGgKAGQgNAFgMAFQgcAKgbAMQgMAGgKAHQgEACgEADQgFADgFAFQgOAKgPAHQgMAHgNADQgVAEgagCQgbgDgagLQgRgGgQgJQgpgagagnQgUgcgFgegAjvBSQgEgVAGgVQACgSALgUQAEgIAEgIQAEgJADgIQAIgYAEgaQAEgRABgHQACgMAFgKQAJgaATgVQAJgLANgIQAMgJAOgFQAMgEATgEQAEAAAEgBQAPgDALgCQAQgEAOgFQAEgBAEgCQAFgCAEgBQAOgDASAEQANACAMAGQAMAGALAIQAJAIAIAMQADADADAEQAMASAMAOQAGAIAHAGQAGAGAJAEQAKAKASAIQAPAIAKAOQAIAIAGALQADAFACAGQAIAUADAVQACATgCAWQgCATgGAXQgHAZgKATQgCAEgDAEQgDAFgDADQgGAHgIAEQgGAFgJADQgWAJgUAJQgXAJgXAKQgNAFgLAGQgGADgFAFQgRALgPAMQgRAJgRAEQgTAEgXgCQgXgBgXgIQgHgCgGgDQgQgGgPgJQgpgZgcgpQgUgcgFgfg");
	this.shape_64.setTransform(214.9444,178.5641);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["rgba(157,200,219,0.239)","#FFFFFF"],[0,1],-101.7,199,10.9,-29.9).s().p("Ag8DrQgbgDgagLQgRgGgQgJQgpgagagnQgUgcgFgeQgDgUAFgUQACgRAKgUQAGgKAEgLIAJgXQAJgZAEgcQACgPAEgKQADgMAFgLQAGgNAJgMQAJgMAMgKQALgKAOgGQALgFANgDIAXgEQAegFAVgGQAGgBAJgFQAIgDAJgBIAQABQANACALADQAaAKARAYQAKALAHAMIASAXIAOAOQAGAFAHADQAFAFAIADQARAJALANQAOAKAKAQQANAYADAcQADAZgFAgQgFAfgKAYQgGANgHAJIgHAJQgHAIgMAEIgWAMIgZAKQgcAKgbAMIgWANIgIAFIgKAIQgOAKgPAHQgMAHgNADQgOADgPAAIgSgBg");
	this.shape_65.setTransform(214.9213,178.5613);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["rgba(146,181,196,0.361)","#E1E1E1"],[0,1],-128.5,235.2,14,-31.6).s().p("Ag3DtQgXgBgXgIIgNgFQgQgGgPgJQgpgZgcgpQgUgcgFgfIAAgBQgEgVAGgVQACgSALgUIAIgQIAHgRQAIgYAEgaIAFgYQACgMAFgKQAJgaATgVQAJgLANgIQAMgJAOgFQAMgEATgEIAIgBIAagFQAQgEAOgFIAIgDQAFgCAEgBQAOgDASAEQANACAMAGQAMAGALAIQAJAIAIAMIAGAHQAMASAMAOQAGAIAHAGQAGAGAJAEQAKAKASAIQAPAIAKAOQAIAIAGALIAFALQAIAUADAVQACATgCAWQgCATgGAXQgHAZgKATIgFAIIgGAIQgGAHgIAEQgGAFgJADIgqASQgXAJgXAKQgNAFgLAGQgGADgFAFQgRALgPAMQgRAJgRAEQgNADgOAAIgPgBgAANjrQgJABgIADQgJAFgGABQgVAGgeAFIgXAEQgNADgLAFQgOAGgLAKQgMAKgJAMQgJAMgGANQgFALgDAMQgEAKgCAPQgEAcgJAZIgJAXQgEALgGAKQgKAUgCARQgFAUADAUQAFAeAUAcQAaAnApAaQAQAJARAGQAaALAbADQAaACAVgEQANgDAMgHQAPgHAOgKIAKgIIAIgFIAWgNQAbgMAcgKIAZgKIAWgMQAMgEAHgIIAHgJQAHgJAGgNQAKgYAFgfQAFgggDgZQgDgcgNgYQgKgQgOgKQgLgNgRgJQgIgDgFgFQgHgDgGgFIgOgOIgSgXQgHgMgKgLQgRgYgagKQgLgDgNgCIgLgBIgFAAg");
	this.shape_66.setTransform(214.9444,178.5641);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("rgba(0,0,0,0.733)").ss(0.8,1,1).p("Aj7BdQgDgWAHgUQAEgSAMgTQAHgNAFgJQAHgMAEgMQAJgaADgfQAAgQADgKQACgOAFgMQAFgOAIgNQAJgNAMgLQAMgLAOgGQAMgGAOgDQAKgCAPgCQAggEAVgIQAHgBAJgHQAIgEAJgBQAIgBAJABQAOACALAEQAcALAPAcQAKAMAGAOQAIANAKAMQAHAIAHAGQAHAGAHADQAGAEAJADQATAGANAMQAQAJALAQQAQAZAEAeQADAZgFAjQgFAhgLAaQgFANgHAKQgEAFgFAEQgIAIgMADQgPAEgKAFQgOAEgNAEQgeAJgdANQgNAHgKAHQgEADgDADQgGAFgFAFQgMAMgPAKQgNAJgMAEQgVAHgcgBQgdgCgcgKQgSgHgRgJQgsgZgdgqQgWgegEgfgAj+BcQgCgXAHgWQAEgRAOgVQAGgJADgHQAGgJADgJQAJgZADgcQACgTABgHQABgOADgKQAHgcATgYQAKgMANgJQANgJAPgFQANgFAVgDQAEAAAEgBQAQgDAMgCQAQgFAOgGQAEgCAFgCQAFgDADgBQAQgFATAEQANADANAHQANAGAKAKQAKAJAHANQACAEADAEQALAWALAOQAHAKAHAFQAHAGAJAEQALAJAVAGQARAHAMAMQAJAIAIAMQADAFADAGQAJAVADAWQADAWgCAWQgCAUgGAZQgHAcgLASQgCAGgDAEQgEAEgDAEQgHAGgIAEQgHAEgKADQgYAGgWAIQgZAIgZAKQgNAFgLAHQgGAEgFAGQgQANgPAPQgQAMgRAGQgUAGgZgBQgYAAgZgIQgHgCgHgCQgRgGgQgJQgsgZgggsQgWgegFggg");
	this.shape_67.setTransform(215.1882,179.813);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["rgba(157,200,219,0.255)","#FFFFFF"],[0,1],-93,185.7,9.7,-30.6).s().p("Ag8D5QgdgCgcgKQgSgHgRgJQgsgZgdgqQgWgegEgfQgDgWAHgUQAEgSAMgTIAMgWQAHgMAEgMQAJgaADgfQAAgQADgKQACgOAFgMQAFgOAIgNQAJgNAMgLQAMgLAOgGQAMgGAOgDQAKgCAPgCQAggEAVgIQAHgBAJgHQAIgEAJgBIARAAQAOACALAEQAcALAPAcQAKAMAGAOQAIANAKAMQAHAIAHAGQAHAGAHADQAGAEAJADQATAGANAMQAQAJALAQQAQAZAEAeQADAZgFAjQgFAhgLAaQgFANgHAKIgJAJQgIAIgMADQgPAEgKAFIgbAIQgeAJgdANQgNAHgKAHIgHAGIgLAKQgMAMgPAKQgNAJgMAEQgSAGgYAAIgHAAg");
	this.shape_68.setTransform(215.1932,179.8483);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["rgba(143,174,188,0.412)","#D7D7D7"],[0,1],-128.8,233.9,13.7,-32.9).s().p("Ag3D7QgYAAgZgIIgOgEQgRgGgQgJQgsgZgggsQgWgegFggIAAgBQgCgXAHgWQAEgRAOgVIAJgQQAGgJADgJQAJgZADgcIADgaQABgOADgKQAHgcATgYQAKgMANgJQANgJAPgFQANgFAVgDIAIgBIAcgFQAQgFAOgGIAJgEIAIgEQAQgFATAEQANADANAHQANAGAKAKQAKAJAHANIAFAIQALAWALAOQAHAKAHAFQAHAGAJAEQALAJAVAGQARAHAMAMQAJAIAIAMIAGALQAJAVADAWQADAWgCAWQgCAUgGAZQgHAcgLASIgFAKIgHAIQgHAGgIAEQgHAEgKADQgYAGgWAIQgZAIgZAKQgNAFgLAHQgGAEgFAGQgQANgPAPQgQAMgRAGQgTAFgWAAIgEAAgAALj3QgJABgIAEQgJAHgHABQgVAIggAEQgPACgKACQgOADgMAGQgOAGgMALQgMALgJANQgIANgFAOQgFAMgCAOQgDAKAAAQQgDAfgJAaQgEAMgHAMIgMAWQgMATgEASQgHAUADAWQAEAfAWAeQAdAqAsAZQARAJASAHQAcAKAdACQAcABAVgHQAMgEANgJQAPgKAMgMIALgKIAHgGQAKgHANgHQAdgNAegJIAbgIQAKgFAPgEQAMgDAIgIIAJgJQAHgKAFgNQALgaAFghQAFgjgDgZQgEgegQgZQgLgQgQgJQgNgMgTgGQgJgDgGgEQgHgDgHgGQgHgGgHgIQgKgMgIgNQgGgOgKgMQgPgcgcgLQgLgEgOgCIgMAAIgFAAg");
	this.shape_69.setTransform(215.1882,179.813);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("rgba(0,0,0,0.667)").ss(0.7,1,1).p("AkJBmQgCgWAJgVQAFgSAPgUQAJgNAGgJQAHgNAFgMQAKgbAAgiQgBgRACgLQABgPAEgMQAEgPAIgPQAJgOAMgMQANgMAPgHQAMgGAPgCQALgDAPgBQAkgEAVgJQAGgCAKgJQAIgFAKgBQAHgCALABQAPACALAFQAdAMAOAgQAJANAFAPQAIAPAJANQAHAJAIAGQAHAGAJACQAGAEAKACQAWAFAOAKQATAIAMAQQATAZAEAgQAEAcgGAkQgFAkgLAbQgFAOgIAKQgEAFgFAEQgJAIgOACQgQADgLAEQgQACgNAEQghAHgeAOQgOAHgKAIQgDADgEAFQgFAFgFAGQgMAPgOAMQgMALgNAFQgVAJgeAAQgeAAgfgKQgTgHgSgJQgwgZgfgsQgZgfgDghgAkMBmQgCgYAKgXQAFgSARgVQAHgJAEgIQAHgJAEgJQAKgaAAgfQABgUAAgHQAAgPADgLQAEgfAUgZQAKgNAOgKQANgKAQgFQANgFAXgDQAEAAAFgBQARgCAMgEQASgEAOgIQAEgCAFgEQAFgDAEgBQAPgGAUAEQAPADANAHQAOAIAKALQAJAJAHAQQACAEACAFQAKAYALAQQAHAKAHAGQAIAGAKADQALAIAZAEQATAFANAMQALAHAIANQAEAFADAGQALAWAEAYQADAWgCAYQgCAUgHAcQgHAegKATQgDAGgEAEQgDAFgEADQgHAHgKADQgHAEgLABQgbAFgXAGQgcAGgZALQgPAGgKAIQgGAEgGAHQgOAOgPATQgPAPgSAIQgUAHgaABQgbABgagHQgIgCgHgCQgSgGgSgJQgvgagigtQgZghgEghg");
	this.shape_70.setTransform(215.441,181.0967);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["rgba(157,200,219,0.267)","#FFFFFF"],[0,1],-84.3,172.3,8.4,-31.4).s().p("Ah5D7QgTgGgSgJQgwgagfgrQgZgggDghIAAAAQgCgWAJgVQAFgSAPgVQAJgMAGgKQAHgMAFgNQAKgbAAghQgBgRACgLQABgPAEgNQAEgPAIgOQAJgPAMgMQANgMAPgGQAMgGAPgDQALgCAPgBQAkgEAVgKQAGgCAKgIQAIgGAKgBQAHgBALABQAPACALAEQAdAMAOAhQAJANAFAPQAIAPAJAMQAHAKAIAGQAHAFAJADQAGADAKACQAWAFAOAKQATAIAMARQATAYAEAhQAEAbgGAlQgFAkgLAaQgFAPgIAKIgJAJQgJAHgOACQgQADgLAEIgdAGQghAHgeAPQgOAHgKAIIgHAHQgFAFgFAHQgMAOgOAMQgMALgNAGQgVAIgeABQgegBgfgKg");
	this.shape_71.setTransform(215.4318,181.13);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["rgba(139,168,181,0.467)","#CDCDCD"],[0,1],-129,232.7,13.5,-34.1).s().p("AhrEDIgPgEQgSgGgSgJQgvgagigtQgZghgEghIAAgBQgCgYAKgXQAFgSARgVQAHgJAEgIQAHgJAEgJQAKgaAAgfIABgbQAAgPADgLQAEgfAUgZQAKgNAOgKQANgKAQgFQANgFAXgDIAJgBQARgCAMgEQASgEAOgIIAJgGIAJgEQAPgGAUAEQAPADANAHQAOAIAKALQAJAJAHAQIAEAJQAKAYALAQQAHAKAHAGQAIAGAKADQALAIAZAEQATAFANAMQALAHAIANIAHALQALAWAEAYQADAWgCAYQgCAUgHAcQgHAegKATIgHAKIgHAIQgHAHgKADQgHAEgLABQgbAFgXAGQgcAGgZALQgPAGgKAIQgGAEgGAHQgOAOgPATQgPAPgSAIQgUAHgaABIgEAAQgZAAgYgGgAAKkDQgKABgIAFQgKAJgGACQgVAJgkAEQgPABgLADQgPACgMAGQgPAHgNAMQgMAMgJAOQgIAPgEAPQgEAMgBAPQgCALABARQAAAigKAbQgFAMgHANQgGAJgJANQgPAUgFASQgJAVACAWIAAABQADAhAZAfQAfAsAwAZQASAJATAHQAfAKAeAAQAeAAAVgJQANgFAMgLQAOgMAMgPQAFgGAFgFIAHgIQAKgIAOgHQAegOAhgHIAdgGQALgEAQgDQAOgCAJgIIAJgJQAIgKAFgOQALgbAFgkQAGgkgEgcQgEgggTgZQgMgQgTgIQgOgKgWgFQgKgCgGgEQgJgCgHgGQgIgGgHgJQgJgNgIgPQgFgPgJgNQgOgggdgMQgLgFgPgCIgIAAIgKABg");
	this.shape_72.setTransform(215.441,181.0967);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("rgba(0,0,0,0.6)").ss(0.6,1,1).p("AkXBvQgBgXALgWQAHgSARgVQALgNAGgKQAJgMAFgNQALgcgDglQgCgSABgLQAAgRADgNQADgQAIgQQAJgPAMgNQANgOAQgHQANgFAQgDQALgCARgBQAmgEAVgLQAGgCALgKQAJgHAJgCQAIgBALABQAQACAMAFQAeAMAMAlQAIAOAFARQAHARAKANQAHAKAJAGQAHAFAJADQAHADALABQAYADAQAJQAVAHAOAQQAVAZAFAjQAEAcgFAnQgGAngLAbQgGAQgIAKQgFAGgFADQgJAHgQACQgSABgLADQgRABgOADQgkAFgfAQQgPAIgKAJQgDADgEAFQgEAGgFAHQgLARgOAOQgMAOgMAGQgWALghACQgfABghgKQgUgGgUgKQgygZgigtQgbgigDgigAkaBuQgCgZANgYQAGgRAUgWQAIgKAFgIQAHgIAFgKQALgbgCghQAAgVAAgIQgCgQACgMQADghAUgcQAJgOAPgLQAOgLARgFQAOgFAZgCQAEAAAEgBQATgCANgEQASgFAPgKQAEgCAFgEQAEgEAFgCQAPgHAWAFQAPACAOAJQAOAIAKAMQAJALAGASQACAFACAFQAJAbALAQQAHALAIAGQAHAGAMADQAKAHAdACQAVADAPALQAMAIAKANQAEAFAEAHQAMAVAEAaQAEAXgDAaQgBAVgHAdQgHAhgLATQgDAHgEAEQgEAFgEAEQgIAHgLACQgHADgNABQgdACgYAFQgeAFgaALQgQAGgLAJQgGAFgFAIQgOAQgNAWQgPASgSAJQgVAKgcACQgcACgcgGQgIgCgHgCQgUgGgTgJQgygaglgwQgcgigDgjg");
	this.shape_73.setTransform(215.669,182.402);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["rgba(157,200,219,0.278)","#FFFFFF"],[0,1],-75.6,159,7.1,-32.1).s().p("Ah9EKQgUgGgUgKQgygZgigtQgbgigDgiIAAgBQgBgXALgWQAHgSARgVQALgNAGgKQAJgMAFgNQALgcgDglQgCgSABgLQAAgRADgNQADgQAIgQQAJgPAMgNQANgOAQgHQANgFAQgDQALgCARgBQAmgEAVgLQAGgCALgKQAJgHAJgCQAIgBALABQAQACAMAFQAeAMAMAlQAIAOAFARQAHARAKANQAHAKAJAGQAHAFAJADQAHADALABQAYADAQAJQAVAHAOAQQAVAZAFAjQAEAcgFAnQgGAngLAbQgGAQgIAKQgFAGgFADQgJAHgQACQgSABgLADQgRABgOADQgkAFgfAQQgPAIgKAJIgHAIIgJANQgLARgOAOQgMAOgMAGQgWALghACIgFAAQgdAAgegJg");
	this.shape_74.setTransform(215.6752,182.4345);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["rgba(136,162,173,0.522)","#C3C3C3"],[0,1],-129.3,231.3,13.2,-35.5).s().p("AhuESIgPgEQgUgGgTgJQgygaglgwQgcgigDgjIAAgCQgCgZANgYQAGgRAUgWQAIgKAFgIQAHgIAFgKQALgbgCghIAAgdQgCgQACgMQADghAUgcQAJgOAPgLQAOgLARgFQAOgFAZgCIAIgBQATgCANgEQASgFAPgKIAJgGQAEgEAFgCQAPgHAWAFQAPACAOAJQAOAIAKAMQAJALAGASIAEAKQAJAbALAQQAHALAIAGQAHAGAMADQAKAHAdACQAVADAPALQAMAIAKANIAIAMQAMAVAEAaQAEAXgDAaQgBAVgHAdQgHAhgLATIgHALIgIAJQgIAHgLACQgHADgNABQgdACgYAFQgeAFgaALQgQAGgLAJQgGAFgFAIQgOAQgNAWQgPASgSAJQgVAKgcACIgLABQgWAAgXgFgAAIkRQgJACgJAHQgLAKgGACQgVALgmAEQgRABgLACQgQADgNAFQgQAHgNAOQgMANgJAPQgIAQgDAQQgDANAAARQgBALACASQADAlgLAcQgFANgJAMQgGAKgLANQgRAVgHASQgLAWABAXIAAABQADAiAbAiQAiAtAyAZQAUAKAUAGQAhAKAfgBQAhgCAWgLQAMgGAMgOQAOgOALgRIAJgNIAHgIQAKgJAPgIQAfgQAkgFQAOgDARgBQALgDASgBQAQgCAJgHQAFgDAFgGQAIgKAGgQQALgbAGgnQAFgngEgcQgFgjgVgZQgOgQgVgHQgQgJgYgDQgLgBgHgDQgJgDgHgFQgJgGgHgKQgKgNgHgRQgFgRgIgOQgMglgegMQgMgFgQgCIgIAAIgLAAg");
	this.shape_75.setTransform(215.669,182.402);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("rgba(0,0,0,0.533)").ss(0.6,1,1).p("AkkB5QgBgZANgWQAIgTAUgVQANgNAHgLQAKgMAFgOQALgdgFgnQgDgTAAgMQgCgSADgOQACgRAIgRQAIgRANgOQAOgOARgIQANgGARgCQAMgCASgBQAogDAWgNQAGgDALgLQAJgJAJgCQAIgBAMABQARACANAFQAfAOALAoQAHAQAEASQAGASAKAOQAHALAKAGQAIAGAKACQAHACAMABQAbABARAHQAXAGAQARQAYAZAFAlQAFAdgGAqQgGApgLAdQgGAQgJALQgFAFgFAEQgKAHgSAAQgTAAgMACQgSAAgQACQgmAEggAQQgQAJgJAKQgEAEgDAFQgFAHgEAIQgKATgOAQQgMAQgMAIQgWANgjADQghACgigJQgWgGgVgKQg2gagkgvQgegjgBgkgAkoB4QgBgbAOgZQAIgRAXgXQAKgKAFgIQAIgJAFgKQAMgbgDgkQgCgWgBgJQgDgRACgMQAAgkAUgeQAKgPAPgMQAPgLASgGQAOgFAbgBQAEgBAFgBQAUgCANgDQAUgGAOgLQAEgDAFgFQAFgEAFgCQAQgJAXAFQAQADAOAJQAPAJAKANQAJAMAFAUQACAFACAGQAHAeALARQAHAMAIAGQAIAGANACQAKAGAgAAQAYACAQAKQAOAHALAOQAEAGAEAGQAOAXAFAbQAEAYgDAbQgBAWgHAfQgIAjgKAUQgEAHgEAFQgEAFgFAEQgIAHgMABQgIADgOAAQgggBgZAFQggADgcAMQgQAGgLAKQgGAGgFAJQgNARgNAZQgPAWgSAKQgVAMgeAEQgdACgegFQgJgCgHgCQgVgGgVgJQg1gagogyQgegkgCgkg");
	this.shape_76.setTransform(215.9199,183.7112);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["rgba(157,200,219,0.294)","#FFFFFF"],[0,1],-67,145.6,5.8,-32.9).s().p("AiAEZQgWgGgVgKQg2gagkgvQgegjgBgkIAAAAQgBgZANgWQAIgTAUgVQANgNAHgLQAKgMAFgOQALgdgFgnQgDgTAAgMQgCgSADgOQACgRAIgRQAIgRANgOQAOgOARgIQANgGARgCQAMgCASgBQAogDAWgNQAGgDALgLQAJgJAJgCQAIgBAMABQARACANAFQAfAOALAoQAHAQAEASQAGASAKAOQAHALAKAGQAIAGAKACQAHACAMABQAbABARAHQAXAGAQARQAYAZAFAlQAFAdgGAqQgGApgLAdQgGAQgJALQgFAFgFAEQgKAHgSAAQgTAAgMACQgSAAgQACQgmAEggAQQgQAJgJAKIgHAJIgJAPQgKATgOAQQgMAQgMAIQgWANgjADIgMAAQgbAAgcgHg");
	this.shape_77.setTransform(215.9179,183.7482);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["rgba(132,155,165,0.573)","#B9B9B9"],[0,1],-129.5,230,13,-36.8).s().p("AhxEhIgQgEQgVgGgVgJQg1gagogyQgegkgCgkIAAgCQgBgbAOgZQAIgRAXgXQAKgKAFgIQAIgJAFgKQAMgbgDgkIgDgfQgDgRACgMQAAgkAUgeQAKgPAPgMQAPgLASgGQAOgFAbgBIAJgCQAUgCANgDQAUgGAOgLIAJgIQAFgEAFgCQAQgJAXAFQAQADAOAJQAPAJAKANQAJAMAFAUIAEALQAHAeALARQAHAMAIAGQAIAGANACQAKAGAgAAQAYACAQAKQAOAHALAOIAIAMQAOAXAFAbQAEAYgDAbQgBAWgHAfQgIAjgKAUIgIAMIgJAJQgIAHgMABQgIADgOAAQgggBgZAFQggADgcAMQgQAGgLAKQgGAGgFAJQgNARgNAZQgPAWgSAKQgVAMgeAEIgSABQgVAAgUgEgAAGkeQgJACgJAJQgLALgGADQgWANgoADQgSABgMACQgRACgNAGQgRAIgOAOQgNAOgIARQgIARgCARQgDAOACASQAAAMADATQAFAngLAdQgFAOgKAMQgHALgNANQgUAVgIATQgNAWABAZIAAAAQABAkAeAjQAkAvA2AaQAVAKAWAGQAiAJAhgCQAjgDAWgNQAMgIAMgQQAOgQAKgTIAJgPIAHgJQAJgKAQgJQAggQAmgEQAQgCASAAQAMgCATAAQASAAAKgHQAFgEAFgFQAJgLAGgQQALgdAGgpQAGgqgFgdQgFglgYgZQgQgRgXgGQgRgHgbgBQgMgBgHgCQgKgCgIgGQgKgGgHgLQgKgOgGgSQgEgSgHgQQgLgogfgOQgNgFgRgCIgJgBIgLABg");
	this.shape_78.setTransform(215.9199,183.7112);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("rgba(0,0,0,0.467)").ss(0.5,1,1).p("AkyCCQAAgaAPgXQAKgTAXgVQAOgOAHgLQAMgNAFgNQANgfgIgpQgFgVAAgNQgDgSABgPQACgTAIgSQAIgSANgPQAOgPARgIQAOgGATgCQAMgCATgBQArgCAWgQQAFgCAMgOQAKgJAJgCQAIgDANABQASACANAGQAgAPAKAtQAGAQADAUQAGAUAKAPQAIALAJAGQAJAGALABQAHACANAAQAegBASAHQAaAEASARQAaAaAGAnQAEAdgFAuQgGArgLAeQgHASgJALQgFAFgGAEQgLAGgTgBQgVgBgNABQgTgBgQABQgqACghASQgQAIgKAMQgDAEgDAGQgFAHgDAKQgKAVgNATQgMARgMAJQgWAPglAFQgjADglgJQgWgFgXgKQg4gagogxQgggmgBglgAk2CBQgBgcASgZQAJgSAagXQALgKAGgJQAJgKAFgKQANgcgGgmQgDgXgBgJQgEgTAAgMQgBgnAUggQAKgQAQgMQAQgNASgGQAPgEAdgCQAFgBAEAAQAWgCAOgEQAUgGAPgNQADgDAGgGQAFgFAFgCQAPgKAZAFQARADAPAKQAPAKAKAOQAJANAEAWQACAGABAGQAHAgAKASQAHANAJAHQAIAGAOABQALAFAjgCQAaABASAKQAPAGAMAOQAFAGAFAHQAPAXAFAdQAEAZgCAdQgCAWgHAiQgHAlgMAUQgDAIgFAFQgEAGgFADQgKAHgMABQgJACgPgBQgigDgaADQgjACgdAMQgRAHgLALQgGAGgFALQgMASgMAdQgOAYgTANQgWANgfAFQgfAEgggFQgIgCgJgCQgWgFgVgKQg5gagrg0QgggngCglg");
	this.shape_79.setTransform(216.1439,185.0289);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["rgba(157,200,219,0.306)","#FFFFFF"],[0,1],-58.2,132.2,4.7,-33.6).s().p("AiEEnQgWgGgXgKQg4gagogwQgggmgBglIAAgBQAAgZAPgYQAKgSAXgWQAOgNAHgLQAMgNAFgOQANgegIgqQgFgVAAgMQgDgTABgPQACgSAIgSQAIgSANgPQAOgQARgHQAOgHATgCQAMgCATAAQArgDAWgPQAFgCAMgOQAKgJAJgDQAIgCANABQASACANAGQAgAOAKAtQAGAQADAUQAGAUAKAPQAIAMAJAGQAJAGALABQAHACANAAQAegBASAGQAaAFASAQQAaAaAGAnQAEAegFAtQgGAsgLAdQgHASgJALQgFAGgGADQgLAHgTgBQgVgCgNABQgTgBgQACQgqACghARQgQAJgKALQgDAEgDAHQgFAHgDAJQgKAWgNASQgMASgMAJQgWAPglAEIgUABQgZAAgbgGg");
	this.shape_80.setTransform(216.1263,185.0597);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["rgba(129,149,158,0.627)","#AEAEAE"],[0,1],-129.7,228.7,12.8,-38.1).s().p("Ah0EwIgRgEQgWgFgVgKQg5gagrg0QgggngCglIAAgCQgBgcASgZQAJgSAagXQALgKAGgJQAJgKAFgKQANgcgGgmIgEggQgEgTAAgMQgBgnAUggQAKgQAQgMQAQgNASgGQAPgEAdgCIAJgBQAWgCAOgEQAUgGAPgNIAJgJQAFgFAFgCQAPgKAZAFQARADAPAKQAPAKAKAOQAJANAEAWIADAMQAHAgAKASQAHANAJAHQAIAGAOABQALAFAjgCQAaABASAKQAPAGAMAOIAKANQAPAXAFAdQAEAZgCAdQgCAWgHAiQgHAlgMAUQgDAIgFAFIgJAJQgKAHgMABQgJACgPgBQgigDgaADQgjACgdAMQgRAHgLALQgGAGgFALQgMASgMAdQgOAYgTANQgWANgfAFQgOACgOAAQgSAAgRgDgAAFkqQgJACgKAJQgMAOgFACQgWAQgrACQgTABgMACQgTACgOAGQgRAIgOAPQgNAPgIASQgIASgCATQgBAPADASQAAANAFAVQAIApgNAfQgFANgMANQgHALgOAOQgXAVgKATQgPAXAAAaIAAAAQABAlAgAmQAoAxA4AaQAXAKAWAFQAlAJAjgDQAlgFAWgPQAMgJAMgRQANgTAKgVQADgKAFgHQADgGADgEQAKgMAQgIQAhgSAqgCQAQgBATABQANgBAVABQATABALgGQAGgEAFgFQAJgLAHgSQALgeAGgrQAFgugEgdQgGgngagaQgSgRgagEQgSgHgeABQgNAAgHgCQgLgBgJgGQgJgGgIgLQgKgPgGgUQgDgUgGgQQgKgtgggPQgNgGgSgCIgHAAQgIAAgGACg");
	this.shape_81.setTransform(216.1439,185.0289);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("rgba(0,0,0,0.4)").ss(0.4,1,1).p("Ak/CLQAAgbARgYQALgTAagWQAQgOAIgLQAMgNAGgOQANgggKgsQgGgWgBgNQgFgUABgQQABgTAIgUQAHgTAOgQQAPgQASgIQAOgHAUgCQAMgCAVAAQAugCAWgRQAFgDAMgPQAKgLAJgDQAJgCANABQAUACANAGQAhAQAIAxQAFARADAVQAFAWAKAQQAIAMAKAGQAJAGAMABQAIABAOAAQAggDAUAFQAcADAUARQAcAaAHApQAFAfgGAwQgGAugLAfQgHASgKAMQgFAFgHAEQgLAGgVgCQgWgDgOAAQgVgCgRABQgsAAgiATQgRAJgJAMQgEAFgDAHQgEAIgDAKQgJAYgNAUQgMAUgNAKQgVASgnAFQglAFgmgIQgYgGgYgKQg8gagqgzQgignAAgngAlECKQAAgeATgaQALgSAdgXQAMgLAHgIQAKgKAFgMQAOgcgHgpQgFgYgCgJQgFgUAAgNQgDgpAUgiQAKgSARgNQAQgNATgGQAPgFAfgBQAFgBAFAAQAXgCAOgEQAVgHAPgOQAEgDAFgHQAGgGAFgCQAQgLAaAEQASAEAPALQAQALAKAPQAIANAEAZQACAGABAHQAFAjAKATQAHAOAJAGQAJAGAPABQALAEAmgEQAdgBATAJQAQAGAOAPQAFAGAFAHQARAYAFAeQAFAagCAfQgCAWgHAkQgIAogLAVQgEAIgFAGQgFAFgFAEQgKAHgOAAQgJACgQgDQglgFgbACQglABgeAMQgSAIgLALQgGAHgFAMQgLAUgMAgQgOAbgUAOQgVAQghAGQggAFgigFQgJgBgJgCQgXgFgXgKQg7gagug2QgjgpgBgng");
	this.shape_82.setTransform(216.3917,186.3537);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["rgba(157,200,219,0.322)","#FFFFFF"],[0,1],-49.5,118.9,3.4,-34.4).s().p("AiHE2QgYgGgYgKQg8gagqgzQgignAAgnIAAAAQAAgbARgYQALgTAagWQAQgOAIgLQAMgNAGgOQANgggKgsQgGgWgBgNQgFgUABgQQABgTAIgUQAHgTAOgQQAPgQASgIQAOgHAUgCIAhgCQAugCAWgRQAFgDAMgPQAKgLAJgDQAJgCANABQAUACANAGQAhAQAIAxQAFARADAVQAFAWAKAQQAIAMAKAGQAJAGAMABQAIABAOAAQAggDAUAFQAcADAUARQAcAaAHApQAFAfgGAwQgGAugLAfQgHASgKAMQgFAFgHAEQgLAGgVgCQgWgDgOAAQgVgCgRABQgsAAgiATQgRAJgJAMQgEAFgDAHQgEAIgDAKQgJAYgNAUQgMAUgNAKQgVASgnAFQgNACgOAAQgYAAgYgFg");
	this.shape_83.setTransform(216.3636,186.3917);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["rgba(125,142,150,0.678)","#A4A4A4"],[0,1],-130,227.4,12.5,-39.4).s().p("Ah3E+IgSgDQgXgFgXgKQg7gagug2QgjgpgBgnIAAgCQAAgeATgaQALgSAdgXQAMgLAHgIQAKgKAFgMQAOgcgHgpIgHghQgFgUAAgNQgDgpAUgiQAKgSARgNQAQgNATgGQAPgFAfgBIAKgBQAXgCAOgEQAVgHAPgOIAJgKQAGgGAFgCQAQgLAaAEQASAEAPALQAQALAKAPQAIANAEAZIADANQAFAjAKATQAHAOAJAGQAJAGAPABQALAEAmgEQAdgBATAJQAQAGAOAPIAKANQARAYAFAeQAFAagCAfQgCAWgHAkQgIAogLAVQgEAIgFAGQgFAFgFAEQgKAHgOAAQgJACgQgDQglgFgbACQglABgeAMQgSAIgLALQgGAHgFAMQgLAUgMAgQgOAbgUAOQgVAQghAGQgRADgRAAQgQAAgQgDgAADk4QgJADgKALQgMAPgFADQgWARguACIghACQgUACgOAHQgSAIgPAQQgOAQgHATQgIAUgBATQgBAQAFAUQABANAGAWQAKAsgNAgQgGAOgMANQgIALgQAOQgaAWgLATQgRAYAAAbIAAAAQAAAnAiAnQAqAzA8AaQAYAKAYAGQAmAIAlgFQAngFAVgSQANgKAMgUQANgUAJgYQADgKAEgIQADgHAEgFQAJgMARgJQAigTAsAAQARgBAVACQAOAAAWADQAVACALgGQAHgEAFgFQAKgMAHgSQALgfAGguQAGgwgFgfQgHgpgcgaQgUgRgcgDQgUgFggADQgOAAgIgBQgMgBgJgGQgKgGgIgMQgKgQgFgWQgDgVgFgRQgIgxghgQQgNgGgUgCIgHAAQgJAAgGABg");
	this.shape_84.setTransform(216.3917,186.3537);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("rgba(0,0,0,0.333)").ss(0.4,1,1).p("AlNCUQABgcATgZQANgTAcgXQARgOAJgLQAOgOAGgOQAOghgMgvQgIgXgCgOQgGgVAAgQQAAgVAIgVQAHgUAOgRQAQgSASgIQAPgHAVgCQANgBAVgBQAxgBAWgTQAFgDANgRQAKgMAJgDQAJgDAOABQAVACANAHQAjAQAHA1QAEATACAXQAEAXALARQAIAMALAHQAJAGANAAQAIABAPgBQAjgFAVAEQAeACAWARQAfAbAHArQAFAfgGAzQgGAxgLAfQgHAUgLAMQgGAGgGADQgMAGgWgDQgZgFgOgBQgWgDgSAAQgvgBgjATQgSAKgJAOQgEAFgDAHQgDAJgDALQgJAagMAXQgLAWgOALQgVAUgqAHQgmAGgogIQgZgFgZgLQg/gagtg0QglgqABgogAlTCSQABgeAWgbQAMgSAggZQANgKAIgIQAKgLAGgMQAQgdgKgrQgGgZgCgLQgGgVgCgNQgFgrAVglQAKgTARgNQARgPAUgGQAQgEAhgBQAFgBAFAAQAYgCAPgEQAWgIAPgQQAEgDAFgHQAFgHAGgDQAQgMAbAFQATADAQAMQARAMAJAQQAIAPAEAaQABAHABAHQAEAmAKAUQAHAPAKAGQAJAGAQABQAKADAqgGQAfgDAVAJQASAGAPAPQAFAGAGAHQASAZAGAfQAFAcgDAgQgBAXgHAmQgIAqgMAVQgEAJgFAGQgFAGgGADQgLAHgPAAQgJABgRgDQgngIgdABQgnAAgfANQgTAHgLAMQgHAIgEANQgKAWgMAjQgNAegUAQQgWASgjAHQghAGgkgEQgJgBgJgCQgZgFgYgKQg/gagwg5QgmgrgBgog");
	this.shape_85.setTransform(216.6029,187.7027);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["rgba(157,200,219,0.333)","#FFFFFF"],[0,1],-40.8,105.4,2.1,-35.2).s().p("AiLFEQgZgFgZgLQg/gagtg0QglgqABgoIAAAAQABgcATgZQANgTAcgXQARgOAJgLQAOgOAGgOQAOghgMgvQgIgXgCgOQgGgVAAgQQAAgVAIgVQAHgUAOgRQAQgSASgIQAPgHAVgCIAigCQAxgBAWgTQAFgDANgRQAKgMAJgDQAJgDAOABQAVACANAHQAjAQAHA1QAEATACAXQAEAXALARQAIAMALAHQAJAGANAAQAIABAPgBQAjgFAVAEQAeACAWARQAfAbAHArQAFAfgGAzQgGAxgLAfQgHAUgLAMQgGAGgGADQgMAGgWgDQgZgFgOgBQgWgDgSAAQgvgBgjATQgSAKgJAOQgEAFgDAHIgGAUQgJAagMAXQgLAWgOALQgVAUgqAHQgQACgRAAQgWAAgXgEg");
	this.shape_86.setTransform(216.6052,187.7393);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["rgba(122,136,142,0.733)","#9A9A9A"],[0,1],-130.2,226,12.3,-40.8).s().p("Ah6FNIgSgDQgZgFgYgKQg/gagwg5QgmgrgBgoIAAgDQABgeAWgbQAMgSAggZQANgKAIgIQAKgLAGgMQAQgdgKgrIgIgkQgGgVgCgNQgFgrAVglQAKgTARgNQARgPAUgGQAQgEAhgBIAKgBQAYgCAPgEQAWgIAPgQQAEgDAFgHQAFgHAGgDQAQgMAbAFQATADAQAMQARAMAJAQQAIAPAEAaIACAOQAEAmAKAUQAHAPAKAGQAJAGAQABQAKADAqgGQAfgDAVAJQASAGAPAPIALANQASAZAGAfQAFAcgDAgQgBAXgHAmQgIAqgMAVQgEAJgFAGQgFAGgGADQgLAHgPAAQgJABgRgDQgngIgdABQgnAAgfANQgTAHgLAMQgHAIgEANQgKAWgMAjQgNAegUAQQgWASgjAHQgUAEgWAAIgbgCgAABlFQgJADgKAMQgNARgFADQgWATgxABIgiACQgVACgPAHQgSAIgQASQgOARgHAUQgIAVAAAVQAAAQAGAVQACAOAIAXQAMAvgOAhQgGAOgOAOQgJALgRAOQgcAXgNATQgTAZgBAcIAAAAQgBAoAlAqQAtA0A/AaQAZALAZAFQAoAIAmgGQAqgHAVgUQAOgLALgWQAMgXAJgaIAGgUQADgHAEgFQAJgOASgKQAjgTAvABQASAAAWADQAOABAZAFQAWADAMgGQAGgDAGgGQALgMAHgUQALgfAGgxQAGgzgFgfQgHgrgfgbQgWgRgegCQgVgEgjAFQgPABgIgBQgNAAgJgGQgLgHgIgMQgLgRgEgXQgCgXgEgTQgHg1gjgQQgNgHgVgCIgHAAQgJAAgHACg");
	this.shape_87.setTransform(216.6029,187.7027);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("rgba(0,0,0,0.267)").ss(0.3,1,1).p("AlaCdQABgdAWgaQAOgTAfgXQATgOAJgLQAPgPAHgQQAOghgPgxQgIgZgEgOQgGgWgBgRQgBgWAHgWQAIgWAOgSQAQgTATgIQAQgHAVgCQAOgBAWAAQA0gCAWgUQAFgDANgTQAKgNAKgEQAJgDAPABQAWACAOAHQAkASAFA5QADATACAZQADAZALARQAIAOALAGQAKAGAOAAQAJABAPgDQAmgGAWACQAhABAXARQAiAbAHAuQAGAggGA2QgHAzgLAhQgHAVgLALQgGAGgHAEQgNAFgYgEQgagGgOgCQgYgEgSgBQgygDgkAVQgTAKgJAPQgEAFgDAIQgDAJgDANQgIAcgMAZQgKAYgOANQgWAVgrAJQgoAHgqgIQgbgEgagLQhCgbgwg2QgngrACgpgAlgCbQABgfAYgcQANgSAjgZQAPgLAIgIQAMgLAGgMQARgfgMgtQgHgagDgLQgIgWgCgPQgHgtAVgnQAKgUASgOQARgQAWgGQAQgEAjgBQAFAAAFAAQAZgCAQgFQAXgIAPgRQAEgEAGgIQAFgHAFgEQARgNAcAFQAUAEARAMQARANAJARQAIAQADAdQABAHABAIQACAoAKAVQAHAPAKAHQAKAGARAAQALADAtgIQAhgFAWAIQAUAGAQAPQAGAGAGAIQATAZAHAhQAGAcgDAiQgCAYgHAoQgIAsgMAWQgFAJgFAHQgFAGgGADQgMAIgQgBQgKAAgSgEQgqgKgeAAQgpgCggANQgUAIgLANQgGAIgFAOQgJAYgLAnQgNAggUASQgXAUgkAIQgjAIgmgEQgJgBgKgCQgagEgZgKQhCgbgzg7QgpgtABgqg");
	this.shape_88.setTransform(216.8497,189.0362);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["rgba(157,200,219,0.345)","#FFFFFF"],[0,1],-32.1,92,0.9,-36).s().p("AiOFSQgbgFgagKQhCgbgwg2QgngsACgpIAAgBQABgcAWgaQAOgTAfgYQATgOAJgLQAPgOAHgQQAOghgPgxQgIgZgEgOQgGgWgBgSQgBgWAHgWQAIgVAOgSQAQgTATgJQAQgHAVgBQAOgCAWAAQA0gBAWgVQAFgDANgTQAKgNAKgDQAJgEAPABQAWACAOAHQAkASAFA5QADAUACAYQADAZALASQAIANALAHQAKAGAOAAQAJAAAPgCQAmgHAWADQAhABAXARQAiAbAHAtQAGAggGA2QgHA0gLAgQgHAVgLAMQgGAGgHADQgNAGgYgFIgogHQgYgFgSAAQgygDgkAUQgTALgJAOQgEAFgDAJQgDAJgDAMQgIAdgMAZQgKAYgOAMQgWAWgrAIQgUAEgTAAQgWAAgVgEg");
	this.shape_89.setTransform(216.8222,189.0703);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["rgba(118,130,135,0.788)","#909090"],[0,1],-130.4,224.7,12.1,-42.1).s().p("Ah9FcIgTgDQgagEgZgKQhCgbgzg7QgpgtABgqIAAgDQABgfAYgcQANgSAjgZQAPgLAIgIQAMgLAGgMQARgfgMgtIgKglQgIgWgCgPQgHgtAVgnQAKgUASgOQARgQAWgGQAQgEAjgBIAKAAQAZgCAQgFQAXgIAPgRIAJgMQAGgHAFgEQARgNAcAFQAUAEARAMQAQANAKARQAIAQADAdIACAPQACAoAKAVQAHAPAKAHQAJAGASAAQALADAtgIQAhgFAWAIQAUAGAQAPQAGAGAGAIQATAZAHAhQAFAcgCAiQgCAYgHAoQgIAsgMAWQgFAJgFAHQgGAGgFADQgMAIgQgBQgKAAgSgEQgqgKgeAAQgpgCggANQgUAIgLANQgGAIgFAOQgJAYgLAnQgNAggUASQgXAUgkAIQgYAFgZAAIgYgBgAAAlSQgKAEgKANQgNATgFADQgWAUg0ACQgWAAgOABQgVACgQAHQgUAIgPATQgOASgIAWQgHAWABAWQABARAGAWQAEAOAIAZQAPAxgPAhQgGAQgPAPQgJALgTAOQgfAXgOATQgWAagBAdIAAABQgCApAnArQAwA2BCAbQAaALAbAEQAqAIAogHQArgJAVgVQAPgNAKgYQAMgZAIgcQACgNAEgJQADgIAEgFQAIgPAUgKQAkgVAxADQATABAYAEIAoAIQAYAEANgFQAHgEAGgGQALgLAHgVQALghAHgzQAGg2gGggQgHgugigbQgXgRghgBQgWgCgmAGQgPADgJgBQgOAAgKgGQgLgGgIgOQgLgRgDgZQgCgZgDgTQgFg5gkgSQgOgHgWgCIgGgBQgLAAgHADg");
	this.shape_90.setTransform(216.8497,189.0362);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("rgba(0,0,0,0.2)").ss(0.2,1,1).p("AloCmQACgeAYgbQAPgTAigYQAUgPALgKQAQgPAHgRQAPgigRg0QgKgagFgOQgIgYgBgSQgCgXAHgXQAHgXAPgTQARgUAUgJQAQgHAXgCQANgBAYAAQA2gBAXgWQAEgDAOgVQAKgOALgEQAJgEAPABQAXACAOAIQAlASAEA+QADAUABAbQACAaALASQAIAOAMAHQALAGAOAAQAKAAAQgDQAogJAYABQAjAAAZARQAkAcAJAvQAGAhgHA5QgGA2gMAhQgHAWgMAMQgGAHgIADQgNAFgZgFQgcgIgPgCQgZgGgUgBQg0gFglAWQgUALgJAPQgEAGgCAJQgEAKgCANQgHAegLAcQgLAagOAOQgVAYguAKQgqAIgsgHQgbgFgcgLQhGgagyg4QgpguACgqgAlvCkQACghAbgdQAOgRAmgaQARgLAIgIQANgLAGgNQASgggOgwQgIgbgEgLQgIgYgDgPQgKgvAVgqQALgVASgPQATgQAWgGQAQgFAlAAQAFAAAGAAQAagCAQgFQAYgJAQgTQADgEAGgIQAGgIAFgEQARgPAeAGQAVADARAOQASANAJATQAIARACAeQABAIAAAIQABAsAKAVQAHARALAGQAKAHASgBQALACAwgKQAkgHAXAHQAVAGASAQQAGAGAGAIQAVAaAHAiQAGAegCAkQgCAYgHAqQgJAvgLAWQgGAKgFAGQgGAGgGAEQgMAHgRgBQgLgBgTgFQgsgMgggBQgrgDgiANQgUAIgLAOQgHAJgEAPQgIAagLAqQgMAjgVAUQgXAVgmAKQgkAJgogDQgKgBgKgCQgbgEgbgKQhEgbg3g+QgrgvABgrg");
	this.shape_91.setTransform(217.0606,190.3653);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["rgba(157,200,219,0.361)","#FFFFFF"],[0,1],-23.4,78.6,-0.4,-36.8).s().p("AiSFgQgbgFgcgKQhGgbgyg4QgpguACgqIAAgBQACgeAYgaQAPgUAigXQAUgPALgLQAQgPAHgRQAPgigRgzIgPgpQgIgXgBgSQgCgYAHgXQAHgXAPgSQARgUAUgJQAQgIAXgBQANgCAYABQA2gBAXgXQAEgDAOgUQAKgPALgEQAJgDAPABQAXACAOAHQAlATAEA9QADAVABAaQACAaALASQAIAPAMAGQALAHAOgBQAKAAAQgDQAogJAYACQAjAAAZARQAkAbAJAwQAGAggHA5QgGA2gMAiQgHAWgMAMQgGAGgIADQgNAGgZgGQgcgHgPgDQgZgFgUgCQg0gEglAVQgUALgJAPQgEAGgCAJQgEAKgCAOQgHAegLAbQgLAbgOAOQgVAXguAKQgXAEgXAAQgUAAgUgDg");
	this.shape_92.setTransform(217.0643,190.4272);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["rgba(115,123,127,0.839)","#868686"],[0,1],-130.7,223.4,11.8,-43.4).s().p("AiAFrIgUgDQgbgEgbgKQhEgbg3g+QgrgvABgrIAAgDQACghAbgdQAOgRAmgaQARgLAIgIQANgLAGgNQASgggOgwIgMgmQgIgYgDgPQgKgvAVgqQALgVASgPQATgQAWgGQAQgFAlAAIALAAQAagCAQgFQAYgJAQgTIAJgMQAGgIAFgEQARgPAeAGQAVADARAOQASANAJATQAIARACAeIABAQQABAsAKAVQAHARALAGQAKAHASgBQALACAwgKQAkgHAXAHQAVAGASAQIAMAOQAVAaAHAiQAGAegCAkQgCAYgHAqQgJAvgLAWQgGAKgFAGQgGAGgGAEQgMAHgRgBQgLgBgTgFQgsgMgggBQgrgDgiANQgUAIgLAOQgHAJgEAPQgIAagLAqQgMAjgVAUQgXAVgmAKQgbAHgcAAIgVgBgAiakdQgXACgQAHQgUAJgRAUQgPATgHAXQgHAXACAXQABASAIAYIAPAoQARA0gPAiQgHARgQAPQgLAKgUAPQgiAYgPATQgYAbgCAeIAAABQgCAqApAuQAyA4BGAaQAcALAbAFQAsAHAqgIQAugKAVgYQAOgOALgaQALgcAHgeQACgNAEgKQACgJAEgGQAJgPAUgLQAlgWA0AFQAUABAZAGQAPACAcAIQAZAFANgFQAIgDAGgHQAMgMAHgWQAMghAGg2QAHg5gGghQgJgvgkgcQgZgRgjAAQgYgBgoAJQgQADgKAAQgOAAgLgGQgMgHgIgOQgLgSgCgaQgBgbgDgUQgEg+glgSQgOgIgXgCQgPgBgJAEQgLAEgKAOQgOAVgEADQgXAWg2ABIgLAAIgaABg");
	this.shape_93.setTransform(217.0606,190.3653);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("rgba(0,0,0,0.133)").ss(0.2,1,1).p("Al1CvQACgfAagcQARgTAkgZQAWgPALgKQARgQAIgRQAPgjgTg2QgMgcgFgPQgJgYgCgUQgDgYAHgYQAHgYAPgUQARgVAVgJQARgIAYgBQANgCAaABQA5gBAXgYQAEgDAOgWQAKgQAMgFQAIgDARABQAYACAOAHQAmAUACBCQACAVAAAcQADAcAKATQAJAPAMAHQALAGAQgBQAJAAASgEQAqgLAaAAQAmgBAaARQAmAcAKAyQAGAhgGA8QgHA5gMAiQgIAXgMAMQgGAHgJADQgNAFgbgHQgegIgPgEQgbgHgUgCQg3gGgnAXQgUALgJAQQgDAHgDAJQgDALgCAOQgGAhgLAdQgLAdgOAPQgVAagwALQgsAKgugHQgcgFgegKQhIgbg1g6QgrgwADgsgAl9CtQADgiAcgeQAQgSAqgaQARgMAJgIQAOgLAHgNQASghgPgyQgKgdgFgLQgJgZgEgPQgLgzAVgrQAKgWAUgQQATgRAXgGQAQgFAnAAQAGAAAGAAQAcgCAQgFQAYgJAQgVQAEgEAGgKQAGgIAFgEQASgQAfAFQAVAEASAPQASAOAJAUQAIARACAhQAAAIAAAJQABAuAJAWQAHASALAHQAKAGAUgBQALAAA0gMQAmgIAYAHQAXAFASARQAHAGAHAIQAWAbAIAkQAGAegCAmQgCAYgIAsQgIAygMAWQgFALgHAHQgGAGgGAEQgNAHgSgCQgLgBgUgGQgvgPghgCQgtgFgjAOQgWAJgKAPQgHAJgEAQQgHAbgKAuQgMAmgWAVQgXAYgoALQgmAKgpgDQgKAAgLgCQgcgEgcgLQhHgbg6g/QgtgxABgtg");
	this.shape_94.setTransform(217.3073,191.713);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["rgba(157,200,219,0.373)","#FFFFFF"],[0,1],-14.7,65.2,-1.6,-37.5).s().p("AiWFuQgcgEgegLQhIgbg1g6QgrgvADgsIAAgBQACgfAagcQARgTAkgYQAWgPALgLQARgPAIgSQAPgjgTg2IgRgqQgJgZgCgTQgDgYAHgZQAHgYAPgTQARgWAVgJQARgIAYgBQANgBAaAAQA5AAAXgYQAEgEAOgWQAKgPAMgFQAIgEARABQAYACAOAIQAmAUACBBQACAVAAAdQADAbAKATQAJAPAMAHQALAHAQgCQAJAAASgEQAqgKAaAAQAmgBAaAQQAmAdAKAxQAGAigGA7QgHA5gMAjQgIAXgMAMQgGAGgJADQgNAGgbgHIgtgMQgbgHgUgCQg3gGgnAWQgUAMgJAQQgDAGgDAKQgDAKgCAPQgGAggLAeQgLAdgOAPQgVAZgwAMQgZAFgaAAQgTAAgUgDg");
	this.shape_95.setTransform(217.3028,191.7874);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["rgba(111,117,119,0.894)","#7C7C7C"],[0,1],-130.9,222,11.6,-44.8).s().p("AiDF5IgVgCQgcgEgcgLQhHgbg6g/QgtgxABgtIAAgDQADgiAcgeQAQgSAqgaQARgMAJgIQAOgLAHgNQASghgPgyIgPgoQgJgZgEgPQgLgzAVgrQAKgWAUgQQATgRAXgGQAQgFAnAAIAMAAQAcgCAQgFQAYgJAQgVIAKgOQAGgIAFgEQASgQAfAFQAVAEASAPQASAOAJAUQAIARACAhIAAARQABAuAJAWQAHASALAHQAKAGAUgBQALAAA0gMQAmgIAYAHQAXAFASARIAOAOQAWAbAIAkQAGAegCAmQgCAYgIAsQgIAygMAWQgFALgHAHQgGAGgGAEQgNAHgSgCQgLgBgUgGQgvgPghgCQgtgFgjAOQgWAJgKAPQgHAJgEAQQgHAbgKAuQgMAmgWAVQgXAYgoALQgdAIgfAAIgTgBgAihklQgYABgRAIQgVAJgRAVQgPAUgHAYQgHAYADAYQACAUAJAYIARArQATA2gPAjQgIARgRAQQgLAKgWAPQgkAZgRATQgaAcgCAfIAAAAQgDAsArAwQA1A6BIAbQAeAKAcAFQAuAHAsgKQAwgLAVgaQAOgPALgdQALgdAGghQACgOADgLQADgJADgHQAJgQAUgLQAngXA3AGQAUACAbAHIAtAMQAbAHANgFQAJgDAGgHQAMgMAIgXQAMgiAHg5QAGg8gGghQgKgygmgcQgagRgmABQgaAAgqALQgSAEgJAAQgQABgLgGQgMgHgJgPQgKgTgDgcQAAgcgCgVQgChCgmgUQgOgHgYgCQgRgBgIADQgMAFgKAQQgOAWgEADQgXAYg5ABIgMAAIgbABg");
	this.shape_96.setTransform(217.3073,191.713);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("rgba(0,0,0,0.067)").ss(0.1,1,1).p("AmDC3QADggAcgcQATgUAngYQAXgQAMgKQATgQAHgSQARglgWg4QgNgdgGgPQgLgagCgUQgEgaAHgZQAGgaAQgUQASgWAVgKQARgIAZgBQAOgBAbABQA7gBAYgaQADgDAPgYQALgRALgFQAJgEARABQAZACAPAIQAoAVAABFQABAXAAAeQABAdALAUQAJAQANAGQAMAHAQgCQAKAAATgFQAsgNAbgBQAogCAcARQApAcAKA0QAHAigHA/QgHA7gMAkQgHAYgNAMQgHAHgJADQgOAFgcgIQgggKgQgFQgbgHgWgDQg5gIgoAXQgVANgJARQgEAGgCALQgDALgCAQQgFAigLAgQgKAfgOAQQgWAcgyANQgtAKgwgGQgegEgegLQhMgbg3g8QgugyADgtgAmLC2QADgkAggfQARgRAsgcQATgLAJgIQAPgMAHgNQAUgigSg1QgLgdgFgNQgKgZgFgQQgNg1AVguQALgXATgRQAUgRAYgHQARgEApAAQAGAAAGAAQAdgBARgHQAZgJARgWQADgFAGgKQAGgJAFgEQASgSAhAGQAWAEATAPQATAPAIAVQAIATABAjQAAAIAAAKQgBAxAJAWQAHATAMAHQALAGAUgBQALgBA3gOQApgJAaAGQAYAEAUARQAHAHAHAIQAYAcAIAlQAHAfgDAoQgCAZgHAuQgJA0gMAXQgGALgGAHQgHAHgGADQgOAIgTgDQgMgCgVgHQgxgQgigEQgwgGgkAPQgWAIgLAQQgHAKgEARQgGAdgKAxQgLApgWAXQgYAagpAMQgnALgrgCQgLgBgLgBQgegEgdgLQhKgbg9hCQgwgzACgug");
	this.shape_97.setTransform(217.516,193.0882);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["rgba(157,200,219,0.388)","#FFFFFF"],[0,1],-6,51.8,-2.9,-38.3).s().p("AiZF9QgegFgegLQhMgbg3g7QgugyADgtIAAgBQADggAcgdQATgTAngZQAXgPAMgLQATgQAHgSQARgkgWg5IgTgsQgLgagCgUQgEgZAHgaQAGgZAQgVQASgWAVgKQARgHAZgCQAOgBAbABQA7AAAYgaQADgEAPgYQALgQALgFQAJgFARABQAZACAPAJQAoAUAABGQABAWAAAeQABAeALATQAJAQANAHQAMAGAQgBQAKgBATgEQAsgNAbgBQAogDAcARQApAdAKA0QAHAigHA/QgHA7gMAjQgHAYgNANQgHAHgJADQgOAEgcgHIgwgPQgbgIgWgDQg5gIgoAYQgVAMgJARQgEAHgCAKIgFAbQgFAjgLAgQgKAegOARQgWAcgyAMQgdAHgeAAQgRAAgRgCg");
	this.shape_98.setTransform(217.5126,193.125);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["rgba(108,110,112,0.945)","#727272"],[0,1],-131.1,220.7,11.4,-46.1).s().p("AiFGIIgWgCQgegEgdgLQhKgbg9hCQgwgzACguIAAgDQADgkAggfQARgRAsgcQATgLAJgIQAPgMAHgNQAUgigSg1IgQgqQgKgZgFgQQgNg1AVguQALgXATgRQAUgRAYgHQARgEApAAIAMAAQAdgBARgHQAZgJARgWIAJgPQAGgJAFgEQASgSAhAGQAWAEATAPQATAPAIAVQAIATABAjIAAASQgBAxAJAWQAHATAMAHQALAGAUgBQALgBA3gOQApgJAaAGQAYAEAUARQAHAHAHAIQAYAcAIAlQAHAfgDAoQgCAZgHAuQgJA0gMAXQgGALgGAHQgHAHgGADQgOAIgTgDQgMgCgVgHQgxgQgigEQgwgGgkAPQgWAIgLAQQgHAKgEARIgQBOQgLApgWAXQgYAagpAMQghAJglAAIgMAAgAiokuQgZABgRAIQgVAKgSAWQgQAUgGAaQgHAZAEAaQACAUALAaIATAsQAWA4gRAlQgHASgTAQQgMAKgXAQQgnAYgTAUQgcAcgDAgIAAABQgDAtAuAyQA3A8BMAbQAeALAeAEQAwAGAtgKQAygNAWgcQAOgQAKgfQALggAFgiIAFgbQACgLAEgGQAJgRAVgNQAogXA5AIQAWADAbAHIAwAPQAcAIAOgFQAJgDAHgHQANgMAHgYQAMgkAHg7QAHg/gHgiQgKg0gpgcQgcgRgoACQgbABgsANQgTAFgKAAQgQACgMgHQgNgGgJgQQgLgUgBgdQAAgegBgXQAAhFgogVQgPgIgZgCQgRgBgJAEQgLAFgLARQgPAYgDADQgYAag7ABIgXgBIgSABg");
	this.shape_99.setTransform(217.516,193.0882);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["rgba(157,200,219,0.4)","#FFFFFF"],[0,1],2.8,38.4,-4.1,-39.1).s().p("AjbF8QhPgcg6g9Qgxg0AFgvQAEghAegeQAUgTAqgaQAZgPAMgLQAUgQAIgTQARglgZg7IgVguQgLgbgEgVQgEgbAGgbQAHgaAQgWQASgXAWgKQASgIAagBQAPgBAeABQA7AAAYgcQADgEAPgZQALgSAMgGQAJgEASABQAaACAQAIQAoAWgBBKIgBA3QABAfALAUQAJARAOAHQAMAGARgCQAKgBAUgFQAvgPAdgCQAqgEAeARQArAaALA5QAHAjgHBCQgHA+gMAkQgNAogZAIQgPAEgegJIgxgRQgdgJgWgDQg9gKgpAZQgWANgIASQgHAOgDAgQgFAlgKAiQgKAhgOASQgWAeg1AOQgfAIggAAQgvAAgxgRg");
	this.shape_100.setTransform(217.7458,194.487);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#686868").s().p("AiIGXQgqgCgqgPQhNgbhAhEQg0g4AFgxQADgkAiggQASgSAwgcQAUgLAKgIQAPgMAIgOQAVgjgUg3IgSgsQgMgbgFgQQgPg3AVgwQALgZAUgRQAVgTAZgGQARgFArABQAnAAAVgIQAagKARgXIAKgQQAFgKAGgFQATgSAhAGQAXAEAUAQQATAQAIAWQAKAYgCAzQgCA0AIAYQAIATAMAHQALAHAVgCQALgCA7gQQArgLAbAFQAkAHAaAeQAZAdAJAmQAHAhgDApQgBAZgIAxQgJA2gMAXQgMAXgPAHQgOAHgUgDQgMgCgXgIQg0gTgjgFQgxgHgmAPQgXAJgLAQQgIAMgDAWIgOBOQgLAsgWAZQgYAbgsAOQgkALgnAAIgKAAgAiuk3QgaABgSAIQgWAKgSAYQgQAVgHAbQgGAbAEAaQAEAVALAbIAVAuQAZA7gRAmQgIASgUARQgMAKgZAQQgqAZgUAUQgeAdgEAhQgFAvAxA0QA6A+BPAbQBSAdBNgUQA1gOAWgeQAOgRAKghQAKgiAFglQADghAHgOQAIgSAWgNQApgYA9AJQAWAEAdAJIAxARQAeAJAPgFQAZgIANgnQAMglAHg+QAHhBgHgjQgLg6grgZQgegRgqADQgdADgvAOQgUAGgKABQgRACgMgHQgOgHgJgQQgLgVgBgfIABg3QABhJgogWQgQgJgagCQgSgBgJAFQgMAFgLASQgPAagDAEQgYAbg7AAIgbAAIgSAAg");
	this.shape_101.setTransform(217.7461,194.4346);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["rgba(157,200,219,0.42)","#FFFFFF"],[0,1],-1,36.2,-0.3,-35.8).s().p("AjMGCIgWgHQgjgLgegTQgpgXgggkQgvg0AFgxQADghAdgeQATgWApgaQAVgPANgKQAWgTAJgSQAKgTAAgYQgBgNgDgQIgIgbIgNgkQgFgQgDgOIgCgQQgDgaAHgbIADgHQAGgWAOgUIADgEQARgVAUgJIAGgDQAQgGAUgCQAPgDAeAAQAlgBAYgLQANgGAKgKQAEgEAQgYQALgRAMgFQAKgEASABQALABAIACQANACAKAFQAPAIAKAOQARAZABAuQABAWAAAiQABAPACANQADANAFALQAJAQAMAJQAIAFAKABIAJAAQAKAAASgEQAXgFASgCQARgDAOABQAegBAZALIAPAIQAhAWAOAnIAGAXQAHAegDAxIgCAWQgFAugIAhIgGAVQgKAdgPANQgGAEgHADQgPAFgdgHIgOgDIgjgKQgVgFgRgCIgNgCQgmgFgfAHQgTAEgPAIQgWAMgKAQQgIAMgFAdQgDASgGARIgJAcQgMAdgPAQIgBAAQgWAag1AMIgMADQgXAEgYAAQgoAAgogLg");
	this.shape_102.setTransform(217.8236,194.7236);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#616161").s().p("AiLGXIgKgBQgmgDglgNQgUgHgTgJQgpgUgjgeQgPgNgOgPQgTgUgLgUQgUgiADggQAEglAfghQAQgRAlgZIALgGQATgMAKgJQALgJAHgJIAGgIQAPgagDgjIgFgaQgCgKgIgYIgDgHQgJgZgDgQIgCgLQgGgrARgoIADgHQAJgUAPgQIAGgHQATgSAWgHIADgBQASgGAqgCIARgBQAagCAQgGQARgHAOgMQAHgGAGgIIALgPQAFgJAGgFQAUgSAiAGQAVAEAUANIACACQAUAPAJAVIAGAQQAGAWAAAkIAAAPQABAoAHAVQACAHAEAGQAFAJAHAFQAKAIAUgBQAFABANgDQARgCAegGIAYgDQAYgCASAFQAfAIAaAaIAEAGQAZAdAJAmQAEARABATQACASgBATQgBAVgFAiIgDAVQgHAsgKAZIgEAJQgMAWgOAIQgOAJgTgCQgMgBgWgHQghgJgbgEIgbgEQgbgDgXADQgUADgRAGQgYAJgMAOQgJALgEAUIgLAoIgHAdQgJAZgMASQgHAKgIAIQgUASgeALIgTAGQgTAFgVADQgOACgQAAIgQgBgAAHmIQgMAFgLARQgQAYgEAEQgKAKgNAGQgYALglABQgeAAgPACQgUACgQAGIgGADQgUAKgRAVIgDAEQgOAUgGAWIgDAGQgHAbADAaIACARQADAOAFAQIANAkIAIAbQADAPABANQAAAZgKATQgJASgWASQgNALgVAOQgpAbgTAVQgdAegDAiQgFAxAvA0QAgAjApAYQAeASAjAMIAWAGQBBASA+gLIAMgCQA1gMAWgaIABgBQAPgPAMgeIAJgbQAGgRADgSQAFgdAIgNQAKgQAWgLQAPgIATgEQAfgHAmAEIANACQARADAVAFIAjAJIAOAEQAdAHAPgGQAHgCAGgFQAPgNAKgdIAGgUQAIghAFguIACgXQADgxgHgeIgGgWQgOgnghgXIgPgIQgZgKgeAAQgOAAgRACQgSADgXAFQgSAEgKAAIgJgBQgKgBgIgFQgMgIgJgQQgFgMgDgNQgCgNgBgPQAAgigBgVQgBgugRgaQgKgOgPgIQgKgEgNgDQgIgCgLAAIgHgBQgNAAgIAEg");
	this.shape_103.setTransform(217.825,194.6984);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["rgba(157,200,219,0.443)","#FFFFFF"],[0,1],-4.7,34.1,3.5,-32.3).s().p("AjSGCIgWgGQglgMgegSQgqgXgfgkQgug0AFgzIAAgBQAEgiAbgfQATgXAngbIAhgaQAXgTAJgRQALgTACgXIgBgaIgEgZQgHgWgCgNQgEgPgBgOIgBgQQAAgZAIgbIACgGQAHgWAOgVIADgEQAQgWATgKIAHgDQAPgHAUgDQAPgEAegBQAjgCAZgLQAOgGAKgKQAFgDAQgXQALgPAOgFQAKgEASABIATACQANADAKAEQAQAHAKAOQATAZADAuQACAVAAAiQAAAPADANQADANAEAMQAIARAMAJQAHAFAJACIAIABQAJACASgDQAUgCARgBQARgBANACQAdACAYAMIAOAIQAiAaANAlQAEALADAMQAHAfgCAxIgCAWQgFAugIAiIgHAVQgJAdgQANQgFAFgHADQgPAHgcgFIgOgCQgWgFgNgCIgmgFIgNgBQglgEghAHQgSADgQAHQgXALgKAOQgJAKgHAaQgEAQgHAOIgLAYQgOAZgPAOIgBABQgXAWg2ALIgMACQgVACgVAAQgqAAgsgLg");
	this.shape_104.setTransform(217.9317,194.9289);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#595959").s().p("AiPGXIgKAAQgngEglgMQgUgHgTgJQgqgUgkgeQgPgNgNgOQgUgVgLgUQgTghADgiQADgnAeghQAPgTAjgZIAKgHQATgMAKgKQALgJAIgJIAFgIQARgagBghIgCgZQgBgJgGgXIgBgGQgGgYgCgPIgBgKQgBgpARgoIADgHQAKgUAPgSIAGgGQASgTAUgIIAEgBQARgIApgDIASgCQAYgEARgGQARgHAPgMIANgNIALgOQAHgJAGgEQAUgRAiAFQAWAEAUAMIACACQAVAOALAUIAFAPQAIAVACAkIAAAQQACAmAHAXIAGANQAEAJAHAHQAJAHATACQAEABANgCQAPABAcgEIAXAAQAWgBASAHQAdAKAZAcIAEAFQAZAfAJAlQAFARACATQACASgBATQAAAWgFAiIgDAUQgGAsgKAaIgEAKQgMAWgOAJQgOAJgSgBQgMABgWgFQgggGgbgDIgbgCQgbgBgYADQgTADgSAGQgYAHgNANQgJAKgGASQgGAMgIAXIgJAZQgKAVgNAQQgHAJgJAGQgUAQgeAKIgUAFQgTAEgVACQgKABgOAAIgXgBgAAUmJQgOAFgLAPQgQAXgFADQgKAKgOAGQgZALgjACQgeABgPAEQgUADgPAHIgHADQgTAKgQAWIgDAEQgOAVgHAWIgCAGQgIAbAAAZIABAQQABAOAEAPQACANAHAWIAEAZIABAaQgCAXgLATQgJARgXATIghAaQgnAbgTAXQgbAfgEAiIAAABQgFAzAuA0QAfAkAqAXQAeASAlAMIAWAGQBBARA/gIIAMgCQA2gLAXgWIABgBQAPgOAOgZIALgYQAHgOAEgQQAHgaAJgKQAKgOAXgLQAQgHASgDQAhgHAlAEIANABIAmAFQANACAWAFIAOACQAcAFAPgHQAHgDAFgFQAQgNAJgdIAHgVQAIgiAFguIACgWQACgxgHgfQgDgMgEgLQgNglgigaIgOgIQgYgMgdgCQgNgCgRABQgRABgUACQgSADgJgCIgIgBQgJgCgHgFQgMgJgIgRQgEgMgDgNQgDgNAAgPQAAgigCgVQgDgugTgZQgKgOgQgHQgKgEgNgDIgTgCIgGgBQgOAAgIAEg");
	this.shape_105.setTransform(217.9018,194.9363);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["rgba(157,200,219,0.463)","#FFFFFF"],[0,1],-8.4,31.9,7.4,-29).s().p("AjYGCIgWgHQgmgLgegSQgrgXgfglQgsgzAFg2IAAAAQADgjAagfQASgaAmgbIAhgbQAWgTALgRQAMgSADgVIACgZIgBgYQgEgUAAgMQgCgPAAgNIAAgQQACgZAJgbIACgGQAHgVAOgWIADgEQAQgWATgLIAGgDQAPgIATgEQAQgFAdgCQAjgEAagLQANgGALgJQAHgEAPgUQAMgPAOgEQALgEASABQAKABAJACQANACAKAEQARAHAKANQAVAYAEAtQADAXAAAhQABAPADAOQACAMAFANQAHAQAKALQAHAGAIADIAIABQAIADAQgBIAjABQAPAAANAEQAcAEAXAOIAOAJQAiAcANAjQAEALACANQAIAfgCAxIgBAXQgFAugIAiIgHAWQgKAcgPAPQgGAFgGADQgOAIgcgDIgOgBIgjgEIgmgCIgMgBQgmgCghAGQgTADgQAGQgXAJgMAMQgKAJgIAWQgGANgIAMIgMAVQgPAVgQAMIgBAAQgYAUg2AIIgNACQgTACgSAAQguAAgugMg");
	this.shape_106.setTransform(218.0195,195.166);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#525252").s().p("AiSGXIgKgBQgngEgmgMQgUgHgTgIQgsgUgkgdQgPgNgOgOQgUgVgLgVQgSghADgjQADgnAcgiQAOgVAigaIAKgHQARgNALgKQAKgJAIgKIAGgIQARgZACggIABgXQABgJgDgVIgBgGQgDgWAAgPIABgJQACgnASgoIADgHQAKgUAPgSIAFgHQASgUAUgIIADgCQASgJAngFIARgDQAZgEAQgHQASgHAPgLIAOgNIAMgOQAFgIAHgEQAWgQAiAFQAWADAVAMIACABQAWAOALATIAHAOQAJAVADAjIABAQQADAmAHAYIAFANQAEAJAGAHQAJAJARADQAEACALgBQAPAEAZgCIAVACQAVACARAIQAcAMAZAcIAEAGQAZAgAKAkQAFASACASQACARAAAVQAAAWgEAiIgDAVQgGArgLAcIgEAJQgLAWgOAKQgNAKgSABQgMACgUgEQgggDgbAAIgbgBQgbAAgYAEQgUADgSAFQgYAHgOALQgLAIgHAQQgHALgJATIgLAWQgMASgNANQgIAHgJAGQgVAMgeAIIgUAEQgTAEgVABIgVACIgbgCgAAhmLQgOAFgNAOQgPAVgGAEQgLAJgOAGQgaALgjADQgdADgPAEQgUAEgPAIIgGADQgSALgQAXIgDAEQgOAWgHAVIgDAGQgIAbgCAYIAAAQQAAAOACAOQAAANADAUIACAXIgCAZQgEAWgMARQgKARgXATIghAbQglAcgTAZQgZAfgEAjIAAABQgFA2AsAzQAfAkArAYQAeARAmAMIAWAGQBCARA/gHIANgBQA3gIAXgUIABgBQAQgLAPgWIANgUQAIgMAFgOQAJgWAKgJQAMgMAWgIQAQgHATgDQAhgFAmABIANABIAmADIAiAEIAOAAQAcADAPgIQAGgDAGgFQAPgOAKgdIAGgVQAJgjAEguIACgXQACgwgIggQgDgMgEgLQgNgjghgdIgOgJQgYgOgbgEQgNgDgPgBIgkAAQgPABgJgDIgHgCQgJgDgGgGQgLgKgHgQQgEgOgDgMQgCgNgBgPQgBgigDgWQgEgugVgYQgKgNgQgHQgKgEgNgCQgJgCgKAAIgIAAQgNAAgIACg");
	this.shape_107.setTransform(217.9873,195.2015);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["rgba(157,200,219,0.486)","#FFFFFF"],[0,1],-12.1,29.8,11.2,-25.6).s().p("AjfGBIgWgGQgngLgegRQgsgYgeglQgrgyAGg5IAAgBQADgkAYgfQASgbAjgdIAigbQAWgTALgQQANgSAGgUIAEgXIACgWQgBgSACgNQAAgNABgOIACgPQADgZAKgaIACgGQAIgVAOgWIADgFQAQgXARgLIAGgEQAPgJATgEQAQgGAcgEQAigFAbgKQAOgGALgJQAHgEAQgSQANgOAPgEQALgDASAAIATADQAOACAKAEQAQAGALAMQAWAXAGAuQAEAXABAhQABAPADAOIAGAaQAGAQAKAMQAGAGAHAEIAHACQAIAEAOABIAhAFQAOACAMAFQAaAFAXAQQAIAFAGAFQAiAfAMAiIAHAXQAIAggBAxIgBAXQgEAugKAkIgGAVQgKAdgPAPIgMAJQgOAJgbgBIgPAAIghAAIgngBIgMAAQgmAAgiAFQgTADgQAFQgXAHgOAKQgKAHgKASQgHAMgKAKIgNAQQgRASgRAKIgBAAQgYARg3AGIgNABIgeACQgxAAg0gOg");
	this.shape_108.setTransform(218.1303,195.4037);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#4A4A4A").s().p("AiVGYIgLgBQgngEgmgMQgVgHgTgIQgugTgjgdQgQgNgOgOQgUgVgLgWQgRggACgkIAAgBQADgoAagiQAOgXAggaIAJgIQARgOALgKQAKgJAIgKIAGgIQASgZAFgeIAEgXQADgIgCgTIAAgGQABgVACgNIABgJQAHglATgpIADgGQAJgUAPgTIAGgHQARgVASgJIAEgCQARgLAmgGIARgEQAYgFARgHQASgHAQgLIAOgNIAMgMQAGgIAHgEQAXgPAjAFQAWADAVAKIADACQAWAMAMASQAEAGADAIQAMAUAEAjIACAQQAEAlAGAZIAFAOIAJARQAIAJAPAFQAEADALAAQAMAGAYABIAUAFQATADAQAKQAbANAYAeIAEAFQAZAiAKAkQAGARACARQADATAAAUQABAXgEAiIgCAVQgHArgKAdIgEAJQgLAXgOALQgNAKgRACQgMADgUgBQgfgBgbACIgbABIgzAFIgnAIQgYAGgPAKQgMAHgIANQgIAJgLAQQgHAIgGAKQgOAPgNALQgJAGgJAEQgWAKgeAGIgTADQgUADgVABIgPAAIghgBgAAtmLQgOAEgNAOQgRASgGAEQgMAJgOAGQgaAKgjAFQgcAEgQAGQgTAEgOAJIgGAEQgSALgQAXIgCAFQgPAWgHAVIgCAGQgKAagEAZIgBAPQgCAOAAANQgCANACASIgCAWIgFAXQgFAUgNASQgMAQgWATIghAbQgkAdgRAbQgYAfgEAkIAAABQgFA5AqAyQAfAlAsAYQAeARAnALIAWAGQBCARBAgFIANgBQA4gGAYgRIABAAQARgKAQgSIAOgQQAJgKAHgMQAKgSALgHQANgKAXgHQARgFATgDQAigFAlAAIANAAIAmABIAiAAIAOAAQAbABAPgJIALgJQAQgPAJgdIAHgVQAJgkAEguIABgXQACgxgIggIgIgXQgMgigigfQgGgFgHgFQgXgQgagFQgMgFgPgCIgggFQgPgBgHgEIgHgCQgIgEgGgGQgJgMgHgQIgGgaQgCgOgBgPQgBghgEgXQgGgugXgXQgKgMgRgGQgKgEgNgCIgUgDIgEAAQgPAAgKADg");
	this.shape_109.setTransform(218.0694,195.4381);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["rgba(157,200,219,0.506)","#FFFFFF"],[0,1],-15.8,27.7,15,-22.2).s().p("AjlGBIgWgFQgogMgegQQgtgYgegmQgpgxAFg7IAAgCQAEglAWggQARgdAigcIAhgdQAWgTANgPQANgSAIgTQADgKAFgLIAFgTQABgRAEgNIAEgaIADgPQAGgYAKgaIADgGQAHgUAPgYIACgEQAQgYARgMIAGgEQAOgJASgGQAQgHAcgFQAigGAbgLQAOgFALgIQAJgEARgRQANgNAPgDQAMgDASAAIATACQAOACAKAEQARAGALAMQAYAWAIAtQAFAXABAiIADAdIAGAaQAGARAIAMQAGAHAGAEIAHAEQAGAFANACIAeAJQAOAEALAGQAZAIAXARIANALQAiAiALAgIAIAWQAJAigCAxIAAAXQgEAugKAkIgGAWQgKAdgPAQIgMAJQgOAKgaACIgPABIghACIgmACIgNABQglABgjAEQgTADgRAEQgYAGgOAHQgMAGgMAPQgIAJgKAHIgPAOQgTANgQAIIgBAAQgaAOg4AEIgNABIgUAAQg4AAg4gOg");
	this.shape_110.setTransform(218.2282,195.6445);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#434343").s().p("AiZGYIgLgBQgogFglgMQgWgGgTgIQgvgTgkgcQgQgNgOgOQgUgVgLgWQgQggACgmIAAAAQADgpAYgjQANgZAegbIAJgIQAQgOALgLQAKgKAIgKIAGgHQAUgaAHgcIAHgVQAEgIABgRIABgGQADgTAEgNIADgIQAKgjAUgpIAEgGQAJgUAOgUIAGgHQARgWARgJIADgCQASgNAkgIIARgEQAYgGARgIQASgIAQgKIAOgMIAOgMQAHgHAHgDQAYgOAiAEQAXACAVAKIADABQAXAMAOARIAHANQANAUAGAiIACAQQAGAkAGAbIAEAOIAIARQAIAKANAIQADADAKABQALAJAWADIASAHQASAFAQAMQAZAPAYAeIAEAGQAZAjAKAjQAGARADARQADATAAAVQACAYgEAhIgCAVQgGArgLAeIgEAKQgLAWgNAMQgMALgRADQgMAFgTAAQgeACgcAEIgbADIgzAGIgoAIQgYAFgQAIQgMAGgKALQgKAHgLAOQgIAFgHAJIgeAUIgSAIQgYAGgdAFIgUACQgTACgWAAIgNABQgOAAgWgCgAA6mMQgPADgOANQgRARgIAEQgLAIgOAFQgcALgiAGQgbAFgQAHQgTAGgOAJIgGAEQgQAMgQAYIgDAEQgOAYgIAUIgCAGQgLAagFAYIgDAPIgFAaQgEANgBARIgFATQgFALgDAKQgHATgOASQgMAPgWATIghAdQgiAcgRAdQgXAggDAlIAAACQgGA7ApAxQAeAmAtAYQAeAQAoAMIAXAFQBCARBBgDIANgBQA5gEAZgOIACAAQAQgIASgNIAPgOQALgHAIgJQAMgPALgGQAPgHAXgGQARgEATgDQAjgEAmgBIAMgBIAngCIAhgCIAOgBQAagCAPgKIALgJQAPgQAKgdIAHgWQAJgkAEguIABgXQABgxgJgiIgHgWQgMgggigiIgNgLQgXgRgYgIQgMgGgNgEIgegJQgNgCgHgFIgGgEQgHgEgFgHQgJgMgGgRIgFgaIgEgdQgBgigFgXQgIgtgYgWQgLgMgRgGQgKgEgNgCIgUgCIgFAAQgOAAgKADg");
	this.shape_111.setTransform(218.1867,195.7169);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["rgba(157,200,219,0.529)","#FFFFFF"],[0,1],-19.5,25.5,18.9,-18.8).s().p("AjrGBIgXgGQgpgLgegQQgugYgdgmQgogxAGg+IAAgBQADgmAVggQARgfAggeIAhgdQAWgTANgPQAPgSAJgRQAEgJAHgKIAIgSQAEgPAGgMIAHgZIAFgPQAHgXAMgaIACgGQAIgUAOgYIADgFQAPgZAQgMIAGgEQAOgLASgGQAQgJAbgFQAhgIAdgKQANgGAMgIQAKgDARgQQAOgLAQgDQAMgDASAAIATACQAOACAKAEQASAFALALQAZAWAKAtQAGAYACAhQABAPACAOIAFAbQAFAQAIAOQAEAHAGAFIAGAEQAGAHAMADIAbAOQAMAFAMAIQAXAKAWATIAMALQAiAlALAeIAIAXQAKAjgBAwIgBAYQgDAugKAlIgHAWQgJAcgQARIgLAKQgOALgZAEIgPADQgTACgOADIgmAEIgNABQglACgkAEIglAFQgXAFgQAGQgMAEgOALQgJAHgMAFIgQAJQgUAKgRAGIgCAAQgaAKg5ADIgOAAIgHAAQg+AAg/gPg");
	this.shape_112.setTransform(218.3426,195.8993);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#3B3B3B").s().p("AicGYIgLgBQgpgFgmgLQgVgHgUgIQgxgSgjgbQgRgNgNgOQgVgWgLgXQgQgfACgnIAAgBQADgqAWgjQANgbAcgbIAJgIIAagbIATgUIAFgGQAVgbAKgaIAKgUQAFgHAEgQIACgFIAMgeIADgIQAPghAVgoIADgHQAKgTAOgVIAFgHQARgYAQgJIADgCQARgPAkgJIARgGQAWgHASgHQASgIARgLIAPgLIANgLQAIgGAHgEQAZgNAjAEQAXACAWAJIACABQAZALAOAQQAEAFAEAHQAPATAHAjIADAPIAMBAIAEAOIAHATQAHAKAMAJQADAEAIADQAKALATAGIARAJQARAHAPAOQAYAQAXAgIAEAFQAZAkALAiQAHASACARQAEATAAAVQACAYgDAhIgCAWQgFArgLAeIgEAKQgLAXgNANQgMALgQAFQgMAGgTACQgdAEgcAGIgbAFIg0AIIgnAHQgYAFgSAGQgNAFgLAJQgLAFgNAKQgJAEgIAHIggAOQgJADgKACIg1AIIgUABQgUABgWgBIgJABQgOAAgagDgABHmNQgQADgOALQgSAQgJADQgNAIgNAGQgcAKghAIQgbAFgRAJQgSAGgOALIgFAEQgQAMgQAZIgCAFQgPAYgIAUIgCAGQgLAagIAXIgEAPIgIAZQgGAMgDAPIgJASQgGAKgEAJQgKARgPASQgNAPgWATIggAdQghAegQAfQgVAggEAmIAAABQgFA+AnAxQAdAmAvAYQAeAQApALIAWAGQBEAQBBgBIANAAQA6gDAagKIABAAQARgGAUgKIARgJQAMgFAJgHQANgLANgEQAPgGAYgFIAlgFQAkgEAlgCIAMgBIAngEQANgDAUgCIAOgDQAZgEAPgLIALgKQAPgRAKgcIAHgWQAKglADguIABgYQAAgwgJgjIgIgXQgLgegiglIgNgLQgWgTgXgKQgLgIgNgFIgbgOQgMgDgGgHIgFgEQgGgFgFgHQgHgOgGgQIgEgbQgDgOgBgPQgCghgGgYQgJgtgagWQgLgLgRgFQgLgEgNgCIgUgCIgFAAQgOAAgKADg");
	this.shape_113.setTransform(218.2789,195.9583);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["rgba(157,200,219,0.549)","#FFFFFF"],[0,1],-23.2,23.3,22.7,-15.5).s().p("AhsGRQhCgBhDgQIgXgFQgqgMgegPQgwgYgcgnQgmgwAFhAIAAgCQAEgmATghQAQghAfgeIAggfQAWgTAOgPQAQgQAMgQQAFgIAIgJIAMgQQAGgOAIgMIALgYIAFgOIAWgxIACgGQAJgTAOgaIACgEQAQgaAPgMIAFgFQAOgLARgIQARgJAagHQAhgJAdgLQAOgFANgHQAKgEASgOQAPgKAQgDQANgCARAAIAUACQANACAKADQASAFAMALQAbAUALAtQAHAZACAhIAEAdIAEAcQAFAQAGAOQAEAIAGAGIAEAFQAGAIAKAFIAZASQALAGALAJQAVAMAWAVIAMAMQAiAoALAbIAIAYQAKAkAAAwIgBAYQgDAugKAmIgHAWQgKAcgPASQgFAGgGAFQgOAMgYAFIgPAFIggAHQgVAFgSACIgMACIhKAHIgmAEIgoAGQgNADgQAHQgKAFgNACIgSAHIgnAJIgCAAQgbAIg6AAIgOAAg");
	this.shape_114.setTransform(218.4414,196.1708);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#343434").s().p("AhEGcIgqgBQgMABgmgEIgLgBQgpgGgngLQgVgGgVgIQgygSgjgaQgRgNgOgOQgVgWgKgXQgPgfACgpIAAAAQACgrAUgkQANgdAagbIAIgJIAagcIASgTIAGgIQAWgaANgZQAFgJAHgJQAHgHAGgOIADgFIARgbIAFgHIAohIIADgHQAKgTAOgVIAFgIQARgYAOgKIADgDQASgQAigLIAQgGQAXgIASgIIAigSIAQgLIAPgKQAIgGAIgDQAZgMAjADQAXACAWAIIADABQAZAKAQAPIAIALQARATAJAiIADAPIANBBIAEAOIAGATQAGALAKAMQADAEAHAEQAJAOARAIIAPAMQAPAJAPAPQAWASAXAgIAEAGQAZAlALAhQAHATADAQQAEATABAVQADAagDAgIgCAWQgFArgLAgIgEAKQgLAWgMAOQgMAMgQAGQgLAIgSADIg6AQIgaAGQgbAGgZAEIgoAHQgZAEgTAEQgNADgNAHQgMADgOAIQgKACgJAEIgiAJIgUADIg2ADIgUAAgABTmPQgQADgPAKQgSAOgKAEQgNAHgOAFQgdALghAJQgaAHgRAJQgRAIgOALIgFAFQgPAMgQAaIgCAEQgOAagJATIgCAGIgWAxIgFAOIgLAYQgIAMgGAOIgMAQQgIAJgFAIQgMAQgQAQQgOAPgWATIggAfQgfAegQAhQgTAhgEAmIAAACQgFBAAmAwQAcAnAwAYQAeAPAqAMIAXAFQBDAQBCABIAOAAQA6AAAbgIIACAAIAngJIASgHQANgCAKgFQAQgHANgDIAogGIAmgEIBKgHIAMgCQASgCAVgFIAggHIAPgFQAYgFAOgMQAGgFAFgGQAPgSAKgcIAHgWQAKgmADguIABgYQAAgwgKgkIgIgYQgLgbgigoIgMgMQgWgVgVgMQgLgJgLgGIgZgSQgKgFgGgIIgEgFQgGgGgEgIQgGgOgFgQIgEgcIgEgdQgCghgHgZQgLgtgbgUQgMgLgSgFQgKgDgNgCIgUgCIgGAAQgNAAgLACg");
	this.shape_115.setTransform(218.4257,196.27);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["rgba(157,200,219,0.569)","#FFFFFF"],[0,1],-27,20.9,26.4,-12.3).s().p("AhjGRIgOAAQhDgDhEgPIgXgGQgrgLgegPQgxgYgcgnQgkgwAFhDIAAgBQAEgoASghQAPgjAegfIAfggIAlghIAegeQAGgHALgIIAOgPQAJgMAKgLIAOgYIAHgOIAYgwIADgFIAXguIACgEQAPgaAOgOIAGgEQANgMARgJQARgLAagHIA9gWQAPgFANgGQAMgEARgMQAQgJARgDQANgCARABIAUABQANABALADQASAGANAJQAcAUANAtQAIAZACAhIAEAdIAEAcQADAQAGAQIAIAPIAEAGQAFAJAIAGQAMANALAJQAKAIAKALQAUAOAWAXIAMAMQAhArALAZIAIAZQALAkAAAwIAAAYQgDAugKAnIgHAXQgLAcgOATIgLAKQgOAOgYAHIgOAGIghAKQgUAGgSAEIgMACQgmAFgmACIglADIgqADIggAFQgLADgOgBIgUADIgpAEIgCAAQgTADgiAAIghgBg");
	this.shape_116.setTransform(218.5511,196.5008);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#2D2D2D").s().p("AgzGdIgUgBIgqgCQgLABgogFIgLgBQgqgGgmgLQgWgGgVgHQg0gSgigaQgSgMgOgPQgVgVgLgZQgOgeACgqIAAAAQACgsATglQALgeAZgdIAIgJIAZgdIASgTIAHgIQAWgaAQgXQAGgIAJgJQAIgGAJgNIADgEIAWgZIAGgHQAWgdAXgpIAEgHIAXgpIAFgHQAQgaAOgKIADgDQARgRAhgNIAQgHIApgSIAjgSIAQgKIAQgJQAIgGAIgDQAbgLAiADQAXACAXAHIADABQAaAJARAOIAJAKQATATAJAhIAFAPQAIAjAFAfIADAOIAGAUQAFAMAJANQACAGAGAFQAIAQAPAKIANAOQANALAPASQAVAUAXAgIAEAHQAYAlAMAhQAHATADAQQAFATACAVQADAagDAhIgCAWQgFArgLAgIgEAKQgKAXgNAPQgLANgPAHQgMAJgRAFIg5AUIgaAIQgbAHgZAFQgVAEgUACIgtAGQgOACgOAEQgOACgPAFQgLAAgKACIgkADIgUABQgbgCgdAAgABfmSQgQADgQAJQgSAMgLAEQgOAGgOAFIg+AWQgaAHgQALQgSAJgNAMIgFAEQgOAOgPAaIgDAEIgWAuIgDAFIgZAwIgGAOIgOAYQgKALgJAMIgPAPQgKAIgGAHIgeAeIglAiIggAfQgeAfgPAjQgSAhgDAoIAAABQgGBDAkAwQAdAnAxAYQAdAPAsALIAXAGQBDAPBDADIAOAAQA7ACAcgEIABAAIAqgEIATgDQAOABALgDIAggFIAqgDIAmgDQAmgCAlgFIANgCQASgEAUgGIAggKIAOgGQAYgHAOgOIALgKQAPgTAKgcIAHgXQAKgnADguIAAgYQAAgwgLgkIgIgZQgKgZgigrIgMgMQgVgXgUgOQgLgLgKgIQgLgJgLgNQgJgGgEgJIgEgGIgJgPQgFgQgEgQIgEgcIgDgdQgDghgIgZQgMgtgdgUQgMgJgTgGQgKgDgNgBIgUgBIgHgBQgNAAgLACg");
	this.shape_117.setTransform(218.5443,196.7429);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["rgba(157,200,219,0.592)","#FFFFFF"],[0,1],-30.7,18.3,30.3,-9.4).s().p("ABwGXIgiAAQgMAAgQgDIgVgBQgZgCgTAAIgBAAQgdABg7gDIgPgBQhDgFhEgPIgXgGQgtgLgdgPQgzgXgbgoQgjgwAGhFIAAgBQADgoARgiQAOglAdggQAQgSAPgNIAlgiIAigcQAHgHAMgHQAQgKACgDIAXgVIARgXIAIgNQAOgWAOgaIACgFIAXguIADgEQAOgbAOgOIAFgFQANgNARgKQARgMAZgIIA+gXIAcgLQANgEASgKQAQgIASgCQANgCARAAIAUACQANABALADQATAEANAJQAeAUAOAsQAJAaADAgIAEAeIADAdIAHAgIAHARIADAGQAEALAIAHQAJAPAKAMIAUAVQASARAVAYIALANQAiAsAKAZQAFAMADANQAMAlABAvIgBAZQgCAugKAoIgIAXQgKAcgPATIgKAMQgOAOgXAKIgOAHIghANQgUAHgSAFIgMACQglAHgnACIgnABIgWABIgVgBg");
	this.shape_118.setTransform(218.6622,197.2075);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#252525").s().p("AA+GlQgWgDgQAAIgVgCQgbgFgdgBIgUgCIgrgDQgJAAgqgFIgMgCQgqgGgngKIgrgNQg1gSgjgZQgSgMgNgPQgWgWgLgZQgNgdACgsIAAAAQABgtARgmQALgfAXgdIAIgKIAYgdIATgUIAGgIIAqgwQAHgHALgIQAKgGALgMIAEgDIAbgWIAHgHQAagbAYgpIADgHIAYgpIAEgIQAQgbANgKIADgDQARgUAfgOIARgIIAogTIAjgSIASgJIAPgJQAJgFAJgDQAbgKAjADQAXABAYAHIADABQAbAHARAOIAKAJQAUASALAhIAFAPQAJAjAFAgIADAOIAFAVQAEAMAHAPQACAHAFAGQAHATAMAMIAMARQAMANAOATQATAVAXAiIAEAGQAZAmAMAhQAIAUADAPQAFATACAVQADAbgCAhIgBAWQgFArgMAhIgEAKQgJAXgNAQQgLAOgOAIQgMAKgQAHQgcANgdAMIgaAKQgbAJgaAEQgUAEgVACIguAEQgPAAgPADQgPgBgRACQgMgCgLABgAgOGNQATAAAZACIAVABQAPADAMAAIAjAAIArAAIAmgBQAngCAlgHIANgCQASgFAUgHIAggNIAOgHQAXgKAOgOIALgMQAPgTAKgcIAHgXQALgoACguIAAgZQgBgvgLglQgEgNgFgMQgKgZghgsIgMgNQgUgYgTgRIgTgVQgKgMgKgPQgHgHgEgLIgDgGIgHgRIgIggIgDgdIgDgeQgEgggJgaQgOgsgegUQgMgJgTgEQgLgDgNgBIgUgCQgRAAgOACQgRACgRAIQgSAKgMAEIgdALIg9AXQgaAIgRAMQgRAKgNANIgFAFQgNAOgPAbIgCAEIgXAuIgDAFQgNAagOAWIgIANIgRAXIgYAVQgCADgQAKQgMAHgHAHIghAcIgmAiQgPANgQASQgcAggPAlQgQAigEAoIAAABQgFBFAiAwQAcAoAyAXQAeAPAsALIAXAGQBFAPBDAFIAOABQA8ADAcgBIACAAg");
	this.shape_119.setTransform(218.6485,197.625);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["rgba(157,200,219,0.612)","#FFFFFF"],[0,1],-34.4,14.7,34.1,-7.4).s().p("ACiGmQgYAAgUgDIgmgGQgNgCgQgFIgXgEQgbgGgTgDIgCAAIhZgHIgPgCQhEgGhEgPIgYgFQgtgLgegPQgzgXgbgpQghgvAFhHIAAgCQAEgpAPgjQAOgnAbgfQAPgSAPgPQAWgUARgOQASgPASgLQAIgFAOgGIAVgLIAcgUIAUgWIAKgNQAQgVAOgaIADgFIAXguIACgFQAPgbAMgPIAFgFQANgOAQgLQARgNAZgJQAfgNAfgLIAdgLQAOgDASgJQARgHASgCQAOgBARAAIAUABQANABALADQAUAEANAJQAfASAQAsQAKAaAEAhIADAeIADAdIAGAiIAFARIADAHQADAMAGAJQAIASAJANIASAYQARATAUAaIALAOQAiAvAJAXQAFAMAEANQAMAmABAvIAAAZQgCAugKAoIgIAYQgKAcgPAUIgKAMQgOAQgWALIgOAJIggAQQgUAJgSAFIgNADQglAIgoABIgTABIgUgBg");
	this.shape_120.setTransform(218.7732,198.9063);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#1E1E1E").s().p("ACbGyIgggBIgjgDQgNgEgMgBQgYgGgRgDIgVgEQgcgIgdgDIgUgDIgrgEQgIAAgsgGIgMgBQgrgHgngKIgrgNQg3gRgjgZQgSgMgOgOQgWgWgKgaQgNgdACgtIAAAAQABguAPgmQALgiAVgdIAHgKIAYgfIASgUIAHgIQAYgaAVgUQAIgHANgHQALgFAOgKIAFgDIAggUIAIgGQAegaAZgoIADgHIAYgrIAEgHQAQgcALgLIADgDQARgVAegQIAQgJIAogVIAkgRIASgJIARgIQAJgEAJgDQAcgJAjACQAXABAYAGIADABQAcAGATANIAKAIQAWASANAhIAFAPQAKAhAFAiIADAOIAEAWQADANAGARQABAHAEAHQAFAWALAPIAKATIAYAjQASAYAWAiIAEAHQAZAnAMAgQAIAUAEAPQAFATADAVQAEAcgCAgIgCAXQgEAqgMAjIgEAKQgJAXgMARQgLAOgNAKQgMALgQAJQgbAQgdAOIgbALQgbAKgZAFQgVAEgVACIgkABIgLAAgAB4mmQgSACgRAGQgSAJgOAEIgdAKQgfALgfANQgZAKgRANQgQALgNANIgFAGQgMAOgPAcIgCAEIgXAvIgDAFQgOAagQAVIgKANIgUAVIgcAUIgVALQgOAGgIAGQgSALgSAPQgRANgWAUQgPAPgPASQgbAggOAnQgPAigEApIAAACQgFBIAhAvQAbAoAzAYQAeAOAtALIAYAFQBEAPBEAHIAPABIBZAIIACAAQATACAbAGIAXAEQAQAGANACIAmAFQAUADAYABIAnAAQAogBAlgIIANgEQASgFAUgJIAggPIAOgJQAWgMAOgPIAKgMQAPgVAKgcIAIgXQAKgpACguIAAgYQgBgvgMgnQgEgMgFgMQgJgYgigvIgLgOQgUgZgRgTIgSgYQgJgOgIgRQgGgJgDgMIgDgHIgFgSIgGgiIgDgdIgDgeQgEgggKgaQgQgsgfgTQgNgIgUgFQgLgCgNgBIgUgBIgIAAIgXABg");
	this.shape_121.setTransform(218.7874,199.0631);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["rgba(157,200,219,0.635)","#FFFFFF"],[0,1],-38.1,11,37.9,-5.6).s().p("ACpG1QgZgCgWgFQgQgEgXgHQgPgEgSgIIgXgIQgcgKgVgEIgCAAQgdgFg+gIIgOgBQhFgJhFgPIgYgEQgugLgegOQg0gYgbgpQgfguAGhKIAAgDQADgqAOgjQANgoAZggQAPgTAQgPQAVgUASgNQATgPAUgKQAIgFARgEIAYgJQAQgIAQgLQAMgJAMgLIALgNQARgVAQgZIACgFIAYgvIACgFQAPgcALgPIAFgGQAMgOAQgMQASgOAYgLQAdgOAhgLIAegKQAOgDATgHQASgGASgBQAPgCAQAAIAVABQANABALADQAUAEANAHQAhASASAsQALAaAEAhIAEAeIABAeIAFAjIAEASIACAIQACANAFALQAGAUAIAPIAQAbIAkAwIAKAPQAiAyAJAWIAJAYQANAoABAuIABAZQgCAugLAqQgDAMgFALQgKAcgPAWIgKAMQgOARgVAOIgOAJIgfATQgUALgTAFIgMAEQglAKgpAAIgHABQgQAAgQgCg");
	this.shape_122.setTransform(218.902,200.655);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#161616").s().p("ACiG/IgigEIglgIQgPgGgMgDQgagJgRgFIgVgHQgfgKgcgFIgUgEIgsgGIg0gGIgMgCQgrgGgngKQgYgGgVgHQg4gRgjgYQgSgMgOgOQgWgWgLgaQgMgdACguIAAgBQABgvANgmQAKgkATgeIAHgJIAXghIATgVIAGgHQAZgbAZgSQAJgGAPgGIAcgNIAGgDQAWgKAPgIIAJgFQAigYAagpIAEgGQAKgSAMgZIAFgIQAPgdAKgMIADgDQARgXAdgRIAQgKIAogWIAkgRIATgIIARgHQAJgEAKgCQAdgJAjACQAYABAYAFIADAAQAdAGATALIALAIQAYARAOAhIAGAPQAMAhAEAjIACAOIADAXIAHAgQABAIADAIQADAYAJASIAJAVIAVAnQARAZAWAkIAEAGQAZApAMAfQAJAUAEAPQAGAUACAVQAFAcgBAgIgCAXQgEAqgMAkIgEALQgJAWgMASQgKAPgNALQgMANgPAKQgaATgeAQIgaANQgbAMgaAEQgUAFgWABIgOAAQgRAAgSgCgACEm1QgSABgSAGQgTAHgOADIgeAKQghALgdAOQgYALgSAOQgQAMgMAOIgFAGQgLAPgPAcIgCAFIgYAvIgCAFQgQAZgRAVIgLANQgMALgMAJQgQALgQAIIgYAJQgRAEgIAFQgUAKgTAPQgSANgVAUQgQAPgPATQgZAggNAoQgOAjgDAqIAAADQgGBKAfAuQAbApA0AYQAeAOAuALIAYAEQBFAPBFAJIAOABQA+AIAdAFIACAAQAVAEAcAKIAXAIQASAIAPAEQAXAHAQAEQAWAFAZACQATACAUgBQApAAAlgKIAMgEQATgFAUgLIAfgTIAOgJQAVgOAOgRIAKgMQAPgWAKgcQAFgLADgMQALgqACguIgBgZQgBgugNgoIgJgYQgJgWgigyIgKgPIgkgwIgQgbQgIgPgGgUQgFgLgCgNIgCgIIgEgSIgFgjIgBgeIgEgeQgEghgLgaQgSgsghgSQgNgHgUgEQgLgDgNgBIgVgBQgQAAgPACg");
	this.shape_123.setTransform(218.9008,200.753);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["rgba(157,200,219,0.655)","#FFFFFF"],[0,1],-41.8,7.4,41.7,-3.7).s().p("ADYHGQgVAAgTgCQgZgEgXgHQgSgFgZgLQgPgHgTgKIgZgLQgdgOgWgGIgCgBQgegHg+gKIgPgCQhGgKhFgPIgYgFQgwgKgdgOQg2gYgagpQgeguAGhNIAAgCQAEgrAMgjQAMgqAYghQAOgUAQgQQAVgUATgMQAVgOAVgIQAKgFASgDIAbgIQATgGASgKQAOgJANgLIAMgMQAUgUAQgZIADgGQAJgQAPgfIACgFQAOgdALgPIAEgGQAMgPAQgNQARgPAYgMQAdgQAhgLIAfgJIAjgJQASgEATgBIAfgBIAVABQANAAALACQAUAEAOAHQAjARATAsQAMAbAFAgQACAPABAQIACAeIACAkIADAUIABAIQACAOADANQAFAWAHARIAOAeIAiA0IAKAQQAiA0AIAUIAKAZQANApACAtIABAaQgCAugLAqIgIAYQgKAcgPAWIgKANQgNASgVAQIgOALQgRAMgOAJQgUAMgSAHIgNAEQgjALgoAAIgDAAg");
	this.shape_124.setTransform(219.0243,202.426);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#0F0F0F").s().p("ACqHNQgSgDgSgFIgogNIgcgMIgugUIgWgJQgfgOgcgGIgVgFIgrgHIg2gHIgMgCQgrgHgogKIgtgMQg6gRgigXQgTgMgOgOQgWgWgLgbQgLgdABgvIAAgBQACgvALgoQAJglASgeIAGgKQALgTALgPIATgVIAHgIQAZgaAcgQQAKgGARgGIAggLIAHgCQAZgIAQgHIALgFQAmgWAagpIAEgGQAKgSANgaIAEgIQAPgeAJgMIACgEQASgYAbgTIAQgLQAUgMAUgLQARgJAUgIIATgIIASgGQAJgDAKgCQAegIAjACQAYAAAZAEIAEABQAdAFAUAKIAMAHQAaARAPAgIAHAPQAMAgAFAkIABAPIACAXIAEAjIADASQACAbAHAUQADANAEALQAHASAMAYIAlA/IAEAHQAZAqANAfQAJAUAEAOQAGAUAEAVQAFAdgBAgIgBAYQgEApgNAlIgEALQgJAWgLATQgKAQgMANQgMAOgOALQgaAWgeASIgaAPQgbANgaAFQgVAFgWAAIgFAAQgXAAgWgEgACRnFQgTABgSAFIgjAJIgfAJQghALgdAPQgYAMgRAQQgQAMgMAQIgEAFQgLAQgOAdIgCAFQgPAegJARIgDAFQgQAZgUAUIgMANQgNALgOAIQgSAKgTAHIgbAHQgSAEgKAEQgVAIgVAOQgTANgVAUQgQAPgOAUQgYAigMApQgMAkgEAqIAAADQgGBMAeAuQAaAqA2AXQAdAOAwALIAYAFQBFAOBGAKIAPACQA+AKAeAIIACABQAWAGAdANIAZAMQATAKAPAGQAZALASAFQAXAIAZADQATADAVAAQApAAAlgLIANgEQASgHAUgMQAOgJARgNIAOgLQAVgQANgSIAKgMQAPgXAKgbIAIgYQALgrACguIgBgZQgCgugNgoIgKgaQgIgTgig1IgKgPIgig0IgOgfQgHgQgFgXQgDgMgCgOIgBgJIgDgUIgCgkIgCgeQgBgQgCgPQgFgggMgbQgTgsgjgRQgOgGgUgEQgLgCgNgBIgVgBIgfABg");
	this.shape_125.setTransform(219.0247,202.4903);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["rgba(157,200,219,0.678)","#FFFFFF"],[0,1],-45.6,3.7,45.5,-1.8).s().p("ADfHWQgUAAgVgEQgZgEgYgKQgSgHgbgOQgQgJgVgMIgagPQgfgSgWgIIgCgBQgfgLg/gLIgQgDIiMgaIgXgFQgxgLgegNQg3gXgZgqQgcguAGhPIAAgDQADgrALgkQAMgsAWghQANgVARgQQAVgUATgMQAWgOAXgGQALgEAUgCIAfgGQAVgFAUgKQAPgHAPgLIANgMQAWgUARgZIADgFQAKgQAOgfIACgFQAOgeAKgQIAFgGQALgRAPgNQASgRAXgNQAcgRAjgKIAfgJIAkgHQATgDAUgBIAfgBIAVABQANAAAMACQAUADAOAHQAlAQAVAsQANAbAFAgIADAfIABAeIABAlIABAWIAAAJIADAdQADAZAGATQAFAPAJASQAMAZATAfIAKAQQAiA3AHASIAKAaQAOApADAuIAAAZQAAAugMArIgIAZQgKAbgPAXIgKAOQgNATgUASIgOAMQgQAOgPALQgUANgSAIIgNAFQgiALgmAAIgHAAg");
	this.shape_126.setTransform(219.1221,204.1787);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#070707").s().p("ADlHgQgZAAgagGQgTgEgUgHQgUgIgWgKIgfgQIgvgaIgXgMQgggQgcgIIgVgGIgsgIIg2gIIgMgCQgsgHgogJQgYgGgVgGQg8gRgigWQgTgMgOgOQgXgXgKgbQgLgcABgxIAAgBQABgxAKgnQAIgnAQgfIAGgLQAKgTAMgQQAJgLAKgKIAGgIQAbgaAegPQAMgFASgEIAkgJIAIgCQAcgHASgGIAMgFQAqgTAbgpIAEgHQALgRAMgbIAEgIQAOggAIgMIADgEQARgaAagUIAQgMQATgOATgKQATgKAUgHIAUgHIASgGIAUgEQAfgHAjABQAZAAAZAEIADAAQAfAEAVAJIAMAGQAcAQARAgIAHAPQANAgAEAmIACAOIABAZIACAlIABAUQABAdAEAWQACAPAEAMQAGAUALAaQAOAcAVAmIAEAGQAZArANAeQAKAVAEAOQAHAUADAVQAGAeAAAgIgCAXQgDAqgNAmIgEALQgIAWgMAUQgJAQgMAOQgLAQgOANQgZAYgeAVQgNAJgNAHQgbAPgbAFQgSAEgVAAIgEAAgACdnVQgUABgSADIgkAHIggAJQgiALgcARQgXANgSAQQgPAOgMAQIgEAGQgKAQgOAeIgCAFQgPAggKAQIgCAFQgRAZgWATIgOAMQgOALgPAIQgUAKgWAFIgeAFQgVADgKADQgYAHgVANQgUAMgVAVQgQAQgOAUQgWAigMArQgKAkgEAsIAAADQgGBPAcAtQAaAqA3AYQAdANAxALIAYAEICMAbIAPACQA/AMAfALIACAAQAWAIAfASIAbAPQAUANARAIQAaAPATAHQAYAJAZAFQAUADAVABQAqABAlgNIAMgFQATgHAUgOQAOgKAQgOIAOgNQAUgSAOgTIAJgNQAPgXAKgcIAIgYQAMgrABguIgBgaQgCgtgOgqIgKgZQgIgSgig4IgJgQQgTgfgNgZQgIgSgFgPQgGgSgDgZIgDgeIgBgJIgBgVIgBglIAAgfIgEgfQgFgggNgbQgVgsgkgQQgOgGgVgDQgLgCgOgBIgUgBIggABg");
	this.shape_127.setTransform(219.1707,204.2255);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["rgba(157,200,219,0.698)","#FFFFFF"],[0,1],-49.3,0,49.3,0).s().p("ADnHmQgwgDgtgUQgegOg4gnQg2glgggOQgjgPhMgPIiNgcQhDgMgkgQQg5gYgZgrQgagtAGhUQALiFA/hBQAngnAzgLQALgCAWgCQAYgCAKgCQAqgGAlgYQAkgZAXgkQALgQAQglQAQgkALgRQArhCBWgbQBAgTBiADQAmACAWAJQAnAQAXAtQATAmADAzQABAOgCBNQgBA4AIAiQAJAoAgA4QAqBIAJATQAXA2AEA7QAEA8gPA4QgMAqgVAiQgVAigjAiQgkAkghAPQglASguAAIgJAAg");
	this.shape_128.setTransform(219.226,205.9575);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("ABkHCIhSgzQgvgeglgNQgcgKgmgHIhDgLQhHgMg7gQQg9gQgjgWQgygfgQguQgKgbABgzQAChkAcg+QASgoAcgdQAeggAlgPQAXgIAygHQAxgHAXgJQAugSAdgpQAMgRAOgiQARgoAIgOQAWgmAmgcQAigcAsgPQBMgbBlAKQAsADAaAOQAkATATArQARAlADAwIgBBWQgBA1AHAhQAJAuAoBIQAtBRAMAhQARAyAAA2QAAA2gRAyQgjBnhYBBQgpAfgnAJQgSAEgUAAQhAAAhQgugAA9nVQhWAbgsBCQgLARgQAkQgQAlgKAQQgXAkglAZQgkAYgqAGQgLACgXACQgWACgMACQgyALgnAnQhABBgKCFQgHBUAaAtQAZArA5AYQAlAQBDAMICNAcQBMAPAjAPQAgAOA1AlQA5AnAdAOQAuAUAvADQAzACAqgUQAggPAkgkQAjgiAVgiQAVgiAMgqQAQg4gEg8QgEg7gYg2QgIgTgqhIQggg4gKgoQgIgiABg4QAChNgBgOQgCgzgUgmQgWgtgngQQgWgJgngCIgdAAQhPAAg1AQg");
	this.shape_129.setTransform(219.2955,205.993);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("rgba(0,0,0,0.067)").ss(0.1,1,1).p("AnvBrQABhiAag+QARgnAbgeQAcggAkgQQATgIAjgHQA/gLAXgKQAtgTAcgoQANgRAPghQARgmAJgNQAWgiAigaQAngeAsgOQBMgaBjAKQArAEAaAOQAWALAQAUQAKANAIAQQASAkAEAuQACAPABBGQAAAzAIAgQAJArAhA+QADAGADAGQArBQALAiQAQAygBA1QgBA1gRAyQgGARgHARQgkBPhJA1QgoAfgmAJQg3AOhGgZQgbgKgdgPQg1gggdgQQgugcglgNQgcgJglgIQgEgBg+gKQgHgCgIgBQg9gMg0gPQg7gSgigWQgxgggQgtQgKgcAAgxgAnmBQQAHiDA9hCQAlgoAwgNQALgDAVgCQAegFADgBQAogIAkgYQAkgZAXgjQALgRARgiQAQgjAMgRQAZgkAngXQAcgSAmgMQBAgSBgAEQAmACAWAJQAmAQAYArQABADACADQARAiAFAuQADAOgBBLQABA1AJAjQAKAnAfA4QAHANAHALQAcAyAHARQAWA2ADA6QAEA7gQA4QgLAlgSAfQgCADgCAEQgVAigiAhQgjAjghAQQgoAUgyAAQgvgCgtgSQgHgDgJgEQgcgOgqgbQg1gjghgNQgkgOhKgQQgvgJgugLQgXgFgXgEQhBgNgkgSQg3gYgZgrQgagtAFhRg");
	this.shape_130.setTransform(223.2496,205.947);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["rgba(157,200,219,0.718)","#FBFDFE"],[0,1],-48.6,-1.3,48.5,1.6).s().p("ADlHgQgvgBgtgSIgQgIQgcgNgqgbQg1gjghgNQgkgPhKgPIhdgUIgugKQhBgNgkgRQg3gZgZgrQgagtAFhRIAAgBQAHiCA9hDQAlgoAwgMQALgDAVgDIAhgFQAogIAkgZQAkgYAXgkQALgQARgjQAQgjAMgRQAZgjAngYQAcgSAmgLQBAgTBgAEQAmADAWAIQAmAQAYArIADAGQARAjAFAtQADAPgBBKQABA2AJAiQAKAoAfA3IAOAZQAcAyAHAQQAWA2ADA6QAEA8gQA3QgLAlgSAfIgEAHQgVAigiAiQgjAjghAPQgnAUgxAAIgCAAg");
	this.shape_131.setTransform(223.2169,205.865);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["#0A0D0F","#0D0F10"],[0,1],17.1,-21.1,92.6,22.5).s().p("ACZHaQgbgKgdgPQg1gggdgQQgugcglgNQgcgJglgIIhCgLIgPgDQg9gMg0gPQg7gSgigWQgxgggQgtQgKgcAAgxIAAgBQABhiAag+QARgnAbgeQAcggAkgQQATgIAjgHQA/gLAWgKQAugTAcgoQANgRAPghQARgmAJgNQAWgiAigaQAngeAsgOQBMgaBjAKQArAEAaAOQAWALAQAUQAKANAIAQQASAkAEAuQACAPABBGQAAAzAIAgQAJArAhA+IAFAMQAsBQALAiQAQAygBA1QgBA1gRAyQgGARgHARQglBPhIA1QgoAfgmAJQgUAFgWAAQgnAAgsgQgAA1nRQgmAMgdASQgmAXgZAkQgMARgQAjQgRAigLARQgXAjgkAZQgkAYgoAIIghAGQgVACgLADQgwANgmAoQg8BCgHCDIAAABQgFBRAaAtQAZArA3AYQAkASBBANIAtAJIBeAUQBKAQAkAOQAhANA1AjQAqAbAcAOIAQAHQAtASAuACQAzAAAogUQAggQAkgjQAighAVgiIAEgHQARgfAMglQAQg4gEg7QgDg6gWg2QgHgRgdgyIgNgYQgfg4gKgnQgJgjgBg1QABhLgDgOQgFgugRgiIgDgGQgYgrgmgQQgWgJgmgCIgigBQhKAAg0APg");
	this.shape_132.setTransform(223.2496,205.947);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("rgba(0,0,0,0.133)").ss(0.2,1,1).p("AnqBsQgBhgAZg+QAQgoAZgeQAbggAjgRQARgJAigIQA8gOAXgLQArgTAdgnQANgRAQgfQARgkALgOQAWghAigYQApgdAqgNQBMgYBhALQArAEAaAOQAVALARATQAKANAIAPQATAjAGAtQAEAPACBDQACAyAIAgQAKAqAgA9QACAGAEAGQApBPAKAkQAPAxgCA1QgBAzgSAyQgGARgHAQQglBOhHA1QgnAegmAKQg2APhFgXQgbgIgdgOQg0gdgegPQgugaglgNQgbgJglgIQgFgCg7gKQgIgCgHgCQg8gMgzgRQg5gSgigYQgvgfgQgtQgKgcgBgwgAniBTQAFiAA5hFQAjgoAugPQALgEAUgDQAdgGADgBQAngKAigYQAjgZAYgiQAMgRAQghQARgiANgQQAagiAmgWQAdgSAlgLQBBgSBeAGQAlACAWAJQAnAPAYAqQABADACACQATAiAFAsQAFAPACBHQADA0AJAjQAMAnAdA2QAHANAGAMQAbAwAHASQAVA2ADA5QACA7gQA3QgLAkgSAgQgCADgCADQgUAigiAhQgiAjggAQQgpAVgxAAQgtABgtgRQgHgCgJgEQgcgMgqgZQg0gggigMQgkgPhIgPQgvgKgugLQgWgFgXgGQg/gOgkgSQg1gZgZgrQgbgtAEhPg");
	this.shape_133.setTransform(227.2049,205.8887);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["rgba(157,200,219,0.737)","#F7FBFC"],[0,1],-47.8,-2.6,47.7,3.2).s().p("ACIHKIgPgGQgdgMgpgZQg1ggghgMQglgPhIgPIhdgVIgsgLQg/gOgkgSQg2gZgZgrQgagtADhPIAAgBQAGiAA5hFQAjgoAugPQALgEAUgDIAfgHQAngKAjgYQAjgZAXgiQAMgRARghQARgiANgQQAZgiAngWQAdgSAlgLQBAgSBeAGQAlACAXAJQAmAPAYAqIADAFQATAiAGAsQAFAPABBHQADA0AKAjQALAnAeA2IANAZQAbAwAGASQAVA2ADA5QADA7gQA3QgLAkgSAgIgEAGQgVAighAhQgjAjggAQQgoAVgxAAIgDAAQgsAAgsgQg");
	this.shape_134.setTransform(227.1965,205.7614);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["#151B1D","#1A1E1F"],[0,1],13.1,-21,88.6,22.6).s().p("ACWHWQgbgIgdgOQg0gdgegPQgugaglgNQgbgJglgIQgFgCg7gKIgPgEQg8gMgzgRQg5gSgigYQgvgfgQgtQgKgcgBgwIAAgBQgBhgAZg+QAQgoAZgeQAbggAjgRQARgJAigIQA8gOAXgLQArgTAdgnQANgRAQgfQARgkALgOQAWghAigYQApgdAqgNQBMgYBhALQArAEAaAOQAVALARATQAKANAIAPQATAjAGAtQAEAPACBDQACAyAIAgQAKAqAgA9IAGAMQApBPAKAkQAPAxgCA1QgBAzgSAyQgGARgHAQQglBOhHA1QgnAegmAKQgWAGgYAAQgkAAgpgOgAAsnNQglALgdASQgmAWgaAiQgNAQgRAiQgQAhgMARQgYAigjAZQgiAYgnAKIggAHQgUADgLAEQguAPgjAoQg5BFgFCAIAAABQgEBPAbAtQAZArA1AZQAkASA/AOIAtALIBdAVQBIAPAkAPQAiAMA0AgQAqAZAcAMIAQAGQAtARAtgBQAxAAApgVQAggQAigjQAighAUgiIAEgGQASggALgkQAQg3gCg7QgDg5gVg2QgHgSgbgwIgNgZQgdg2gMgnQgJgjgDg0QgChHgFgPQgFgsgTgiIgDgFQgYgqgngPQgWgJglgCIgqgCQhDAAgyAOg");
	this.shape_135.setTransform(227.2049,205.8887);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("rgba(0,0,0,0.2)").ss(0.2,1,1).p("AnkBsQgCheAXg/QAOgnAYgeQAaghAhgSQARgKAhgJQA4gPAXgMQAqgVAdgmQAOgRAQgdQASgjALgNQAXgfAjgYQAogbAqgMQBMgXBgAMQApAFAbANQAVALARATQAKAMAJAPQATAiAIArQAFAQAEBAQAEAwAIAgQAMAqAeA8QACAGADAGQAoBNAJAlQANAxgCA0QgCAzgSAxQgGARgHAQQglBNhGA0QgmAegmALQg2APhEgUQgagHgcgNQg0gagegOQgugYgmgNQgbgJgkgIQgGgCg5gLQgHgCgIgCQg7gNgxgSQg3gTghgYQgughgQgsQgLgcgBgvgAndBVQADh+A2hGQAhgoAsgRQAKgFATgEQAbgHADgBQAmgMAhgYQAigaAZghQAMgRARgfQASggANgQQAbghAmgVQAdgRAlgKQBBgRBcAGQAkADAXAIQAmAQAZAnQABADACADQAUAgAHAqQAHAQAEBEQAEAyALAjQAMAnAcA2QAHANAGALQAZAvAHATQAUA2ACA5QACA6gQA2QgMAkgRAfQgCADgCAEQgVAhghAhQghAiggARQgoAVgwACQgtABgsgOQgHgCgJgEQgdgKgpgXQgzgdgjgMQglgNhGgQQgugKgugMQgWgGgVgFQg+gPgjgUQg0gagZgqQgbguAChNg");
	this.shape_136.setTransform(231.1299,205.8547);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["rgba(157,200,219,0.757)","#F3F8FB"],[0,1],-47.2,-3.9,46.8,4.8).s().p("ACHHIIgPgGQgdgKgpgXQg0gdgigMQgmgNhGgQQgugKgtgMIgsgLQg9gPgkgUQg0gagZgqQgaguAChNIAAgBQACh+A2hGQAhgoAsgRQALgFATgEIAegIQAlgMAigYQAigaAYghQANgRARgfQARggAOgQQAaghAngVQAdgRAkgKQBBgRBcAGQAlADAWAIQAmAQAZAnIADAGQAUAgAIAqQAHAQADBEQAFAyAKAjQAMAnAdA2IAMAYQAaAvAGATQAUA2ACA5QACA6gQA2QgLAkgSAfIgEAHQgUAhghAhQgiAiggARQgnAVgwACIgJAAQgpAAgogNg");
	this.shape_137.setTransform(231.1791,205.679);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["#1F282C","#272C2F"],[0,1],9.2,-21,84.7,22.6).s().p("ACTHSQgagHgcgNQg0gagegOQgugYgmgNQgbgJgkgIIg/gNIgPgEQg7gNgxgSQg3gTghgYQgughgQgsQgLgcgBgvIAAgBQgCheAXg/QAOgnAYgeQAaghAhgSQARgKAhgJQA4gPAXgMQAqgVAdgmQAOgRAQgdQASgjALgNQAXgfAjgYQAogbAqgMQBMgXBgAMQApAFAbANQAVALARATQAKAMAJAPQATAiAIArQAFAQAEBAQAEAwAIAgQAMAqAeA8IAFAMQAoBNAJAlQANAxgCA0QgCAzgSAxQgGARgHAQQglBNhGA0QgmAegmALQgYAHgaAAQghAAgngMgAAlnJQglAKgdARQgmAVgbAhQgNAQgSAgQgRAfgMARQgZAhgiAaQghAYgmAMIgeAIQgTAEgKAFQgsARghAoQg2BGgDB+IAAABQgCBNAbAuQAZAqA0AaQAjAUA+APIArALQAuAMAuAKQBGAQAlANQAjAMAzAdQApAXAdAKIAQAGQAsAOAtgBQAwgCAogVQAggRAhgiQAhghAVghIAEgHQARgfAMgkQAQg2gCg6QgCg5gUg2QgHgTgZgvIgNgYQgcg2gMgnQgLgjgEgyQgEhEgHgQQgHgqgUggIgDgGQgZgngmgQQgXgIgkgDQgYgCgWAAQg/AAgwANg");
	this.shape_138.setTransform(231.1299,205.8547);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("rgba(0,0,0,0.267)").ss(0.3,1,1).p("AnfBtQgDhcAVg/QANgnAXgfQAYghAggUQAQgKAfgKQA2gSAXgNQApgVAdglQAOgQAQgdQATghAMgNQAYgdAjgXQApgZApgMQBMgVBeANQAoAFAbAOQAVAKARASQALAMAIAOQAVAhAJAqQAIAQAFA9QAFAuAJAhQAMAqAdA7QADAGADAGQAlBKAIAnQANAxgDAzQgDAzgSAvQgGARgIAQQglBMhEA0QgmAdgmAMQg1AQhCgRQgbgGgcgLQgzgYgfgNQgtgWgmgNQgbgJgjgIQgIgDg2gLQgHgCgIgCQg5gOgxgUQg1gUgggZQgsgggRgsQgLgcgBgugAnYBYQAAh7AzhIQAfgpAqgTQAJgFASgFQAbgJACgBQAkgNAhgZQAhgaAZghQANgQASgeQARgfAPgPQAbgfAngVQAegQAjgJQBCgQBaAGQAjADAXAJQAmAPAZAnQACACACADQAUAfAKApQAIAQAGBAQAGAxALAjQANAnAcA1QAGAMAGALQAYAuAGAVQATA1ACA4QABA5gRA2QgLAkgSAeQgBAEgCADQgVAiggAgQghAiggARQgmAVgwAEQgsACgsgMQgHgBgIgDQgegJgogVQgzgagjgLQgngNhEgQQgtgLgtgMQgWgGgVgHQg7gQgjgUQgzgbgZgqQgaguAAhMg");
	this.shape_139.setTransform(235.0795,205.8078);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["rgba(157,200,219,0.78)","#EFF6F9"],[0,1],-46.4,-5.3,46,6.3).s().p("ACGHFIgPgEQgegJgogVQgzgagjgLQgngNhEgQQgtgLgtgMIgrgNQg7gQgjgUQgzgbgZgqQgaguAAhMIAAAAQAAh7AzhIQAfgpAqgTQAJgFASgFIAdgKQAkgNAhgZQAhgaAZghQANgQASgeQARgfAPgPQAbgfAngVQAegQAjgJQBCgQBaAGQAjADAXAJQAmAPAZAnIAEAFQAUAfAKApQAIAQAGBAQAGAxALAjQANAnAcA1IAMAXQAYAuAGAVQATA1ACA4QABA5gRA2QgLAkgSAeIgDAHQgVAiggAgQghAiggARQgmAVgwAEIgPAAQgkAAglgKg");
	this.shape_140.setTransform(235.1529,205.6027);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["#2A353A","#343B3E"],[0,1],5.2,-21,80.7,22.6).s().p("ACRHPQgbgGgcgLQgzgYgfgNQgtgWgmgNQgbgJgjgIQgIgDg2gLIgPgEQg5gOgxgUQg1gUgggZQgsgggRgsQgLgcgBguIgBgBQgDhcAVg/QANgnAXgfQAYghAggUQAQgKAfgKQA2gSAXgNQApgVAdglQAOgQAQgdQATghAMgNQAYgdAjgXQApgZApgMQBMgVBeANQAoAFAbAOQAVAKARASQALAMAIAOQAVAhAJAqQAIAQAFA9QAFAuAJAhQAMAqAdA7IAGAMQAlBKAIAnQANAxgDAzQgDAzgSAvIgOAhQglBMhEA0QgmAdgmAMQgaAIgdAAQgfAAghgJgAAdnFQgjAJgeAQQgnAVgbAfQgPAPgRAfQgSAegNAQQgZAhghAaQghAZgkANIgdAKQgSAFgJAFQgqATgfApQgzBIAAB7IAAAAQAABMAaAuQAZAqAzAbQAjAUA7AQIArANQAtAMAtALQBEAQAnANQAjALAzAaQAoAVAeAJIAPAEQAsAMAsgCQAwgEAmgVQAggRAhgiQAgggAVgiIADgHQASgeALgkQARg2gBg5QgCg4gTg1QgGgVgYguIgMgXQgcg1gNgnQgLgjgGgxQgGhAgIgQQgKgpgUgfIgEgFQgZgngmgPQgXgJgjgDQgagBgYAAQg7AAgvALg");
	this.shape_141.setTransform(235.0795,205.8078);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("rgba(0,0,0,0.333)").ss(0.4,1,1).p("AnZBuQgGhbAUg/QANgnAVgfQAXghAegVQAQgMAdgLQAzgTAWgOQAogWAegkQAOgQARgbQATgfANgNQAZgdAjgVQApgYApgLQBMgTBcANQAnAGAbAOQAVAKARASQALALAJAOQAWAfAKAoQAKASAGA5QAHAtAKAhQANApAbA6QADAGADAGQAjBJAIAoQALAxgEAzQgEAxgRAvQgHAQgHAQQglBMhEAzQglAdglAMQg0ARhCgOQgbgGgbgJQgygWgggLQgtgVgmgMQgbgJgigIQgKgEgzgLQgHgCgIgCQg4gQgvgUQg0gVgggaQgqghgQgrQgLgcgDgtgAnTBaQgDh4AwhKQAdgpAngVQAKgGARgFQAZgLADgBQAigPAggZQAggaAZggQAOgQASgdQASgdAQgPQAcgdAmgUQAegPAjgJQBCgQBYAIQAjADAXAJQAlAPAbAlQABACACADQAWAeALAnQALARAHA9QAIAvAMAiQAOAnAaA0QAGANAGALQAXAtAGAVQASA1AAA4QABA4gRA2QgLAjgSAeQgCADgCAEQgUAhgfAgQghAigfARQgmAWguAFQgsAEgrgKQgHgCgJgCQgegIgogSQgygYgkgKQgngMhCgQQgtgLgsgOQgWgGgUgHQg6gRgjgVQgxgcgYgqQgbgugBhKg");
	this.shape_142.setTransform(239.0079,205.765);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["rgba(157,200,219,0.8)","#EBF4F8"],[0,1],-45.7,-6.6,45.2,7.9).s().p("ACGHDIgQgEQgegHgogTQgygXgkgLQgngMhCgQQgtgLgsgNIgqgNQg6gRgjgWQgxgbgYgqQgbgugBhLIAAAAQgDh5AwhJQAdgpAngWQAKgGARgFIAcgMQAigPAggZQAggaAZgfQAOgRASgcQASgdAQgPQAcgeAmgTQAegQAjgJQBCgPBYAIQAjADAXAJQAlAPAbAkIADAFQAWAeALAnQALARAHA9QAIAvAMAjQAOAnAaA0IAMAXQAXAtAGAWQASA1AAA3QABA5gRA1QgLAjgSAfIgEAGQgUAigfAgQghAhgfASQgmAVguAFIgZABQgfAAgfgHg");
	this.shape_143.setTransform(239.1195,205.546);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["#344349","#414A4E"],[0,1],1.3,-20.9,76.8,22.7).s().p("ACOHMQgbgGgbgJQgygWgggLQgtgVgmgMQgbgJgigIQgKgEgzgLIgPgEQg4gQgvgUQg0gVgggaQgqghgQgrQgLgcgDgtIAAgBQgGhbAUg/QANgnAVgfQAXghAegVQAQgMAdgLQAzgTAWgOQAogWAegkQAOgQARgbQATgfANgNQAZgdAjgVQApgYApgLQBMgTBcANQAnAGAbAOQAVAKARASQALALAJAOQAWAfAKAoQAKASAGA5QAHAtAKAhQANApAbA6IAGAMQAjBJAIAoQALAxgEAzQgEAxgRAvIgOAgQglBMhEAzQglAdglAMQgdAJggAAQgbAAgegGgAAVnBQgjAJgeAPQgmAUgcAdQgQAPgSAdQgSAdgOAQQgZAgggAaQggAZgiAPIgcAMQgRAFgKAGQgnAVgdApQgwBKADB4IAAABQABBKAbAuQAYAqAxAcQAjAVA6ARIAqANQAsAOAtALQBCAQAnAMQAkAKAyAYQAoASAeAIIAQAEQArAKAsgEQAugFAmgWQAfgRAhgiQAfggAUghIAEgHQASgeALgjQARg2gBg4QAAg4gSg1QgGgVgXgtIgMgYQgag0gOgnQgMgigIgvQgHg9gLgRQgLgngWgeIgDgFQgbglglgPQgXgJgjgDQgegCgbAAQg1AAgsAKg");
	this.shape_144.setTransform(239.0079,205.765);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("rgba(0,0,0,0.4)").ss(0.4,1,1).p("AnOBcQgFh1AthMQAagpAmgYQAJgGAQgGQAYgMACgCQAhgQAfgZQAggbAZgfQAOgQATgbQATgbAQgPQAcgcAngTQAegOAjgJQBCgOBWAIQAiAEAXAJQAlAPAcAiQABADACACQAXAdANAlQANASAIA6QAKAtANAjQAPAnAZAzQAGAMAFALQAWAtAGAVQAQA1AAA3QAAA4gRA1QgLAigRAeQgCAEgCADQgVAhgeAgQggAhgfASQglAWguAGQgqAFgrgIQgHgBgJgCQgegFgngRQgygUglgLQgogLhAgQQgsgLgsgPQgVgGgUgHQg4gSgigXQgwgcgYgqQgbgugDhJgAnTBuQgHhZAShAQALgmAUggQAWghAcgWQAQgMAbgMQAwgWAXgOQAmgYAegiQAOgRASgZQATgeAPgMQAZgbAjgUQAqgXAogKQBMgSBaAPQAmAFAcAOQAUALASAQQALALAJAOQAXAeAMAmQALASAIA3QAJArALAhQANApAaA5QADAGACAGQAiBHAGAqQAKAwgEAyQgEAxgSAuQgHAQgHAQQgmBLhCAyQgkAdglAMQg0AShAgLQgbgEgbgJQgxgSghgLQgsgTgngMQgbgJghgIQgLgEgxgLQgHgDgHgCQg3gRgugVQgygWgfgbQgpghgRgrQgLgcgDgrg");
	this.shape_145.setTransform(242.9341,205.7507);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["rgba(157,200,219,0.82)","#E7F2F6"],[0,1],-45,-7.9,44.4,9.5).s().p("ACFHAIgPgDQgfgFgngRQgxgUglgLQgogLhAgQQgtgLgsgPIgpgNQg3gSgjgXQgvgcgZgqQgbgugChJIAAgBQgFh1AshMQAbgpAlgYQAJgGAQgGIAbgOQAhgQAegZQAggbAagfQAOgQASgbQATgbARgPQAcgcAmgTQAfgOAigJQBDgOBWAIQAhAEAYAJQAlAPAbAiIAEAFQAXAdAMAlQANASAJA6QAKAtANAjQAPAnAZAzIALAXQAVAtAGAVQARA1AAA3QAAA4gRA1QgMAigRAeIgEAHQgUAhgfAgQgfAhgfASQgmAWgtAGQgRACgSAAQgZAAgagFg");
	this.shape_146.setTransform(243.0747,205.48);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["#3F5058","#4E595D"],[0,1],-2.6,-20.9,72.9,22.7).s().p("ACMHIQgbgEgbgJQgxgSghgLQgsgTgngMQgbgJghgIQgLgEgxgLIgOgFQg3gRgugVQgygWgfgbQgpghgRgrQgLgcgDgrIAAgCQgHhZAShAQALgmAUggQAWghAcgWQAQgMAbgMQAwgWAXgOQAmgYAegiQAOgRASgZQATgeAPgMQAZgbAjgUQAqgXAogKQBMgSBaAPQAmAFAcAOQAUALASAQQALALAJAOQAXAeAMAmQALASAIA3QAJArALAhQANApAaA5IAFAMQAiBHAGAqQAKAwgEAyQgEAxgSAuIgOAgQgmBLhCAyQgkAdglAMQggALgkAAQgXAAgZgEgAAOm+QgjAJgeAOQgnATgcAcQgQAPgTAbQgTAbgOAQQgZAfggAbQgfAZghAQIgaAOQgQAGgJAGQgmAYgaApQgtBMAFB1IAAABQADBJAbAuQAYAqAwAcQAiAXA4ASIApANQAsAPAsALQBAAQAoALQAlALAyAUQAnARAeAFIAQADQArAIAqgFQAugGAlgWQAfgSAgghQAeggAVghIAEgHQARgeALgiQARg1AAg4QAAg3gQg1QgGgVgWgtIgLgXQgZgzgPgnQgNgjgKgtQgIg6gNgSQgNglgXgdIgDgFQgcgiglgPQgXgJgigEQgggDgdAAQgxAAgqAJg");
	this.shape_147.setTransform(242.9341,205.7507);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("rgba(0,0,0,0.467)").ss(0.5,1,1).p("AnJBfQgIhzAqhNQAYgqAkgaQAIgHAPgHQAXgNACgCQAggSAegZQAfgbAZgeQAPgQATgaQATgaASgOQAdgbAmgRQAfgOAigIQBDgNBUAJQAhAEAXAJQAlAOAcAhQACADACACQAYAcAOAjQAPATAKA2QAMAsAOAiQAQAnAYAzQAFALAFALQAUAsAGAXQAQA0gBA2QgBA4gRA0QgLAigSAeQgBADgCADQgVAigdAfQgfAggfATQglAWgsAIQgqAGgrgFQgHgBgIgCQgfgEgngOQgxgSglgJQgpgLg+gQQgsgMgrgPQgVgHgUgIQg1gTgigXQgugdgZgqQgbgugEhHgAnOBvQgIhXAQhAQAKgmATghQAUghAbgXQAPgOAZgNQAugXAWgQQAlgYAeghQAPgRASgYQAUgcAQgMQAagZAjgTQAqgVAogKQBMgQBYAPQAlAGAcAOQAUALASAQQAMAKAJANQAYAdAOAlQAMATAKAzQAKAqAMAgQAOAqAZA3QACAGADAGQAfBGAGArQAJAwgFAxQgGAwgSAuQgGAQgIAPQglBKhBAyQgkAcglANQgzATg/gJQgagDgcgHQgwgQgigJQgrgRgngMQgbgJghgIQgMgFgugLQgHgDgHgDQg2gRgtgXQgwgXgegcQgngggRgrQgMgcgDgqg");
	this.shape_148.setTransform(246.8698,205.7193);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["rgba(157,200,219,0.839)","#E3F0F5"],[0,1],-44.2,-9.3,43.6,11).s().p("ACFG+IgQgDQgfgEgmgOQgxgSgmgJIhngbQgsgMgrgPIgogPQg2gTgigXQgugdgYgqQgbgugFhHIAAgBQgHhzAphNQAZgqAjgaQAJgHAPgHIAZgPQAfgSAegZQAfgbAageQAPgQATgaQATgaARgOQAdgbAngRQAegOAigIQBDgNBUAJQAhAEAYAJQAlAOAcAhIADAFQAYAcAPAjQAOATALA2QAMAsAOAiQAPAnAYAzIALAWQAUAsAGAXQAPA0AAA2QgBA4gRA0QgMAigRAeIgEAGQgUAigeAfQgfAggfATQgkAWgtAIQgWADgXAAQgTAAgUgCg");
	this.shape_149.setTransform(247.0184,205.446);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["#495D66","#5B686D"],[0,1],-6.6,-20.9,68.9,22.7).s().p("ACJHEQgagDgcgHQgwgQgigJQgrgRgngMQgbgJghgIQgMgFgugLIgOgGQg2gRgtgXQgwgXgegcQgngggRgrQgMgcgDgqIgBgCQgIhXAQhAQAKgmATghQAUghAbgXQAPgOAZgNQAugXAWgQQAlgYAeghQAPgRASgYQAUgcAQgMQAagZAjgTQAqgVAogKQBMgQBYAPQAlAGAcAOQAUALASAQQAMAKAJANQAYAdAOAlQAMATAKAzQAKAqAMAgQAOAqAZA3IAFAMQAfBGAGArQAJAwgFAxQgGAwgSAuIgOAfQglBKhBAyQgkAcglANQgiANgpAAQgTAAgUgDgAAGm6QgiAIgfAOQgmARgdAbQgSAOgTAaQgTAagPAQQgZAegfAbQgeAZggASIgZAPQgPAHgIAHQgkAagYAqQgqBNAIBzIAAABQAEBHAbAuQAZAqAuAdQAiAXA1ATIApAPQArAPAsAMIBnAbQAlAJAxASQAnAOAfAEIAPADQArAFAqgGQAsgIAlgWQAfgTAfggQAdgfAVgiIADgGQASgeALgiQARg0ABg4QABg2gQg0QgGgXgUgsIgKgWQgYgzgQgnQgOgigMgsQgKg2gPgTQgOgjgYgcIgEgFQgcghglgOQgXgJghgEQgigEgfAAQguAAgoAIg");
	this.shape_150.setTransform(246.8698,205.7193);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("rgba(0,0,0,0.533)").ss(0.6,1,1).p("AlIEsQgMgIgKgHQgsgdgZgqQgbgvgGhFIAAgBQgKhwAmhPQAWgqAigcQAIgIAOgIQAWgOACgCQAegUAdgaQAegbAagdQAQgQATgYQAUgYASgOQAegZAmgRQAfgNAigHQBDgNBSAKQAgAEAYAJQAkAPAdAfQACACACACQAZAbAQAiQARATAMAzQAOAqAOAjQARAmAXAyQAFAMAFAKQATArAFAXQAPA1gCA2QgBA2gSA0QgLAhgRAeQgCADgCAEQgUAhgdAfQgeAggfATQgkAXgsAIQgoAIgqgEQgIAAgIgBQgfgDgngMQgxgPglgJQgqgKg8gQQgrgMgrgQQgUgHgTgIQgWgIgTgKQgFgCgFgDQgCgBgDgCQgEgCgEgCQgigTgXgXQglgigRgqQgMgcgFgpIAAgCQgKhVAPhBQAJgmASggQASghAagZQAOgOAYgOQArgaAVgQQAkgaAeggQAQgQASgXQAUgaASgMQAbgYAjgRQAqgVAngIQBMgPBWAQQAlAHAcAOQAUAKASAPQALAKAKANQAZAcAPAjQAPATALAxQAMAoAMAhQAPApAYA2QACAGACAGQAeBEAFAtQAHAvgGAxQgFAvgTAtQgGAQgIAPQgmBJg/AyQgjAbgkAOQgzATg+gGQgbgBgagGQgwgNgigJQgsgPgmgMQgcgIgfgJQgOgFgrgMQgIgDgHgDQgygRgqgXQgCgBgCgBQgDgBgDgC");
	this.shape_151.setTransform(250.7583,205.7091);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["#546B75","#69767C"],[0,1],20.6,-51.8,96.1,-8.2).s().p("AgEgCIAFACIAEADIgJgFg");
	this.shape_152.setTransform(219.6875,236.675);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["rgba(157,200,219,0.859)","#E0EDF3"],[0,1],-43.3,-11,43,12.2).s().p("ACHHAQgbgBgagGIhSgWQgsgPgmgMIg7gRQgOgFgrgMIgPgGQgygRgqgXQATAKAWAIIAnAPQArAQArAMIBmAaQAlAJAxAPQAnAMAfADIAQABIAcACIAAAAIAAAAQAaAAAZgFIADgBQAsgIAkgXQAfgTAeggQAdgfAUghIAEgHQARgeALghQASg0ABg2IABgKQAAgxgOgwQgFgXgTgrIgKgWIgohYQgOgjgOgqQgMgzgRgTQgQgigZgbIgEgEQgdgfgkgPQgYgJgggEIgDAAIgDAAIgBAAQghgEgeAAIAAAAIgBAAQgpAAglAHQgiAHgfANQgmARgeAZQgSAOgUAYQgTAYgQAQQgaAdgeAbQgdAageAUIgYAQQgOAIgIAIQgiAcgWAqQgeA+AABTQAAAWACAYIAAABQAGBFAbAvQAZAqAsAdIAWAPQgigTgXgXQglgigRgqQgMgcgFgpIAAgCQgKhVAPhBQAJgmASggQASghAagZQAOgOAYgOQArgaAVgQQAkgaAeggQAQgQASgXQAUgaASgMQAbgYAjgRQAqgVAngIQBMgPBWAQQAlAHAcAOQAUAKASAPQALAKAKANQAZAcAPAjQAPATALAxQAMAoAMAhQAPApAYA2IAEAMQAeBEAFAtQAHAvgGAxQgFAvgTAtQgGAQgIAPQgmBJg/AyQgjAbgkAOQgmAPguAAIgdgCgACjG5IgcgCIgQgBQgfgDgngMQgxgPglgJIhmgaQgrgMgrgQIgngPQgWgIgTgKIgEgCIgGgDIgFgDIgIgEIgWgPQgsgdgZgqQgbgvgGhFIAAgBQgCgYAAgWQAAhTAeg+QAWgqAigcQAIgIAOgIIAYgQQAegUAdgaQAegbAagdQAQgQATgYQAUgYASgOQAegZAmgRQAfgNAigHQAlgHApAAIABAAIAAAAQAeAAAhAEIABAAIADAAIADAAQAgAEAYAJQAkAPAdAfIAEAEQAZAbAQAiQARATAMAzQAOAqAOAjIAoBYIAKAWQATArAFAXQAOAwAAAxIgBAKQgBA2gSA0QgLAhgRAeIgEAHQgUAhgdAfQgeAggfATQgkAXgsAIIgDABQgZAFgaAAIAAAAIAAAAgAkxE4IAAAAg");
	this.shape_153.setTransform(250.7583,205.7091);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("rgba(0,0,0,0.6)").ss(0.6,1,1).p("AlQElQgFgDgEgEQgqgegZgqQgbgvgIhDQgMhvAjhQQAUgqAfgeQAIgJANgJQAUgQADgCQAcgVAcgaQAdgbAbgdQAQgQAUgWQAUgXATgNQAfgYAmgQQAfgMAigHQBDgMBQALQAfAFAYAJQAlAOAdAdQACACACADQAaAZASAgQASAUAPAwQAPAoAQAjQARAmAWAxQAFAMAEAKQASApAFAZQAOA1gCA1QgCA2gSAzQgMAhgRAdQgCADgCAEQgUAhgcAeQgdAggfAUQgjAXgrAKQgoAJgpgCQgIAAgIgBQgggBgmgJQgwgNgmgIQgrgJg6gRQgrgMgqgRQgUgIgSgIQgCgBgBAAQgCgBgCgBQgKgEgKgFQgDgBgDgCIgBAAQgBgBAAAAQgBAAAAgBQgDgBgCgBQgTgKgPgLQgZgRgTgTQgjgigRgqQgMgcgGgnIAAgDQgMhTAOhBQAIgmAQggQARgiAYgaQANgPAXgPQAogbAVgSQAjgaAeggQARgQASgVQAVgYASgMQAcgXAkgQQApgTAogHQBLgOBVARQAjAIAcANQAVAKASAPQALAKALALQAZAcARAhQAQAUANAuQANAmANAhQARApAWA1QACAGACAGQAbBCAFAuQAGAwgHAwQgGAugTAsQgGAQgIAPQgmBIg+AxQgiAbgkAPQgyAUg+gEQgaAAgagFQgvgKgigIQgsgNgngMQgbgIgfgJQgPgGgpgMQgHgDgHgDQgtgQglgVAkpE8QgFgCgEgDQgQgJgOgJAkoE9QgBAAAAAAIAAgBAknE+QgBgBgBAA");
	this.shape_154.setTransform(254.692,205.7023);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["#5E7883","#76858C"],[0,1],15.3,-52.5,90.8,-8.9).s().p("AAAAAIAAAAIABAAIgBAAg");
	this.shape_155.setTransform(225,237.425);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["rgba(157,200,219,0.878)","#DCEBF2"],[0,1],-42.5,-12.4,42.3,13.7).s().p("ACEG8QgaAAgagFIhRgSIhTgZIg6gRQgPgGgpgMIgOgGQgtgQglgVIAGADIAUAJIAEACIADABIAmAQQAqARArAMQA6ARArAJQAmAIAwANQAmAJAgABIAQABIACABIACAAIACAAIAFAAIAAAAIABAAQAgAAAggHIAFgBQArgKAjgXQAfgUAdggQAcgeAUghIAEgHQARgdAMghQASgzACg2IAAgNQAAgvgMguQgFgZgSgpIgJgWIgnhXQgQgjgPgoQgPgwgSgUQgSgggagZIgEgFQgdgdglgOQgYgJgfgFIgGAAIgBAAQgigFghAAIAAAAIgBAAQgkAAghAGIgDAAQgiAHgfAMQgmAQgfAYQgTANgUAXQgUAWgQAQQgbAdgdAbQgcAagcAVIgXASQgNAJgIAJQgfAegUAqQgaA7AABLQAAAbADAeQAIBDAbAvQAZAqAqAeIAJAHQgZgRgTgTQgjgigRgqQgMgcgGgnIAAgDQgMhTAOhBQAIgmAQggQARgiAYgaQANgPAXgPQAogbAVgSQAjgaAeggQARgQASgVQAVgYASgMQAcgXAkgQQApgTAogHQBLgOBVARQAjAIAcANQAVAKASAPQALAKALALQAZAcARAhQAQAUANAuQANAmANAhIAnBeIAEAMQAbBCAFAuQAGAwgHAwQgGAugTAsQgGAQgIAPQgmBIg+AxQgiAbgkAPQgrARgzAAIgSgBgACSG1IgFAAIgCAAIgCAAIgCgBIgQgBQgggBgmgJQgwgNgmgIQgrgJg6gRQgrgMgqgRIgmgQIgDgBIgEgCIgUgJIgGgDIgBAAIgBgBIgBgBIgJgFQgQgJgOgJIgJgHQgqgegZgqQgbgvgIhDQgDgeAAgbQAAhLAag7QAUgqAfgeQAIgJANgJIAXgSQAcgVAcgaQAdgbAbgdQAQgQAUgWQAUgXATgNQAfgYAmgQQAfgMAigHIADAAQAhgGAkAAIABAAIAAAAQAhAAAiAFIABAAIAGAAQAfAFAYAJQAlAOAdAdIAEAFQAaAZASAgQASAUAPAwQAPAoAQAjIAnBXIAJAWQASApAFAZQAMAuAAAvIAAANQgCA2gSAzQgMAhgRAdIgEAHQgUAhgcAeQgdAggfAUQgjAXgrAKIgFABQggAHggAAIgBAAIAAAAgAkmE+IAAAAgAkuE6QgTgKgPgLQAOAJAQAJIAJAFIgFgCg");
	this.shape_156.setTransform(254.692,205.7023);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("rgba(0,0,0,0.667)").ss(0.7,1,1).p("Al4D+QghghgRgpQgMgcgGgmIAAgCQgNhSALhBQAHgmAPghQAQghAXgcQAMgQAVgQQAlgdAWgTQAhgbAegeQARgQATgUQAVgXAUgLQAIgHAJgFIAGgEIACgBQABgBABgBQAGgDAFgDIAGgCQAKgFAKgEIAEgCQACgBADgBIAPgFQAYgIAZgEQBEgLBOALQAeAFAZAJQAkAOAeAcQACACACACQAbAZAUAeQAUAVAQAsQASAnAQAiQASAnAVAwQAFALAEAKQAQAoAFAbQAMAzgCA1QgDA1gSAzQgMAggRAdQgBAEgCADQgUAhgcAeQgcAfgfAUQgiAYgqALQgnAKgpABQgIAAgIAAQggABglgIQgwgJgngIQgsgJg4gQQgqgNgqgSQgTgIgSgJIgNgGQgEgCgDgBQgNgIgMgHQgPgJgNgJQgBgBgBgBQgJgGgHgHIgSgPQgFgFgEgFQgRgSgMgVQgbgvgJhCIAAAAQgPhsAfhSQASgrAeggQAHgJAMgKQATgRACgCQAbgXAbgaQAdgcAbgcQARgQAUgVQAUgVAVgNQAAAAABgBIAIgFQACgCACgBAhBmjQAdgLAdgEQBLgMBSASQAjAHAcAOQAUAKASAOQAMAJALALQAbAaASAgQASAVAOAqQAPAlAOAhQARApAVA0QACAGACAGQAZBBADAvQAGAvgIAvQgHAugTArQgGAQgIAOQgmBIg9AwQghAbgkAPQgyAVg8gBQgaABgagDQgugIgjgHQgsgLgngLQgbgIgegKQgRgGglgMQgIgDgHgEQgigOgdgQQgCgBgBAAQgegPgXgSQgDgCgCgCIgDgDQgGgEgEgEAhZmaQAEgCAFgCAh6mLQAHgDAGgDAh6mLQAEgCADgCAh+mJIAEgCAlvEIQgEgEgDgEQgBgBgBgBAlNEkQgCgBgBgBAkPFKQgCgBgCgBQgigRgYgT");
	this.shape_157.setTransform(258.5964,205.7461);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["#698592","#83949B"],[0,1],14.4,-49.9,89.9,-6.3).s().p("AgHABIADACQAWASAeAPIACABQghgRgYgTgAAwAkIAAAAgAgEADIAaASIAaAPQgegPgWgSgAgEADIAAAAgAgxgkIABACIAIAIIgJgKg");
	this.shape_158.setTransform(225.9125,234.8375);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["rgba(157,200,219,0.898)","#D8E9F0"],[0,1],-41.7,-13.8,41.5,15.2).s().p("ABOG2IhRgPIhTgWIg5gSQgRgGglgMIgPgHQgigOgdgQIAEACIgHgDIgZgPIgcgSIgFgEIADACIgQgNIAKAIIADADIgDgDIgKgIIgSgPIgHgIIgCgCQgRgSgMgVQgbgvgJhCIAAAAQgFgjAAggQAAhDAVg4QASgrAeggQAHgJAMgKIAVgTQAbgXAbgaIA4g4IAlglQAUgVAVgNIABgBIAIgFIAEgDIAGgEIACgBIACgCIALgGIAGgCIAUgJIAJgEIAPgFQAYgIAZgEIACgBIAAAAIAHgBQAcgEAfAAIAAAAIABAAQAlAAAoAGQAeAFAZAJQAkAOAeAcIAEAEQAbAZAUAeQAUAVAQAsIAiBJQASAnAVAwIAJAVQAQAoAFAbQAKAqAAAsIAAASQgDA1gSAzQgMAggRAdIgDAHQgUAhgcAeQgcAfgfAUQgiAYgqALQgnAKgpABIgQAAIgEAAIgEAAIAAAAIAAAAQgbAAgdgGIgCAAIgDgBIhXgRQgsgJg4gQQgqgNgqgSIglgRIgNgGIANAGIAlARQAqASAqANQA4AQAsAJIBXARIADABIACAAQAdAGAbAAIAAAAIAAAAIAEAAIAEAAIAQAAQApgBAngKQAqgLAigYQAfgUAcgfQAcgeAUghIADgHQARgdAMggQASgzADg1IAAgSQAAgsgKgqQgFgbgQgoIgJgVQgVgwgSgnIgihJQgQgsgUgVQgUgegbgZIgEgEQgegcgkgOQgZgJgegFQgogGglAAIgBAAIAAAAQgfAAgcAEIgHABIAAAAIgCABQgZAEgYAIQAdgLAdgEQBLgMBSASQAjAHAcAOQAUAKASAOQAMAJALALQAbAaASAgQASAVAOAqIAdBGIAmBdIAEAMQAZBBADAvQAGAvgIAvQgHAugTArQgGAQgIAOQgmBIg9AwQghAbgkAPQgyAVg8gBIgMAAQgUAAgUgCgAh+mJIAEgCgAh6mLIANgGIgNAGIAHgEIgHAEIAAAAgAkTFIIgDgBIAHADIgEgCgAkTFIIAAAAgAkWFHIAAAAgAmqC0QgMgcgGgmIAAgCQgNhSALhBQAHgmAPghQAQghAXgcQAMgQAVgQQAlgdAWgTQAhgbAegeQARgQATgUQAVgXAUgLIARgMIgEADIgIAFIgBABQgVANgUAVIglAlIg4A4QgbAagbAXIgVATQgMAKgHAJQgeAggSArQgVA4AABDQAAAgAFAjIAAAAQAJBCAbAvQAMAVARASQghghgRgpgAiImCIAAAAgAhVmcIAFgCIgJAEgAhQmeIAAAAg");
	this.shape_159.setTransform(258.5964,205.7461);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("rgba(0,0,0,0.733)").ss(0.8,1,1).p("Al1D6QgOgQgLgTQgcgwgKhAIAAAAQgShpAdhUQAQgrAbgiQAHgLALgKQASgSACgDQAZgZAagaQAcgcAcgaQARgRAUgTQASgQARgLQACgCADgBQAegUAkgOQADgBADgBAl1D6QgdgggRgnQgMgdgHgkIAAgDQgPhQAKhCQAGglAOghQAOgiAVgcQAMgSATgRQAjgfAVgTQAfgdAfgdQASgQATgSQASgSATgLQAEgDAEgCQAfgVAmgNQABgBACAAIARgGQAWgGAXgEQBEgKBMANQAeAFAYAJQAkAOAfAZQACACACACQAcAYAVAcQAXAWASApQATAlARAiQATAnAUAvQAEALAEAKQAPAnAFAcQALAzgDA0QgDA1gTAyQgMAfgQAeQgCADgCADQgUAhgbAdQgbAfgeAVQgjAYgoAMQgmAMgpADQgIAAgIAAQghADgkgGQgvgGgogIQgsgIg3gQQgpgNgpgTQgTgIgSgJIgBgBQAAAAgBAAQgCgBgCgBQgFgDgFgCIgHgFQgMgHgKgHQgOgJgNgKIgDgCQgCgCgCgCQgWgRgRgUgAhEmjQAcgJAbgDQBLgLBQATQAiAIAdANQAUAKASAOQAMAJALAKQAcAZAUAeQATAWAQAnQARAkAOAgQASApAUAzQABAGACAGQAYBAACAwQAEAugIAvQgIAsgTAsQgGAPgIAOQgmBHg8AwQghAagjAQQgxAVg7ACQgaACgagCQgtgFgkgGQgrgJgngLQgbgIgegKQgSgHgjgMQgHgDgHgEQgYgKgVgMAlHElQgYgSgSgVQgCgCgCgCAkCFRQgBAAgCgBQgJgFgIgFIgxghAkBFSQAAAAgBgBQgHgDgGgD");
	this.shape_160.setTransform(262.4917,205.8349);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["#7393A1","#90A3AB"],[0,1],-1.3,-17.2,74.2,26.4).s().p("AgyF3IgCgBIACABIgMgHIAKAGIAEACIgCgBgAhcFdQgOgJgNgJIAxAgIgWgOgAAylVQAfgUAngOIgHADQgkANgdAUIgGADIAIgFg");
	this.shape_161.setTransform(241.65,202.075);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["rgba(157,200,219,0.918)","#D4E7EF"],[0,1],-40.9,-15.3,40.8,16.6).s().p("ABMGzQgtgFgkgGQgrgJgngLQgbgIgegKIg1gTIgOgHQgYgKgVgMIgBAAIgEgCIgRgKIgxghQgYgSgSgVIgEgEIAEAEQASAVAYASIgDgCIgEgEQgWgRgRgUQgOgQgLgTQgcgwgKhAIAAAAQgHgqAAgmQAAg6ASgzQAQgrAbgiQAHgLALgKIAUgVIAzgzIA4g2IAlgkQASgQARgLQgRALgSAQIglAkIg4A2IgzAzIgUAVQgLAKgHALQgbAigQArQgSAzAAA6QAAAmAHAqIAAAAQAKBAAcAwQALATAOAQQgdgggRgnQgMgdgHgkIAAgDQgPhQAKhCQAGglAOghQAOgiAVgcQAMgSATgRIA4gyIA+g6IAlgiQASgSATgLIAFgDQAegUAkgOIAGgCIADgBIARgGQAWgGAXgEIAFgBIAFAAQAZgEAaAAIABAAIAAAAQAiAAAlAGIABAAIAEABIAGABQAeAFAYAJQAkAOAfAZIAEAEQAcAYAVAcQAXAWASApIAkBHQATAnAUAvIAIAVQAPAnAFAcQAJAngBAnIAAAZQgDA1gTAyQgMAfgQAeIgEAGQgUAhgbAdQgbAfgeAVQgjAYgoAMQgmAMgpADIgQAAIgRABIgEAAQgXAAgZgEQgvgGgogIQgsgIg3gQQgpgNgpgTIglgRIgBgBIABABIAlARQApATApANQA3AQAsAIQAoAIAvAGQAZAEAXAAIAEAAIARgBIAQAAQApgDAmgMQAogMAjgYQAegVAbgfQAbgdAUghIAEgGQAQgeAMgfQATgyADg1IAAgZQABgngJgnQgFgcgPgnIgIgVQgUgvgTgnIgkhHQgSgpgXgWQgVgcgcgYIgEgEQgfgZgkgOQgYgJgegFIgGgBIgEgBIgBAAQglgGgiAAIAAAAIgBAAQgaAAgZAEIgFAAIgFABQgXAEgWAGQAcgJAbgDQBLgLBQATQAiAIAdANQAUAKASAOQAMAJALAKQAcAZAUAeQATAWAQAnIAfBEQASApAUAzIADAMQAYBAACAwQAEAugIAvQgIAsgTAsQgGAPgIAOQgmBHg8AwQghAagjAQQgxAVg7ACIgaABIgagBgAkPFLIgHgFIARAKIgKgFg");
	this.shape_162.setTransform(262.4917,205.8349);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("rgba(0,0,0,0.8)").ss(0.8,1,1).p("AkJkrQAFgFAEgEQACgCACgCIAEgEQAOgMAPgNQAEgEAEgEQAUgQATgLAkJkrQAEgEAEgEQACgCADgDAkAk0QAEgEAEgEQAOgMAPgNQAFgEAFgFQABgBABgBIAfgVQADgCADgCQACgBABgBQAfgSAkgNQANgEAMgDIALgDQAQgEARgDQBFgJBKANQAcAFAZAKQAkANAfAZQADABACACQAdAXAXAbQAYAWAUAlQAVAkASAiQAUAmASAvQAFAKADALQAOAlAFAeQAKAygEAzQgEA0gTAyQgMAfgRAdQgBADgCADQgUAigaAcQgbAfgeAVQghAYgoAOQglANgpAFQgIABgIABQghADgkgDQgugEgogGQgugIg0gQQgpgOgpgTQgSgJgSgKQgDgBgDgCQgpgXgdgbQgBgBgCgBQgXgUgSgYQgBgBAAAAQgJgNgIgNQgcgwgMg+QgUhoAZhUQAOgsAZgkQAGgLAKgLQARgUACgDQAYgaAZgbQAEgDADgDQADgDADgDQABgCABgBIAXgWAkBkzQAAgBABAAAl2DwQgYgdgOgjQgNgcgHgjIgBgDQgQhOAIhCQAFglANgiQAMgiAUgeQALgSARgSQAhghAUgVQAagYAbgYAhAmkQAXgGAWgDQBLgJBOATQAhAJAdAOQAUAJASANQANAJALAJQAdAYAVAdQAWAWARAkQASAiAPAhQATApASAxQACAGACAGQAVA+ACAyQADAugJAuQgJAsgTAqQgHAPgIAOQgmBGg7AwQgfAZgkARQgwAWg6AFQgaADgaAAQgsgDglgFQgqgHgngLQgbgIgdgKQgUgIgggMQgHgDgHgEQgagMgWgNQgVgMgSgOQgngbgbghQgFgFgEgFAiql5QACgBADgCQAggTAmgNQAKgDAKgCAiwl1QACgCACgBQABgBABAA");
	this.shape_163.setTransform(266.418,205.9615);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["rgba(157,200,219,0.941)","#D0E5ED"],[0,1],-40.1,-16.9,40,18).s().p("ABJGxQgsgDglgFQgqgHgngLIg4gSIg0gUIgOgHQgagMgWgNQgVgMgSgOQgngbgbghIgJgKIgBgBQgJgNgIgNQgcgwgMg+QgJgtAAgqQAAg1AOgwQAOgsAZgkQAGgLAKgLIATgXIAxg1IAHgGIAGgGIACgDIAXgWIgXAWIgCADIgGAGIgHAGIgxA1IgTAXQgKALgGALQgZAkgOAsQgOAwAAA1QAAAqAJAtQAMA+AcAwQAIANAJANQgYgdgOgjQgNgcgHgjIgBgDQgQhOAIhCQAFglANgiQAMgiAUgeQALgSARgSIA1g2IA1gwIgIAIIAJgJIAIgIIAdgZIAIgIQAUgQATgLIACgBIADgCQAfgSAkgNIAZgHIALgDIAhgHIAIgBQAYgDAZAAIAAAAIABAAQAmAAAmAHIAJABQAcAFAZAKQAkANAfAZIAFADQAdAXAXAbQAYAWAUAlQAVAkASAiQAUAmASAvIAIAVQAOAlAFAeQAHAkAAAlIgBAcQgEA0gTAyQgMAfgRAdIgDAGQgUAigaAcQgbAfgeAVQghAYgoAOQglANgpAFIgQACIgGAAIgeACIAAAAIAAAAIgbgBIgGgBQgugEgogGQgugIg0gQQgpgOgpgTQgSgJgSgKIgGgDIAGADQASAKASAJQApATApAOQA0AQAuAIQAoAGAuAEIAGABIAbABIAAAAIAAAAIAegCIAGAAIAQgCQApgFAlgNQAogOAhgYQAegVAbgfQAagcAUgiIADgGQARgdAMgfQATgyAEg0IABgcQAAglgHgkQgFgegOglIgIgVQgSgvgUgmQgSgigVgkQgUglgYgWQgXgbgdgXIgFgDQgfgZgkgNQgZgKgcgFIgJgBQgmgHgmAAIgBAAIAAAAQgZAAgYADIgIABIghAHQAXgGAWgDQBLgJBOATQAhAJAdAOQAUAJASANIAYASQAdAYAVAdQAWAWARAkQASAiAPAhQATApASAxIAEAMQAVA+ACAyQADAugJAuQgJAsgTAqIgPAdQgmBGg7AwQgfAZgkARQgwAWg6AFQgWADgWAAIgIAAgAjPlgIgCACIgKAJIAKgJIACgCIAfgVgAiwl1IAGgEIgGAEIAEgDIgEADIAAAAgAlJEfIgDgCQgXgUgSgYIAJAKQAbAhAnAbQASAOAVAMQgpgXgdgbgAl1DxIAAAAgAj8k4IgEAEIgBABIAFgFgAj8k4IAEgEIAdgZIgdAZIgIAIIAEgEgAj8k4IAAAAgAjblVIAAAAgAill8QAggTAmgNIAUgFIgZAHQgkANgfASIgDACIAFgDgAhLmhIAAAAg");
	this.shape_164.setTransform(266.418,205.9615);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("rgba(0,0,0,0.867)").ss(0.9,1,1).p("AlyDsQgVgdgOghQgNgcgIgiIgBgEQgShLAHhDQAEglALgiQALgiASgfQALgTAQgTQAdgjAUgWQAUgUAWgTAlyDsQgHgMgHgLQgcgwgOg9QgXhlAXhWQALgsAXgmQAGgMAJgLQAQgWACgDQAWgcAYgbQACgBABgCQABgBACgBQABgCABgBQAOgPAPgNQAAgBABAAQACgCACgCIAFgFQADgDADgDQABAAABgBQAPgNARgNQADgDAEgDQAXgSAXgLIAggPQATgIAUgGQABgBACAAIAKgCQAPgFAPgCQAFgCAFAAAg7mlQACgBABAAQADgBAEAAIADgBQADAAADAAQABgBABAAQBFgIBIAOQAcAFAZAKQAjANAgAXQADABACACQAeAVAZAaQAaAWAWAjQAWAhATAjQAVAmARAuQAEAKAEAKQAAABABACQAAABAAABQAAAAABABQAAABAAACQADAJADAJIAEASQABADABADQAAACABABIACAMQAAABAAAAQAJAzgFAyQgFAzgTAxQgMAfgQAdQgCADgCADQgUAhgZAdQgaAdgeAWQggAZgnAPQglAOgoAHQgIACgIABQghAFgkgBQgtgBgpgGQgvgHgygRQgpgNgngUQgJgFgJgFAgumoQALgCAKgBQBLgHBNAUQAfAJAdAOQAUAJATAMQANAIALAKQAeAWAXAcQAXAWATAiQATAgAQAgQAUApARAxQABADABADQAAABABACQADALADAKAjilbQAEgDAEgDQAWgRAXgMAiNmNQARgHASgGQAJgCAIgCAkKk6QAFgEAEgEQAPgMAQgNAGxgjQAHAjABAfQABAugJAtQgKArgTAqQgHAOgIAPQgmBFg6AvQgfAZgjARQgvAXg5AIQgaAEgZABQgsAAglgEQgqgGgogLQgbgHgcgKQgVgIgegNQgHgEgHgDQgLgGgKgGIgRgKQgZgPgVgRQglgbgbgiQgEgFgFgGQAAAAgBgBQAAgBgBAAAj5FWQgrgZgggeQgZgXgTga");
	this.shape_165.setTransform(270.3222,206.1227);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["#88ADBE","#AAC0CA"],[0,1],-32.9,-17.2,42.6,26.4).s().p("AlgFIQgZgXgTgaIAJALQAbAiAkAbQAWARAYAPQgrgZgfgegAGIgnIgBgDIAGAVIgFgSgAGHgrIgBgCIABADIAAgBgAj3k4QAWgSAXgLQgXAMgWARIgIAGIAIgGgAhOl+IgGABIgDAAIAJgBg");
	this.shape_166.setTransform(273.1625,202.025);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["rgba(157,200,219,0.961)","#CCE2EC"],[0,1],-39.4,-18.4,39.2,19.3).s().p("AgJGqQgqgGgogLQgbgHgcgKIgzgVIgOgHIgVgMIASAKQAnAUApANQAyARAvAHQApAGAtABIADAAIAEAAIAAAAIAAAAQAeAAAdgEIADAAIAQgDQAogHAlgOQAngPAggZQAegWAagdQAZgdAUghIAEgGQAQgdAMgfQATgxAFgzQACgSAAgSQAAghgGggIAAgBIgCgMIACAMIAAABQAGAgAAAhQAAASgCASQgFAzgTAxQgMAfgQAdIgEAGQgUAhgZAdQgaAdgeAWQggAZgnAPQglAOgoAHIgQADIgDAAQgdAEgeAAIAAAAIAAAAIgEAAIgDAAQgtgBgpgGQgvgHgygRQgpgNgngUIgSgKIgRgKQgZgPgVgRQglgbgbgiIgJgLIgBgBIgBgBIgOgXQgcgwgOg9QgLgzAAgwQAAgtALgrQALgsAXgmQAGgMAJgLIASgZQAWgcAYgbIADgDIADgCIACgDIAdgcIgdAcIgCADIgDACIgDADQgYAbgWAcIgSAZQgJALgGAMQgXAmgLAsQgLArAAAtQAAAwALAzQAOA9AcAwIAOAXQgVgdgOghQgNgcgIgiIgBgEQgShLAHhDQAEglALgiQALgiASgfQALgTAQgTQAdgjAUgWQAUgUAWgTIABgBIAEgEIAFgFIAJgIIAfgZIAIgGQAWgRAXgMIAggPIAjgNIARgEIAegHIADgBIAHgBIADgBIAGAAIACgBIAFAAIAAAAQAYgDAXAAIAAAAIAAAAQArAAAsAIIACABQAcAFAZAKQAjANAgAXIAFADQAeAVAZAaQAaAWAWAjQAWAhATAjQAVAmARAuIAIAUIABADIAAACIABABIAAADIAGASIAEASIACAGIABADQAHAjABAfQABAugJAtQgKArgTAqIgPAdQgmBFg6AvQgfAZgjARQgvAXg5AIQgaAEgZABQgsAAglgEgAjoFgIAAAAgAGihZIgIgUQgRgugVgmQgTgjgWghQgWgjgagWQgZgagegVIgFgDQgggXgjgNQgZgKgcgFIgCgBQgsgIgrAAIAAAAIAAAAQgXAAgYADIAAAAIgFAAIgCABIgGAAIAVgDQBLgHBNAUQAfAJAdAOQAUAJATAMQANAIALAKQAeAWAXAcQAXAWATAiQATAgAQAgQAUApARAxIACAGIgBgDgAkElAIACgBIAggaIgfAZIgJAIIAGgGgAhmmbIADgBIAKgCIgRAEIgjANQATgIAUgGgAhZmeIAAAAg");
	this.shape_167.setTransform(270.3222,206.1227);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("rgba(0,0,0,0.933)").ss(1,1,1).p("Al1DZQgOgWgLgYQgMgcgJghIgBgDQgUhKAGhDQADglAJgiQAKgjARggQAKgUAOgUQAaglAVgXQANgPAOgOIASgQQAEgEAFgEQABgBABgBQAUgQAVgPQADgCADgCQACgBABgBQADgCADgBQAMgHALgGQAFgCAEgCIATgJQAEgBADgCIADgBQAKgEAKgDQADgBACgBQACAAABgBIAJgCQABgBABAAQABAAABAAQANgEAMgDIAZgEQAHgBAIgBQBGgIBGAPQAGABAGACIAlALQACABABAAQADABADABIASAIQAFACAEACQAUAJATAMQANAIALAIQAfAWAZAaQAZAXAUAeQAVAfARAhQAUAoAQAvQAAABAAABAl1DZQgCgDgBgCQgdgwgPg7QgZhjAThYQAKgsAUgpQAGgMAIgMQAPgXACgDQAUgeAYgbQAMgOAMgNAg8mlQAPgDAPgBQBFgGBEASAjalsQABAAABgBQACgBACgBQAQgKARgIQAMgGANgFAkXk9QAHgGAHgGQATgPAUgOQADgCACgCIACgBQABAAAAgBAhwmaIABAAQABgBABAAQAMgDAMgDAiDmUIADgBQABAAABgBAihmJQAFgCAFgCACrmHQAXAKAVAOQADACACABQAfAVAaAXQAdAYAXAfQAZAgATAiQAWAmAQAtQAEAKADAKQACAFABAFQADAKADAKIACAJQABAFABAEIAAAFQADAOACAOIAABUQAAABAAABIgFAgQgBAGgBAHQgKAqgUApQgHAOgIAOQgHANgIALAGvgrQABADAAACIACAJQABAHABAHAGtg5QABAHABAHAEqFOQgEAEgFAEQgeAZgjASQguAXg4ALQgaAFgZACQgrADgmgDQgqgEgogKQgbgIgbgKQgWgJgbgNQgHgDgHgEQgBgBgBAAQgBgBgCgBQgCgBgCgBAEqFOQgIAHgJAHQghAZgmAQQgjAQgoAJQgIACgIABQgiAHgiABQguACgpgFQgvgHgxgQQgngOgmgUQgFgDgEgCIgUgMQgEgCgDgDIAAAAQgCgBgBgBIgXgQQgLgIgJgIQgRgNgPgPIgogxIgCgCQgBgBgBgCIAAAAQgBgCgBgCIgBAAIgDgGAGvBnQgGAigOAhQgLAegRAdQgCADgCADQgFAIgFAIIghAtIgmAmAj0FYQgCgBgCgCAj0FYQAAAAgBgBAjuFcQgDgCgDgCAlrDoQgCgCgCgDQgBgCgBgCAkPFFQgagSgVgVQgBgBgBgBIgDgDQgQgRgOgSQgFgHgFgH");
	this.shape_168.setTransform(274.127,206.3349);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["rgba(157,200,219,0.98)","#C8E0EA"],[0,1],-38.6,-20,38.5,20.7).s().p("AglGnQgvgHgxgQQgngOgmgUIgJgFIAJAFIgCgBIgCgCIgFgCIgUgMIgHgFIAAAAIgDgCIADACIAAAAIAHAFIgFgEIgCgBIACABIgFgDIgXgQIgUgQQgRgNgOgPIgpgxIgDgFIAAAAIgDgEIAAAAIgEgGIgDgFQgdgwgPg7QgZhjAThYQAKgsAUgpQAGgMAIgMIARgaQAUgeAYgbIAZgbIARgQIAOgMQATgPAUgOIAFgEIACgBIABgBIAHgDIgEACIgDABIADgBIAEgCIAWgNIAJgEIAUgJIgUAJIgJAEIgWANQAQgKAQgIIAZgLIADgBIAUgHIAGgCIACgBIAJgCIACgBIACAAIAagHIAYgEIAPgCIADgBIABAAQAWgCAVAAIAAAAIABAAQApAAAqAIIABAAIAFABIABABIACAAIAMADIAlALIADABIAGACIATAIQAWAKAVAOIAFADQAfAVAaAXQAdAYAXAfQAZAgATAiQAWAmAQAtIAHAUIADAKIAGAUIACAJIADAOIAEAcIgCgOIgCgJIAAgFIAAAFIACAJIACAOIABBUIgBACIgEAgQgHAigOAhQgLAegRAdIgEAGIgKAQIghAtIglAmIgSAOQghAZgmAQQgjAQgoAJIgQADQgiAHgiABIgYABQggAAgfgEgAihmIIAJgEIgJAEIAGgDIgGADgAk/EfIgBgCIgDgDQAOAPARANIAUAQQgZgSgWgVgAlDEaIAAAAgAluDnIgBgDIADAFgAkPlEIACgCQAUgQAVgPIAGgEIgFAEQgUAOgTAPIgOAMIAJgIgAjelpIAAAAgAiBmUIADgBIgGACgAh+mVIAAAAgAhvmZIABgBIAZgGIgaAHIgCAAgABqmcIAAAAgABemfIgCAAIgBgBIgFgBIgBAAQgqgIgpAAIgBAAIAAAAQgVAAgWACIgBAAIgDABIgPACIAegEQBFgGBEASIgMgDg");
	this.shape_169.setTransform(274.2023,206.2366);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["#93BBCC","#B7CFD9"],[0,1],-33.6,-23.2,41.9,20.4).s().p("AgIGYQgpgEgogKQgbgIgbgKQgXgJgbgNIgOgHQAnAUAnAOQAwAQAvAHQAqAFAtgCQAjgBAigHIAQgDQAogJAjgQQAmgQAggZIASgOIgJAIQgeAZgjASQgvAXg4ALQgaAFgZACIgqACQgUAAgTgCgAleDkIgLgOIApAxQgQgRgOgSgAF+DZIADgGQARgdAMgeQANghAHgiIgDANQgKAqgTApIgPAcIgPAYIAKgQgAlvDNIADAEIAAABIgDgFgAmLCZQgNgcgJghIgBgDQgThKAFhDQADglAKgiQAKgjAQggQAKgUAOgUQAbglAUgXQAOgPAOgNIgZAaQgXAbgVAeIgQAaQgIAMgGAMQgVApgJAsQgTBZAZBiQAPA7AcAwIADAFQgOgWgKgYgAGvhLIACAJIABAGIgDgPgAGeiGQgQgtgWgmQgUgigYggQgYgfgcgYQgagXgggVIgEgDQgWgNgWgLIAJAEQATAJATAMIAZAQQAfAWAYAaQAZAXAUAeQAWAfAQAhQAVAoAPAvIABACIgHgUgAjXl+IgCABIgCABIAEgCg");
	this.shape_170.setTransform(273.877,208.125);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["#9DC8DB","#C4DEE9"],[0,1],-28.8,0,28.9,0).s().p("AjLBIQhUgdgBgrQABgpBUgfQBUgdB3AAQB3AABVAdQBUAfAAApQAAArhUAdQhVAeh3AAQh3AAhUgeg");
	this.shape_171.setTransform(278.0968,206.6595,1.5115,4.1262,29.9987);

	this.circle = new lib.hugering();
	this.circle.name = "circle";
	this.circle.setTransform(278.1,206.6,1,1,0,0,0,0,-42.6);
	this.circle._off = true;
	new cjs.ButtonHelper(this.circle, 0, 1, 1);

	this.instance_33 = new lib.bouncering("synched",0);
	this.instance_33.setTransform(205.7,101.55,1,1,0,0,0,0,-42.6);
	this.instance_33._off = true;

	this.instance_34 = new lib.元件309("synched",0);
	this.instance_34.setTransform(180.7,267.55,1.3948,3.9455,0,47.5491,19.3263,185,50.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.ringbutton}]},98).to({state:[{t:this.ringbutton}]},1).to({state:[{t:this.button_3}]},29).to({state:[{t:this.movieClip_6}]},1).to({state:[{t:this.shape_34},{t:this.shape_33,p:{scaleY:0.4018,x:213.9733,y:175.0572,scaleX:0.7019,rotation:29.9988}}]},1).to({state:[{t:this.shape_36},{t:this.shape_35}]},1).to({state:[{t:this.shape_38},{t:this.shape_37}]},1).to({state:[{t:this.shape_40},{t:this.shape_39}]},1).to({state:[{t:this.shape_42},{t:this.shape_41}]},1).to({state:[{t:this.shape_44},{t:this.shape_43}]},1).to({state:[{t:this.shape_46},{t:this.shape_45}]},1).to({state:[{t:this.shape_48},{t:this.shape_47}]},1).to({state:[{t:this.shape_50},{t:this.shape_49}]},1).to({state:[{t:this.shape_52},{t:this.shape_51}]},1).to({state:[{t:this.shape_54},{t:this.shape_53}]},1).to({state:[{t:this.shape_56},{t:this.shape_55}]},1).to({state:[{t:this.shape_57},{t:this.shape_33,p:{scaleY:1.9716,x:213.916,y:175.0259,scaleX:0.7019,rotation:29.9988}}]},1).to({state:[{t:this.shape_60},{t:this.shape_59},{t:this.shape_58}]},1).to({state:[{t:this.shape_63},{t:this.shape_62},{t:this.shape_61}]},1).to({state:[{t:this.shape_66},{t:this.shape_65},{t:this.shape_64}]},1).to({state:[{t:this.shape_69},{t:this.shape_68},{t:this.shape_67}]},1).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70}]},1).to({state:[{t:this.shape_75},{t:this.shape_74},{t:this.shape_73}]},1).to({state:[{t:this.shape_78},{t:this.shape_77},{t:this.shape_76}]},1).to({state:[{t:this.shape_81},{t:this.shape_80},{t:this.shape_79}]},1).to({state:[{t:this.shape_84},{t:this.shape_83},{t:this.shape_82}]},1).to({state:[{t:this.shape_87},{t:this.shape_86},{t:this.shape_85}]},1).to({state:[{t:this.shape_90},{t:this.shape_89},{t:this.shape_88}]},1).to({state:[{t:this.shape_93},{t:this.shape_92},{t:this.shape_91}]},1).to({state:[{t:this.shape_96},{t:this.shape_95},{t:this.shape_94}]},1).to({state:[{t:this.shape_99},{t:this.shape_98},{t:this.shape_97}]},1).to({state:[{t:this.shape_101},{t:this.shape_100}]},1).to({state:[{t:this.shape_103},{t:this.shape_102}]},1).to({state:[{t:this.shape_105},{t:this.shape_104}]},1).to({state:[{t:this.shape_107},{t:this.shape_106}]},1).to({state:[{t:this.shape_109},{t:this.shape_108}]},1).to({state:[{t:this.shape_111},{t:this.shape_110}]},1).to({state:[{t:this.shape_113},{t:this.shape_112}]},1).to({state:[{t:this.shape_115},{t:this.shape_114}]},1).to({state:[{t:this.shape_117},{t:this.shape_116}]},1).to({state:[{t:this.shape_119},{t:this.shape_118}]},1).to({state:[{t:this.shape_121},{t:this.shape_120}]},1).to({state:[{t:this.shape_123},{t:this.shape_122}]},1).to({state:[{t:this.shape_125},{t:this.shape_124}]},1).to({state:[{t:this.shape_127},{t:this.shape_126}]},1).to({state:[{t:this.shape_129},{t:this.shape_128}]},1).to({state:[{t:this.shape_132},{t:this.shape_131},{t:this.shape_130}]},1).to({state:[{t:this.shape_135},{t:this.shape_134},{t:this.shape_133}]},1).to({state:[{t:this.shape_138},{t:this.shape_137},{t:this.shape_136}]},1).to({state:[{t:this.shape_141},{t:this.shape_140},{t:this.shape_139}]},1).to({state:[{t:this.shape_144},{t:this.shape_143},{t:this.shape_142}]},1).to({state:[{t:this.shape_147},{t:this.shape_146},{t:this.shape_145}]},1).to({state:[{t:this.shape_150},{t:this.shape_149},{t:this.shape_148}]},1).to({state:[{t:this.shape_153},{t:this.shape_152},{t:this.shape_151}]},1).to({state:[{t:this.shape_156},{t:this.shape_155},{t:this.shape_154}]},1).to({state:[{t:this.shape_159},{t:this.shape_158},{t:this.shape_157}]},1).to({state:[{t:this.shape_162},{t:this.shape_161},{t:this.shape_160}]},1).to({state:[{t:this.shape_164},{t:this.shape_163}]},1).to({state:[{t:this.shape_167},{t:this.shape_166},{t:this.shape_165}]},1).to({state:[{t:this.shape_170},{t:this.shape_169},{t:this.shape_168}]},1).to({state:[{t:this.shape_171},{t:this.shape_33,p:{scaleY:4.1262,x:278.0968,y:206.6595,scaleX:1.5115,rotation:29.9987}}]},1).to({state:[{t:this.circle}]},1).to({state:[{t:this.circle}]},1).to({state:[{t:this.circle}]},96).to({state:[{t:this.circle}]},2).to({state:[{t:this.instance_33}]},11).to({state:[{t:this.instance_33}]},10).to({state:[{t:this.instance_33}]},3).to({state:[{t:this.instance_33}]},4).to({state:[{t:this.instance_33}]},7).to({state:[{t:this.instance_33}]},10).to({state:[{t:this.instance_33}]},3).to({state:[{t:this.instance_33}]},2).to({state:[{t:this.instance_33}]},10).to({state:[{t:this.instance_33}]},14).to({state:[{t:this.instance_34}]},1).to({state:[]},48).wait(150));
	this.timeline.addTween(cjs.Tween.get(this.ringbutton).wait(98).to({_off:false},0).wait(1).to({regY:-4,rotation:0.9993,x:253.4,y:38.6},0).to({_off:true,regX:0.1,rotation:29.9984,x:214.05,y:175.25},29).wait(431));
	this.timeline.addTween(cjs.Tween.get(this.circle).wait(187).to({_off:false},0).wait(97).to({regX:0.2,regY:-42.4,scaleX:0.591,scaleY:0.9775,rotation:-29.9989,x:263.75,y:184.55},2).to({_off:true,regX:0,regY:-42.6,scaleX:1,scaleY:1,rotation:0,x:205.7,y:101.55,mode:"synched",startPosition:0},11).wait(262));
	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(286).to({_off:false},11).to({regX:0.2,regY:-42.5,scaleX:0.6635,scaleY:1.3188,rotation:22.499,x:222.6,y:216.75},10).to({regX:0,regY:-42.6,scaleX:1,scaleY:1,rotation:0,x:210.85,y:232.95},3).to({regX:0.5,regY:-42.2,scaleX:0.3693,scaleY:0.8589,skewX:-11.8004,skewY:-15.3753,x:199.6,y:218.3},4).to({regX:0.8,scaleX:0.8531,skewY:-11.5246,x:207.4,y:152.75},7).to({regX:1.2,regY:-42,scaleX:0.4797,scaleY:1.0328,skewX:18.1989,skewY:18.4753,x:197.85,y:225.05},10).to({regX:0.8,regY:-42.2,scaleX:0.8531,scaleY:0.8589,skewX:-11.8004,skewY:-11.5246,x:193.25,y:256.95},3).to({regY:-42,scaleX:0.5283,scaleY:1.1362,skewX:-11.8001,skewY:-11.5228,y:244.9},2).to({regX:1,regY:-41.9,scaleX:0.8816,scaleY:0.9313,skewX:-11.7993,skewY:-11.5231,x:185.2,y:175.05},10).to({regX:1.2,regY:-41.4,scaleX:0.8074,scaleY:0.7664,skewX:32.4978,skewY:-1.111,x:181.35,y:267.2},14).to({_off:true,regX:185,regY:50.4,scaleX:1.3948,scaleY:3.9455,skewX:47.5491,skewY:19.3263,x:180.7,y:267.55},1).wait(198));

	// bulb
	this.bulb = new lib.bulb();
	this.bulb.name = "bulb";
	this.bulb.setTransform(156.35,121.6,0.804,0.8033,0,0,0,0.1,-36.8);
	this.bulb._off = true;
	new cjs.ButtonHelper(this.bulb, 0, 1, 2, false, new lib.bulb(), 3);

	this.timeline.addTween(cjs.Tween.get(this.bulb).wait(68).to({_off:false},0).to({_off:true},5).wait(4).to({_off:false},0).to({_off:true},1).wait(481));

	// boy_scene1
	this.instance_35 = new lib.ClipGroup_13();
	this.instance_35.setTransform(161.55,218.95,0.3082,0.3081,0,0,0,162.7,210.8);

	this.instance_36 = new lib.PuppetShape_1复制("synched",1,false);
	this.instance_36.setTransform(160.45,218.4,0.1216,0.1217,0,0,0,487.6,626.8);

	this.instance_37 = new lib.PuppetShape_2复制("synched",1,false);
	this.instance_37.setTransform(160.45,218.4,0.1216,0.1217,0,0,0,487.6,626.9);
	this.instance_37._off = true;

	this.instance_38 = new lib.PuppetShape_2复制3("synched",1,false);
	this.instance_38.setTransform(160.45,218.4,0.1216,0.1217,0,0,0,487.6,626.9);
	this.instance_38._off = true;

	this.instance_39 = new lib.PuppetShape_2复制4("synched",1,false);
	this.instance_39.setTransform(160.45,218.4,0.1216,0.1217,0,0,0,487.6,626.9);

	this.instance_40 = new lib.资源33x();
	this.instance_40.setTransform(129,142,0.1196,0.1197);

	this.instance_41 = new lib.PuppetShape_3复制2("synched",1,false);
	this.instance_41.setTransform(160.45,218.4,0.1216,0.1217,0,0,0,487.6,626.9);

	this.instance_42 = new lib.PuppetShape_5复制("synched",1,false);
	this.instance_42.setTransform(160.45,218.4,0.1216,0.1217,0,0,0,487.6,626.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_35}]},9).to({state:[{t:this.instance_35}]},5).to({state:[{t:this.instance_35}]},11).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},12).to({state:[{t:this.instance_38}]},8).to({state:[{t:this.instance_39}]},7).to({state:[{t:this.instance_41},{t:this.instance_40}]},15).to({state:[{t:this.instance_42},{t:this.instance_40}]},9).to({state:[]},1).wait(481));
	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(38).to({_off:false},0).to({_off:true},8).wait(513));
	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(38).to({_off:false},8).to({_off:true},7).wait(506));

	// 图层_14 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_9 = new cjs.Graphics().p("ACcFIIAAhmIk3AAIAABmIi9AAIAAi9IAqAAIAAnSIJpAAIAAHSIAeAAIAAC9g");
	var mask_3_graphics_14 = new cjs.Graphics().p("ACcFIIAAhmIk3AAIAABmIi9AAIAAi9IAqAAIAAnSIJpAAIAAHSIAeAAIAAC9g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_3_graphics_9,x:356.525,y:171.675}).wait(5).to({graphics:mask_3_graphics_14,x:356.525,y:171.675}).wait(545));

	// boy1
	this.button_1 = new lib.naughtyboy("synched",0);
	this.button_1.name = "button_1";
	this.button_1.setTransform(355.6,190.85,1,1,0,0,0,0,46.2);
	this.button_1._off = true;

	var maskedShapeInstanceList = [this.button_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.button_1).wait(9).to({_off:false},0).to({_off:true},5).wait(25).to({_off:false,mode:"independent"},0).to({_off:true},9).wait(511));

	// boy1_no_hand
	this.instance_43 = new lib.ClipGroup_12();
	this.instance_43.setTransform(359.1,190.85,0.3756,0.3958,0,0,0,52.5,101);
	this.instance_43._off = true;

	var maskedShapeInstanceList = [this.instance_43];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(14).to({_off:false},0).to({_off:true},34).wait(511));

	// stretch_hand
	this.instance_44 = new lib.ClipGroup();
	this.instance_44.setTransform(315.05,191.7,0.2924,0.2839,0,123.9548,-56.0454,76.5,83.5);
	this.instance_44._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(14).to({_off:false},0).to({regX:76.4,scaleX:0.9895,scaleY:0.9607,skewX:123.9551,skewY:-56.045,x:238.2,y:207.7},9).to({_off:true},25).wait(511));

	// window
	this.instance_45 = new lib.CachedBmp_1();
	this.instance_45.setTransform(295.6,130.5);

	this.instance_46 = new lib.补间1("synched",0);
	this.instance_46.setTransform(357,163.4);

	this.instance_47 = new lib.补间2("synched",0);
	this.instance_47.setTransform(356.6,163.8);
	this.instance_47._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_45}]},9).to({state:[{t:this.instance_46}]},30).to({state:[{t:this.instance_47}]},9).to({state:[]},81).to({state:[{t:this.instance_47}]},59).to({state:[{t:this.instance_47}]},100).to({state:[{t:this.instance_47}]},40).wait(231));
	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(48).to({_off:false},0).to({_off:true},81).wait(59).to({_off:false},0).wait(100).to({startPosition:0},0).to({x:563.6},40).wait(231));

	// house
	this.instance_48 = new lib.CachedBmp_2();
	this.instance_48.setTransform(207.35,8.5);

	this.instance_49 = new lib.CachedBmp_3();
	this.instance_49.setTransform(207.35,8.5);

	this.instance_50 = new lib.CachedBmp_4();
	this.instance_50.setTransform(207.35,8.5);

	this.instance_51 = new lib.补间14("synched",0);
	this.instance_51.setTransform(317.15,134.2);
	this.instance_51._off = true;

	this.instance_52 = new lib.补间15("synched",0);
	this.instance_52.setTransform(524.15,134.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_48}]}).to({state:[{t:this.instance_49}]},99).to({state:[]},30).to({state:[{t:this.instance_50}]},59).to({state:[{t:this.instance_51}]},100).to({state:[{t:this.instance_52}]},40).wait(231));
	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(288).to({_off:false},0).to({_off:true,x:524.15},40).wait(231));

	// bushes
	this.instance_53 = new lib.Bushes("synched",0);
	this.instance_53.setTransform(6.1,203.65,1,1,0,0,0,0,-33.4);

	this.instance_54 = new lib.补间27("synched",0);
	this.instance_54.setTransform(220.6,178.75);
	this.instance_54._off = true;

	this.instance_55 = new lib.补间28("synched",0);
	this.instance_55.setTransform(428.9,178.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_53}]}).to({state:[]},129).to({state:[{t:this.instance_53}]},59).to({state:[{t:this.instance_54}]},100).to({state:[{t:this.instance_55}]},75).to({state:[{t:this.instance_55}]},45).to({state:[{t:this.instance_55}]},100).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_54).wait(288).to({_off:false},0).to({_off:true,x:428.9},75).wait(196));

	// fencing
	this.instance_56 = new lib.fencing("synched",0);
	this.instance_56.setTransform(10.25,168.2,1.1568,1.1567,0,0,0,194.5,-41.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_56).to({_off:true},129).wait(59).to({_off:false},0).wait(100).to({startPosition:0},0).to({x:217.25},75).wait(45).to({startPosition:0},0).wait(100).to({startPosition:0},0).wait(51));

	// hills
	this.instance_57 = new lib.CachedBmp_5();
	this.instance_57.setTransform(-208.7,86);

	this.instance_58 = new lib.CachedBmp_6();
	this.instance_58.setTransform(-208.7,86);

	this.instance_59 = new lib.补间21("synched",0);
	this.instance_59.setTransform(69.25,161.1);
	this.instance_59._off = true;

	this.instance_60 = new lib.补间22("synched",0);
	this.instance_60.setTransform(276.25,161.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_57}]}).to({state:[]},129).to({state:[{t:this.instance_58}]},59).to({state:[{t:this.instance_59}]},100).to({state:[{t:this.instance_60}]},75).to({state:[{t:this.instance_60}]},45).to({state:[{t:this.instance_60}]},100).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_59).wait(288).to({_off:false},0).to({_off:true,x:276.25},75).wait(196));

	// sky
	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["#9DC8DB","#FFFFFF"],[0,1],3.5,-85.9,-1.3,32.7).s().p("Eg5GANEIAA6HMByNAAAIAAaHg");
	this.shape_172.setTransform(99.475,64.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_172).wait(559));

	// ground
	this.instance_61 = new lib.grassland("synched",0);
	this.instance_61.setTransform(220.05,242.3,1,1,0,0,0,0,-82.5);
	var instance_61Filter_1 = new cjs.ColorFilter(0.72,0.72,0.72,1,71.4,71.4,71.4,0);
	this.instance_61.filters = [instance_61Filter_1];
	this.instance_61.cache(-222,-167,444,169);

	this.instance_62 = new lib.补间25("synched",0);
	this.instance_62.setTransform(0,244.65);
	this.instance_62._off = true;

	this.instance_63 = new lib.补间26("synched",0);
	this.instance_63.setTransform(207,244.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_61}]}).to({state:[]},129).to({state:[{t:this.instance_61}]},59).to({state:[{t:this.instance_62}]},100).to({state:[{t:this.instance_63}]},75).to({state:[{t:this.instance_63}]},45).to({state:[{t:this.instance_63}]},100).wait(51));
	this.timeline.addTween(cjs.Tween.get(this.instance_62).wait(288).to({_off:false},0).to({_off:true,x:207},75).wait(196));
	this.timeline.addTween(cjs.Tween.get(instance_61Filter_1).wait(59).to(new cjs.ColorFilter(0.72,0.72,0.72,1,71.4,71.4,71.4,0), 0).wait(271));
	this.instance_62.addEventListener("tick", AdobeAn.handleFilterCache);
	this.instance_63.addEventListener("tick", AdobeAn.handleFilterCache);

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_61, startFrame:188, endFrame:188, x:-222, y:-167, w:444, h:169});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-240.1,98.6,1116.8,254.1);
// library properties:
lib.properties = {
	id: '5109BEBCB62AB74AB8EA7C6B2F3DFC85',
	width: 400,
	height: 300,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/BMP_26b679c2_34a8_4f49_a075_b145af616971.png", id:"BMP_26b679c2_34a8_4f49_a075_b145af616971"},
		{src:"images/BMP_332ea57d_16d1_4228_8327_61e38414cc39.png", id:"BMP_332ea57d_16d1_4228_8327_61e38414cc39"},
		{src:"images/BMP_370ec49d_0b79_4455_9e61_924055af0a22.png", id:"BMP_370ec49d_0b79_4455_9e61_924055af0a22"},
		{src:"images/BMP_423e1008_986d_466e_9f99_82c25859bb5d.png", id:"BMP_423e1008_986d_466e_9f99_82c25859bb5d"},
		{src:"images/BMP_5bdd1a53_80c8_49ff_abe6_f52214b2c7d4.png", id:"BMP_5bdd1a53_80c8_49ff_abe6_f52214b2c7d4"},
		{src:"images/BMP_60586941_0b38_4bee_a76f_417c4b942e26.png", id:"BMP_60586941_0b38_4bee_a76f_417c4b942e26"},
		{src:"images/BMP_6aea30a4_9771_48f7_9511_d949c53a09d1.png", id:"BMP_6aea30a4_9771_48f7_9511_d949c53a09d1"},
		{src:"images/BMP_7743ee04_b567_47a2_82da_b45bce5c7968.png", id:"BMP_7743ee04_b567_47a2_82da_b45bce5c7968"},
		{src:"images/BMP_876b56da_2732_4da5_9cf7_313b46d9898d.png", id:"BMP_876b56da_2732_4da5_9cf7_313b46d9898d"},
		{src:"images/BMP_ba9bd476_7fe0_4639_ab98_da0f8fbf99e8.png", id:"BMP_ba9bd476_7fe0_4639_ab98_da0f8fbf99e8"},
		{src:"images/BMP_cd0d2951_0ab3_4fb2_8808_166fb48dac77.png", id:"BMP_cd0d2951_0ab3_4fb2_8808_166fb48dac77"},
		{src:"images/BMP_d2a4597e_fc32_4c5f_9197_c44aa262d36f.png", id:"BMP_d2a4597e_fc32_4c5f_9197_c44aa262d36f"},
		{src:"images/BMP_f8a9dfaa_30ca_4f7f_853c_8063ade2d2b2.png", id:"BMP_f8a9dfaa_30ca_4f7f_853c_8063ade2d2b2"},
		{src:"images/soil.jpg", id:"soil"},
		{src:"images/vecteezy_cartoonbushbushes_19201231.png", id:"vecteezy_cartoonbushbushes_19201231"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_1.png", id:"Ass1_Jieyi Liang_Friends_atlas_1"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_2.png", id:"Ass1_Jieyi Liang_Friends_atlas_2"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_3.png", id:"Ass1_Jieyi Liang_Friends_atlas_3"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_4.png", id:"Ass1_Jieyi Liang_Friends_atlas_4"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_5.png", id:"Ass1_Jieyi Liang_Friends_atlas_5"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_6.png", id:"Ass1_Jieyi Liang_Friends_atlas_6"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_7.png", id:"Ass1_Jieyi Liang_Friends_atlas_7"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_8.png", id:"Ass1_Jieyi Liang_Friends_atlas_8"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_9.png", id:"Ass1_Jieyi Liang_Friends_atlas_9"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_10.png", id:"Ass1_Jieyi Liang_Friends_atlas_10"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_11.png", id:"Ass1_Jieyi Liang_Friends_atlas_11"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_12.png", id:"Ass1_Jieyi Liang_Friends_atlas_12"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_13.png", id:"Ass1_Jieyi Liang_Friends_atlas_13"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_14.png", id:"Ass1_Jieyi Liang_Friends_atlas_14"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_15.png", id:"Ass1_Jieyi Liang_Friends_atlas_15"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_16.png", id:"Ass1_Jieyi Liang_Friends_atlas_16"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_17.png", id:"Ass1_Jieyi Liang_Friends_atlas_17"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_18.png", id:"Ass1_Jieyi Liang_Friends_atlas_18"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_19.png", id:"Ass1_Jieyi Liang_Friends_atlas_19"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_20.png", id:"Ass1_Jieyi Liang_Friends_atlas_20"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_21.png", id:"Ass1_Jieyi Liang_Friends_atlas_21"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_22.png", id:"Ass1_Jieyi Liang_Friends_atlas_22"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_23.png", id:"Ass1_Jieyi Liang_Friends_atlas_23"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_24.png", id:"Ass1_Jieyi Liang_Friends_atlas_24"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_25.png", id:"Ass1_Jieyi Liang_Friends_atlas_25"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_26.png", id:"Ass1_Jieyi Liang_Friends_atlas_26"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_27.png", id:"Ass1_Jieyi Liang_Friends_atlas_27"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_28.png", id:"Ass1_Jieyi Liang_Friends_atlas_28"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_29.png", id:"Ass1_Jieyi Liang_Friends_atlas_29"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_30.png", id:"Ass1_Jieyi Liang_Friends_atlas_30"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_31.png", id:"Ass1_Jieyi Liang_Friends_atlas_31"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_32.png", id:"Ass1_Jieyi Liang_Friends_atlas_32"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_33.png", id:"Ass1_Jieyi Liang_Friends_atlas_33"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_34.png", id:"Ass1_Jieyi Liang_Friends_atlas_34"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_35.png", id:"Ass1_Jieyi Liang_Friends_atlas_35"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_36.png", id:"Ass1_Jieyi Liang_Friends_atlas_36"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_37.png", id:"Ass1_Jieyi Liang_Friends_atlas_37"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_38.png", id:"Ass1_Jieyi Liang_Friends_atlas_38"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_39.png", id:"Ass1_Jieyi Liang_Friends_atlas_39"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_40.png", id:"Ass1_Jieyi Liang_Friends_atlas_40"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_41.png", id:"Ass1_Jieyi Liang_Friends_atlas_41"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_42.png", id:"Ass1_Jieyi Liang_Friends_atlas_42"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_43.png", id:"Ass1_Jieyi Liang_Friends_atlas_43"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_44.png", id:"Ass1_Jieyi Liang_Friends_atlas_44"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_45.png", id:"Ass1_Jieyi Liang_Friends_atlas_45"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_46.png", id:"Ass1_Jieyi Liang_Friends_atlas_46"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_47.png", id:"Ass1_Jieyi Liang_Friends_atlas_47"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_48.png", id:"Ass1_Jieyi Liang_Friends_atlas_48"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_49.png", id:"Ass1_Jieyi Liang_Friends_atlas_49"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_50.png", id:"Ass1_Jieyi Liang_Friends_atlas_50"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_51.png", id:"Ass1_Jieyi Liang_Friends_atlas_51"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_52.png", id:"Ass1_Jieyi Liang_Friends_atlas_52"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_53.png", id:"Ass1_Jieyi Liang_Friends_atlas_53"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_54.png", id:"Ass1_Jieyi Liang_Friends_atlas_54"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_55.png", id:"Ass1_Jieyi Liang_Friends_atlas_55"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_56.png", id:"Ass1_Jieyi Liang_Friends_atlas_56"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_57.png", id:"Ass1_Jieyi Liang_Friends_atlas_57"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_58.png", id:"Ass1_Jieyi Liang_Friends_atlas_58"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_59.png", id:"Ass1_Jieyi Liang_Friends_atlas_59"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_60.png", id:"Ass1_Jieyi Liang_Friends_atlas_60"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_61.png", id:"Ass1_Jieyi Liang_Friends_atlas_61"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_62.png", id:"Ass1_Jieyi Liang_Friends_atlas_62"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_63.png", id:"Ass1_Jieyi Liang_Friends_atlas_63"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_64.png", id:"Ass1_Jieyi Liang_Friends_atlas_64"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_65.png", id:"Ass1_Jieyi Liang_Friends_atlas_65"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_66.png", id:"Ass1_Jieyi Liang_Friends_atlas_66"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_67.png", id:"Ass1_Jieyi Liang_Friends_atlas_67"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_68.png", id:"Ass1_Jieyi Liang_Friends_atlas_68"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_69.png", id:"Ass1_Jieyi Liang_Friends_atlas_69"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_70.png", id:"Ass1_Jieyi Liang_Friends_atlas_70"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_71.png", id:"Ass1_Jieyi Liang_Friends_atlas_71"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_72.png", id:"Ass1_Jieyi Liang_Friends_atlas_72"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_73.png", id:"Ass1_Jieyi Liang_Friends_atlas_73"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_74.png", id:"Ass1_Jieyi Liang_Friends_atlas_74"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_75.png", id:"Ass1_Jieyi Liang_Friends_atlas_75"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_76.png", id:"Ass1_Jieyi Liang_Friends_atlas_76"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_77.png", id:"Ass1_Jieyi Liang_Friends_atlas_77"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_78.png", id:"Ass1_Jieyi Liang_Friends_atlas_78"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_79.png", id:"Ass1_Jieyi Liang_Friends_atlas_79"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_80.png", id:"Ass1_Jieyi Liang_Friends_atlas_80"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_81.png", id:"Ass1_Jieyi Liang_Friends_atlas_81"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_82.png", id:"Ass1_Jieyi Liang_Friends_atlas_82"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_83.png", id:"Ass1_Jieyi Liang_Friends_atlas_83"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_84.png", id:"Ass1_Jieyi Liang_Friends_atlas_84"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_85.png", id:"Ass1_Jieyi Liang_Friends_atlas_85"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_86.png", id:"Ass1_Jieyi Liang_Friends_atlas_86"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_87.png", id:"Ass1_Jieyi Liang_Friends_atlas_87"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_88.png", id:"Ass1_Jieyi Liang_Friends_atlas_88"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_89.png", id:"Ass1_Jieyi Liang_Friends_atlas_89"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_90.png", id:"Ass1_Jieyi Liang_Friends_atlas_90"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_91.png", id:"Ass1_Jieyi Liang_Friends_atlas_91"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_92.png", id:"Ass1_Jieyi Liang_Friends_atlas_92"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_93.png", id:"Ass1_Jieyi Liang_Friends_atlas_93"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_94.png", id:"Ass1_Jieyi Liang_Friends_atlas_94"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_95.png", id:"Ass1_Jieyi Liang_Friends_atlas_95"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_96.png", id:"Ass1_Jieyi Liang_Friends_atlas_96"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_97.png", id:"Ass1_Jieyi Liang_Friends_atlas_97"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_98.png", id:"Ass1_Jieyi Liang_Friends_atlas_98"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_99.png", id:"Ass1_Jieyi Liang_Friends_atlas_99"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_100.png", id:"Ass1_Jieyi Liang_Friends_atlas_100"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_101.png", id:"Ass1_Jieyi Liang_Friends_atlas_101"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_102.png", id:"Ass1_Jieyi Liang_Friends_atlas_102"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_103.png", id:"Ass1_Jieyi Liang_Friends_atlas_103"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_104.png", id:"Ass1_Jieyi Liang_Friends_atlas_104"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_105.png", id:"Ass1_Jieyi Liang_Friends_atlas_105"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_106.png", id:"Ass1_Jieyi Liang_Friends_atlas_106"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_107.png", id:"Ass1_Jieyi Liang_Friends_atlas_107"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_108.png", id:"Ass1_Jieyi Liang_Friends_atlas_108"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_109.png", id:"Ass1_Jieyi Liang_Friends_atlas_109"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_110.png", id:"Ass1_Jieyi Liang_Friends_atlas_110"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_111.png", id:"Ass1_Jieyi Liang_Friends_atlas_111"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_112.png", id:"Ass1_Jieyi Liang_Friends_atlas_112"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_113.png", id:"Ass1_Jieyi Liang_Friends_atlas_113"},
		{src:"images/Ass1_Jieyi Liang_Friends_atlas_114.png", id:"Ass1_Jieyi Liang_Friends_atlas_114"},
		{src:"sounds/fallwav.mp3", id:"fallwav"},
		{src:"sounds/gamefailedwav.mp3", id:"gamefailedwav"},
		{src:"sounds/ideawav.mp3", id:"ideawav"},
		{src:"sounds/ImpactsBoardWoodHitByLargeMetalPole.mp3", id:"ImpactsBoardWoodHitByLargeMetalPole"},
		{src:"sounds/jumpsoundver26093wav.mp3", id:"jumpsoundver26093wav"},
		{src:"sounds/laughwav.mp3", id:"laughwav"},
		{src:"sounds/laughingWAV.mp3", id:"laughingWAV"},
		{src:"sounds/magicWAV.mp3", id:"magicWAV"},
		{src:"sounds/springwav.mp3", id:"springwav"},
		{src:"sounds/stetch2WAV.mp3", id:"stetch2WAV"},
		{src:"sounds/stretch1WAV.mp3", id:"stretch1WAV"},
		{src:"sounds/successwav.mp3", id:"successwav"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5109BEBCB62AB74AB8EA7C6B2F3DFC85'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;